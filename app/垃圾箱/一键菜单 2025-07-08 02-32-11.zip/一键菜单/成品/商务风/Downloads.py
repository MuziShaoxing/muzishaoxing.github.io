import os
from datetime import datetime

class DirectoryTreeGenerator:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.folder_name = os.path.basename(folder_path)
        self.html_content = []
        # 获取当前时间作为生成时间
        self.generated_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def generate_html(self):
        self.html_content.append('<!DOCTYPE html>')
        self.html_content.append('<html lang="en">')
        self.html_content.append('<head>')
        self.html_content.append('<meta charset="UTF-8">')
        self.html_content.append('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
        self.html_content.append(f'<title>{self.folder_name} 目录结构</title>')
        # 引入Material Icons字体
        self.html_content.append('<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">')
        self.html_content.append('<style>')
        self.html_content.append('''
            :root {
                --background-color: #f8f9fa;
                --container-bg: #ffffff;
                --text-color: #495057;
                --primary-color: #4a6baf;
                --secondary-color: #3a5a9a;
                --light-color: #f1f5fe;
                --dark-color: #1a1a2e;
                --gray-color: #16213e;
                --shadow-color: rgba(0, 0, 0, 0.08);
                --dark-shadow: rgba(0, 0, 0, 0.3);
                --button-size: 46px;
                --spacing: 15px;
                --transition-time: 0.3s;
                --border-color: #e0e0e0;
            }

            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            
            body {
                font-family: 'Segoe UI', 'Roboto', sans-serif;
                background-color: var(--background-color);
                color: var(--text-color);
                padding: 20px;
                transition: background-color var(--transition-time), color var(--transition-time);
                display: flex;
                flex-direction: column;
                align-items: center;
                line-height: 1.6;
            }
            
            .container {
                max-width: 1000px;
                width: 100%;
                background-color: var(--container-bg);
                padding: 25px;
                border-radius: 8px;
                box-shadow: 0 4px 12px var(--shadow-color);
                transition: background-color var(--transition-time);
                margin-top: 20px;
            }
            
            .header {
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 25px;
            }
            
            h1 {
                text-align: center;
                color: var(--text-color);
                margin: 0;
                transition: color var(--transition-time);
                font-weight: 500;
                font-size: 1.8rem;
            }
            
            .search-container {
                display: flex;
                justify-content: center;
                align-items: center;
                margin-bottom: 25px;
                flex-wrap: wrap;
                gap: var(--spacing);
            }
            
            .search-container button {
                background: none;
                color: var(--text-color);
                border: 1px solid var(--border-color);
                width: var(--button-size);
                height: var(--button-size);
                border-radius: 50%;
                cursor: pointer;
                transition: all var(--transition-time);
                display: flex;
                align-items: center;
                justify-content: center;
                background-color: var(--container-bg);
            }
            
            .search-container button:hover {
                background-color: rgba(0, 0, 0, 0.03);
                border-color: var(--primary-color);
                color: var(--primary-color);
            }
            
            .search-container input {
                flex: 1;
                padding: 12px 15px;
                border: 1px solid var(--border-color);
                border-radius: 6px;
                font-size: 16px;
                transition: border-color var(--transition-time);
                max-width: 600px;
                background-color: var(--container-bg);
                color: var(--text-color);
            }
            
            .search-container input:focus {
                outline: none;
                border-color: var(--primary-color);
                box-shadow: 0 0 0 2px rgba(74, 107, 175, 0.2);
            }
            
            .tree {
                margin: 0;
                padding: 0;
                list-style: none;
            }
            
            .tree li {
                margin: 0;
                padding: 10px 15px;
                position: relative;
                background-color: var(--container-bg);
                border-radius: 6px;
                transition: all var(--transition-time);
                cursor: pointer;
                box-shadow: 0 1px 2px var(--shadow-color);
                margin-bottom: 6px;
                border: 1px solid var(--border-color);
            }
            
            .tree li:hover {
                background-color: var(--light-color);
                border-color: var(--primary-color);
            }
            
            .tree .directory-wrapper {
                display: flex;
                align-items: center;
            }
            
            .tree .toggle {
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 10px;
                color: var(--primary-color);
            }
            
            .material-icons {
                font-size: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .tree .file {
                display: flex;
                align-items: center;
                padding-left: 30px;
            }
            
            .tree .file-icon {
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 10px;
                color: var(--primary-color);
            }
            
            .tree ul {
                display: none;
                padding-left: 20px;
                margin-top: 8px;
                list-style: none;
            }
            
            .tree li.open > ul {
                display: block;
            }
            
            body.dark {
                --background-color: var(--dark-color);
                --container-bg: var(--gray-color);
                --text-color: #e0e0e0;
                --primary-color: #5d8aff;
                --light-color: #252a3e;
                --shadow-color: var(--dark-shadow);
                --border-color: #2a2a4a;
            }

            /* 移除链接下划线和悬停效果 */
            a {
                text-decoration: none;
                color: inherit;
            }
            
            a:hover {
                color: var(--primary-color);
            }

            /* 暗色模式下的按钮样式 */
            body.dark .search-container button {
                background-color: var(--gray-color);
                border-color: var(--border-color);
            }
            
            body.dark .search-container button:hover {
                background-color: rgba(255, 255, 255, 0.05);
                border-color: var(--primary-color);
            }
            
            /* 生成时间组件样式 */
            .generated-time {
                text-align: center;
                margin-top: 30px;
                padding-top: 15px;
                border-top: 1px solid var(--border-color);
                color: var(--text-color);
                font-size: 14px;
                opacity: 0.7;
                transition: color var(--transition-time);
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .time-icon {
                vertical-align: middle;
                margin-right: 8px;
                font-size: 16px;
            }
        ''')
        self.html_content.append('</style>')
        self.html_content.append('</head>')
        self.html_content.append('<body>')
        self.html_content.append('<div class="container">')
        self.html_content.append('<div class="header">')
        self.html_content.append(f'<h1>{self.folder_name} 目录结构</h1>')
        self.html_content.append('</div>')
        self.html_content.append('<div class="search-container">')
        self.html_content.append('<button id="toggle-theme"><span class="material-icons">light_mode</span></button>')
        self.html_content.append('<button id="toggle-all"><span class="material-icons">unfold_more</span></button>')
        self.html_content.append('<input type="text" id="search-input" placeholder="搜索文件或文件夹...">')
        self.html_content.append('<button id="reset-search"><span class="material-icons">refresh</span></button>')
        self.html_content.append('</div>')
        self.html_content.append('<ul class="tree">')
        self.process_directory(self.folder_path)
        self.html_content.append('</ul>')
        # 添加生成时间组件
        self.html_content.append(f'<div class="generated-time">')
        self.html_content.append('<span class="material-icons time-icon">schedule</span>')
        self.html_content.append(f'<span>生成时间: {self.generated_time}</span>')
        self.html_content.append('</div>')
        self.html_content.append('</div>')
        self.html_content.append('<script>')
        self.html_content.append('''
            document.addEventListener('DOMContentLoaded', function() {
                // 目录项点击事件
                document.querySelectorAll('.tree .directory-wrapper').forEach(wrapper => {
                    wrapper.addEventListener('click', function(e) {
                        if(e.target === this.querySelector('.toggle') || 
                           e.target === this.querySelector('.toggle *')) {
                            const parent = this.parentElement;
                            parent.classList.toggle('open');
                            const icon = this.querySelector('.material-icons');
                            icon.textContent = parent.classList.contains('open') ? 'expand_more' : 'chevron_right';
                        }
                    });
                });

                // 主题切换
                const toggleTheme = document.getElementById('toggle-theme');
                toggleTheme.addEventListener('click', function() {
                    document.body.classList.toggle('dark');
                    localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
                    this.querySelector('.material-icons').textContent = 
                        document.body.classList.contains('dark') ? 'dark_mode' : 'light_mode';
                });

                // 初始化主题
                if (localStorage.getItem('theme') === 'dark') {
                    document.body.classList.add('dark');
                    toggleTheme.querySelector('.material-icons').textContent = 'dark_mode';
                }

                // 展开/折叠全部
                const toggleAll = document.getElementById('toggle-all');
                toggleAll.addEventListener('click', function() {
                    const isExpanded = this.querySelector('.material-icons').textContent === 'unfold_more';
                    document.querySelectorAll('.tree li').forEach(li => {
                        const icon = li.querySelector('.directory-wrapper .material-icons');
                        if(icon) {
                            li.classList.toggle('open', !isExpanded);
                            icon.textContent = isExpanded ? 'expand_more' : 'chevron_right';
                        }
                    });
                    this.querySelector('.material-icons').textContent = isExpanded ? 'unfold_less' : 'unfold_more';
                });

                // 搜索功能
                const searchInput = document.getElementById('search-input');
                const resetSearch = document.getElementById('reset-search');
                
                searchInput.addEventListener('input', function() {
                    const term = this.value.toLowerCase();
                    document.querySelectorAll('.tree li').forEach(li => {
                        const text = li.textContent.toLowerCase();
                        const isMatch = text.includes(term);
                        li.style.display = isMatch ? '' : 'none';
                        
                        if(isMatch) {
                            let parent = li.parentElement;
                            while(parent && parent.classList.contains('tree') === false) {
                                parent.style.display = '';
                                parent.classList.add('open');
                                const icon = parent.querySelector('.directory-wrapper .material-icons');
                                if(icon) icon.textContent = 'expand_more';
                                parent = parent.parentElement;
                            }
                        }
                    });
                });

                resetSearch.addEventListener('click', function() {
                    searchInput.value = '';
                    document.querySelectorAll('.tree li').forEach(li => {
                        li.style.display = '';
                    });
                    const toggleAllIcon = document.getElementById('toggle-all').querySelector('.material-icons');
                    toggleAllIcon.textContent = 'unfold_more';
                    document.querySelectorAll('.tree li').forEach(li => {
                        li.classList.add('open');
                        const icon = li.querySelector('.directory-wrapper .material-icons');
                        if(icon) icon.textContent = 'expand_more';
                    });
                });
            });
        ''')
        self.html_content.append('</script>')
        self.html_content.append('</body>')
        self.html_content.append('</html>')

    def process_directory(self, directory_path):
        dir_name = os.path.basename(directory_path)
        self.html_content.append('<li>')
        self.html_content.append('<div class="directory-wrapper">')
        self.html_content.append('<span class="toggle"><span class="material-icons">chevron_right</span></span>')
        self.html_content.append(f'<span class="directory">{dir_name}</span>')
        self.html_content.append('</div>')
        self.html_content.append('<ul>')

        try:
            contents = os.listdir(directory_path)
            # 分离文件和文件夹并分别排序
            dirs = []
            files = []
            for item in contents:
                if item.startswith('.') or item.lower().endswith('.html'):
                    continue
                item_path = os.path.join(directory_path, item)
                if os.path.isdir(item_path):
                    dirs.append(item)
                else:
                    files.append(item)
            
            # 分别按字母顺序排序
            dirs.sort(key=lambda x: x.lower())
            files.sort(key=lambda x: x.lower())
            
            # 先添加文件，再添加文件夹
            for item in files:
                item_path = os.path.join(directory_path, item)
                self.html_content.append('<li>')
                self.html_content.append('<div class="file">')
                self.html_content.append('<span class="file-icon"><span class="material-icons">insert_drive_file</span></span>')
                self.html_content.append(f'<a href="./{os.path.relpath(item_path, self.folder_path).replace("\\", "/")}">{item}</a>')
                self.html_content.append('</div>')
                self.html_content.append('</li>')
                
            for item in dirs:
                item_path = os.path.join(directory_path, item)
                self.process_directory(item_path)
                
        except Exception as e:
            print(f"无法访问目录 {directory_path}: {e}")

        self.html_content.append('</ul>')
        self.html_content.append('</li>')

def main():
    folder_path = input("请输入文件夹路径: ").strip()
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        print("指定的路径不存在或不是一个文件夹，请检查后重新输入。")
        return

    generator = DirectoryTreeGenerator(folder_path)
    generator.generate_html()

    html_output = os.path.join(folder_path, "目录树.html")
    with open(html_output, 'w', encoding='utf-8') as f:
        f.write('\n'.join(generator.html_content))

    print(f"HTML文件已生成：{html_output}")
    print(f"生成时间: {generator.generated_time}")

if __name__ == "__main__":
    main()