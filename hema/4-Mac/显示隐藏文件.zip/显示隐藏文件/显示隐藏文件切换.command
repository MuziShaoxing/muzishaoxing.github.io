#!/bin/bash

# ==============================================
# 隐藏文件切换器 (macOS版)
# 功能：图形化切换指定目录的隐藏文件显示状态
# 使用方式：双击运行此.command文件
# ==============================================

# 设置终端窗口标题
function set_terminal_title() {
    echo -n -e "\033]0;隐藏文件切换器\007"
}

# 显示隐藏文件
show_hidden() {
    osascript <<EOD
    tell application "Finder"
        set targetFolder to choose folder with prompt "请选择要显示隐藏文件的目录"
        set targetPath to POSIX path of targetFolder
        do shell script "defaults write com.apple.finder AppleShowAllFiles YES"
        do shell script "osascript -e 'tell application \"Finder\" to update (POSIX file \"" & targetPath & "\" as alias)'"
        do shell script "killall Finder"
        display notification "已显示隐藏文件" with title "操作成功" subtitle targetPath
    end tell
EOD
}

# 隐藏隐藏文件
hide_hidden() {
    osascript <<EOD
    tell application "Finder"
        set targetFolder to choose folder with prompt "请选择要隐藏隐藏文件的目录"
        set targetPath to POSIX path of targetFolder
        do shell script "defaults write com.apple.finder AppleShowAllFiles NO"
        do shell script "osascript -e 'tell application \"Finder\" to update (POSIX file \"" & targetPath & "\" as alias)'"
        do shell script "killall Finder"
        display notification "已隐藏隐藏文件" with title "操作成功" subtitle targetPath
    end tell
EOD
}

# 主菜单界面
main_menu() {
    while true; do
        clear
        set_terminal_title
        echo ""
        echo "      ███████╗██╗  ██╗██████╗ ███████╗██╗   ██╗"
        echo "      ██╔════╝██║  ██║██╔══██╗██╔════╝╚██╗ ██╔╝"
        echo "      █████╗  ███████║██████╔╝█████╗   ╚████╔╝ "
        echo "      ██╔══╝  ██╔══██║██╔══██╗██╔══╝    ╚██╔╝  "
        echo "      ██║     ██║  ██║██║  ██║███████╗   ██║   "
        echo "      ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   "
        echo ""
        echo "            macOS 隐藏文件切换工具 v1.2"
        echo "        -----------------------------------"
        echo ""
        echo "          请选择操作："
        echo ""
        echo "          1. 显示指定目录的隐藏文件"
        echo "          2. 隐藏指定目录的隐藏文件"
        echo "          3. 退出程序"
        echo ""
        echo "        -----------------------------------"
        read -p "        请输入选项 (1-3): " choice

        case $choice in
            1) show_hidden ;;
            2) hide_hidden ;;
            3) break ;;
            *) 
                osascript -e 'display dialog "无效输入，请选择1-3的选项。" buttons {"OK"} with icon stop'
                ;;
        esac
    done
}

# 启动主程序
chmod +x "$0"
main_menu