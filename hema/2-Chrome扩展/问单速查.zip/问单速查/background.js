// background.js
// 点击工具栏图标 -> 打开（或聚焦）工具页面
const PAGE_URL = chrome.runtime.getURL('index.html');

chrome.action.onClicked.addListener(async () => {
    try {
        const tabs = await chrome.tabs.query({ url: PAGE_URL });
        if (tabs && tabs.length > 0) {
            const tab = tabs[0];
            await chrome.tabs.update(tab.id, { active: true });
            await chrome.windows.update(tab.windowId, { focused: true });
            return;
        }
    } catch (e) {
        // 查询失败则直接新建
        console.warn('查询已有标签页失败，将新建标签页', e);
    }
    await chrome.tabs.create({ url: PAGE_URL });
});

// 首次安装后自动打开一次，方便确认安装成功
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        chrome.tabs.create({ url: PAGE_URL });
    }
});