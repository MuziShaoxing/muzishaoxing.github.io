import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import os
import sys
import subprocess
from collections import defaultdict

# 尝试导入拖拽支持
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    USE_DND = True
except ImportError:
    USE_DND = False

class StyledButton(tk.Button):
    """自定义按钮样式，带悬停和点击动画效果"""
    def __init__(self, master=None, **kwargs):
        default_style = {
            'bg': '#FFFFFF',
            'fg': '#000000',
            'font': ('微软雅黑', 15),
            'relief': 'flat',
            'bd': 1,
            'cursor': 'hand2',
            'activebackground': '#E8E8E8',
            'activeforeground': '#000000'
        }
        default_style.update(kwargs)
        super().__init__(master, **default_style)
        
        self.bind('<Enter>', self.on_enter)
        self.bind('<Leave>', self.on_leave)
        self.bind('<ButtonPress-1>', self.on_press)
        self.bind('<ButtonRelease-1>', self.on_release)
        
        self.original_bg = default_style['bg']
        self.hover_bg = '#F0F0F0'
        self.press_bg = '#D8D8D8'
        self.disabled_bg = '#E0E0E0'
        self.disabled_fg = '#A0A0A0'
    
    def on_enter(self, event):
        if self['state'] != 'disabled':
            self.config(bg=self.hover_bg)
    
    def on_leave(self, event):
        if self['state'] != 'disabled':
            self.config(bg=self.original_bg)
    
    def on_press(self, event):
        if self['state'] != 'disabled':
            self.config(bg=self.press_bg)
    
    def on_release(self, event):
        if self['state'] != 'disabled':
            self.config(bg=self.hover_bg)
    
    def config(self, **kwargs):
        super().config(**kwargs)
        if 'state' in kwargs and kwargs['state'] == 'disabled':
            super().config(bg=self.disabled_bg, fg=self.disabled_fg, cursor='arrow')
        elif 'state' in kwargs and kwargs['state'] == 'normal':
            super().config(bg=self.original_bg, fg='#000000', cursor='hand2')

class ExcelToVCardApp:
    def __init__(self, root):
        if USE_DND:
            self.root = root
        else:
            self.root = root
        
        self.root.title("Excel 转 通讯录 vCard 工具")
        self.root.geometry("950x700")
        self.root.resizable(True, True)
        self.root.minsize(850, 600)
        self.root.configure(bg='#F5F5F5')
        
        self.file_paths = []
        self.df = None
        self.processed_contacts = []
        self.column_letters = []
        self.column_mapping = {}
        
        self.name_col = tk.StringVar(value="AD")
        self.phone_col = tk.StringVar(value="AE")
        self.company_col = tk.StringVar(value="AF")
        
        self.merge_duplicates = tk.BooleanVar(value=True)
        self.phone_separator = tk.StringVar(value="; ")
        self.filter_empty_name = tk.BooleanVar(value=True)
        self.filter_empty_phone = tk.BooleanVar(value=False)
        
        self.setup_ui()
        self.update_button_states()
        
        if USE_DND:
            self.root.drop_target_register(DND_FILES)
            self.root.dnd_bind('<<Drop>>', self.on_drop)

    def open_folder(self, path):
        try:
            if sys.platform == 'win32':
                os.startfile(path)
            elif sys.platform == 'darwin':
                subprocess.run(['open', path])
            else:
                subprocess.run(['xdg-open', path])
        except Exception as e:
            messagebox.showwarning("提示", f"无法自动打开文件夹，请手动打开：\n{path}")

    def update_button_states(self):
        """根据文件选择状态更新按钮状态"""
        if self.file_paths:
            self.load_btn.config(state="normal")
        else:
            self.load_btn.config(state="disabled")
        
        if self.processed_contacts:
            self.convert_btn.config(state="normal")
        else:
            self.convert_btn.config(state="disabled")

    def setup_ui(self):
        main_frame = tk.Frame(self.root, padx=12, pady=12, bg='#F5F5F5')
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 标题
        title = tk.Label(main_frame, text="📇 Excel 通讯录转换器", 
                        font=("微软雅黑", 18, "bold"), bg='#F5F5F5', fg='#000000')
        title.pack(pady=(0, 8))
        
        subtitle = tk.Label(main_frame, text="支持多文件 · 无数量限制 · 默认读取 AD/AE/AF 列",
                           font=("微软雅黑", 10), bg='#F5F5F5', fg='#555555')
        subtitle.pack(pady=(0, 12))

        # ========== 步骤 1：选择文件 ==========
        step1_frame = tk.LabelFrame(main_frame, text="步骤 1：选择 Excel 文件", 
                                    padx=12, pady=10, bg='#F5F5F5', fg='#000000',
                                    font=('微软雅黑', 12, 'bold'))
        step1_frame.pack(fill=tk.X, pady=(0, 10))

        # 左右布局：左侧按钮，右侧文件信息
        file_main_frame = tk.Frame(step1_frame, bg='#F5F5F5')
        file_main_frame.pack(fill=tk.X)

        # 左侧按钮区域
        left_btn_frame = tk.Frame(file_main_frame, bg='#F5F5F5')
        left_btn_frame.pack(side=tk.LEFT)

        select_btn = StyledButton(left_btn_frame, text="📁 选择文件", command=self.browse_files,
                                 font=("微软雅黑", 15), width=12, height=1)
        select_btn.pack(side=tk.LEFT, padx=(0, 8))

        clear_btn = StyledButton(left_btn_frame, text="🗑️ 清空", command=self.clear_files,
                                font=("微软雅黑", 15), width=8, height=1)
        clear_btn.pack(side=tk.LEFT)

        # 右侧文件信息区域
        right_info_frame = tk.Frame(file_main_frame, bg='#F5F5F5')
        right_info_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(10, 0))

        # 文件计数
        self.file_count_label = tk.Label(right_info_frame, text="已选择 0 个文件", 
                                         font=("微软雅黑", 10, "bold"), fg="#000000", bg='#F5F5F5')
        self.file_count_label.pack(anchor='w')

        # 文件列表标签
        self.file_list_label = tk.Label(right_info_frame, text="", 
                                        font=("微软雅黑", 9), fg="#555555", bg='#F5F5F5',
                                        anchor='w', justify='left')
        self.file_list_label.pack(fill=tk.X, pady=(3, 0))

        if USE_DND:
            drag_tip = tk.Label(step1_frame, text="💡 支持拖拽文件到此窗口", 
                               font=("微软雅黑", 9), fg="#666666", bg='#F5F5F5')
            drag_tip.pack(anchor='e', pady=(5, 0))

        # ========== 步骤 2：列映射与数据处理 ==========
        step2_frame = tk.LabelFrame(main_frame, text="步骤 2：列映射与数据处理", 
                                    padx=12, pady=10, bg='#F5F5F5', fg='#000000',
                                    font=('微软雅黑', 12, 'bold'))
        step2_frame.pack(fill=tk.X, pady=(0, 10))

        # 第一行：列映射设置
        map_frame = tk.Frame(step2_frame, bg='#F5F5F5')
        map_frame.pack(fill=tk.X, pady=(0, 10))

        # 姓名列
        tk.Label(map_frame, text="姓名列：", font=("微软雅黑", 15), bg='#F5F5F5', fg='#000000').pack(side=tk.LEFT, padx=(0, 5))
        self.name_combo = ttk.Combobox(map_frame, textvariable=self.name_col, width=12, font=("微软雅黑", 10))
        self.name_combo.pack(side=tk.LEFT, padx=(0, 15))

        # 电话列
        tk.Label(map_frame, text="电话列：", font=("微软雅黑", 15), bg='#F5F5F5', fg='#000000').pack(side=tk.LEFT, padx=(0, 5))
        self.phone_combo = ttk.Combobox(map_frame, textvariable=self.phone_col, width=12, font=("微软雅黑", 10))
        self.phone_combo.pack(side=tk.LEFT, padx=(0, 15))

        # 公司列
        tk.Label(map_frame, text="公司列：", font=("微软雅黑", 15), bg='#F5F5F5', fg='#000000').pack(side=tk.LEFT, padx=(0, 5))
        self.company_combo = ttk.Combobox(map_frame, textvariable=self.company_col, width=12, font=("微软雅黑", 10))
        self.company_combo.pack(side=tk.LEFT, padx=(0, 15))

        # 刷新按钮
        refresh_cols_btn = StyledButton(map_frame, text="↻ 刷新", command=self.refresh_column_list, 
                                       font=("微软雅黑", 15), width=8)
        refresh_cols_btn.pack(side=tk.LEFT)

        # 默认提示
        tip_label = tk.Label(map_frame, text="默认 AD/AE/AF", 
                            font=("微软雅黑", 9), fg="#888888", bg='#F5F5F5')
        tip_label.pack(side=tk.LEFT, padx=(10, 0))

        # 分隔线
        separator = ttk.Separator(step2_frame, orient='horizontal')
        separator.pack(fill=tk.X, pady=(0, 10))

        # 第二行：过滤选项 + 加载按钮
        row1_frame = tk.Frame(step2_frame, bg='#F5F5F5')
        row1_frame.pack(fill=tk.X, pady=(0, 8))

        # 过滤选项
        filter_frame = tk.Frame(row1_frame, bg='#F5F5F5')
        filter_frame.pack(side=tk.LEFT)

        self.filter_name_check = tk.Checkbutton(filter_frame, text="过滤空姓名", 
                                                variable=self.filter_empty_name,
                                                font=("微软雅黑", 15), bg='#F5F5F5', fg='#000000',
                                                activebackground='#F5F5F5', selectcolor='#F5F5F5')
        self.filter_name_check.pack(side=tk.LEFT, padx=(0, 15))

        self.filter_phone_check = tk.Checkbutton(filter_frame, text="过滤空电话", 
                                                 variable=self.filter_empty_phone,
                                                 font=("微软雅黑", 15), bg='#F5F5F5', fg='#000000',
                                                 activebackground='#F5F5F5', selectcolor='#F5F5F5')
        self.filter_phone_check.pack(side=tk.LEFT)

        # 加载按钮
        self.load_btn = StyledButton(row1_frame, text="📂 加载并预览", command=self.load_and_preview,
                                    font=("微软雅黑", 20, "bold"), padx=15, pady=4)
        self.load_btn.pack(side=tk.RIGHT)

        # 第三行：合并选项
        row2_frame = tk.Frame(step2_frame, bg='#F5F5F5')
        row2_frame.pack(fill=tk.X)

        self.merge_check = tk.Checkbutton(row2_frame, text="合并相同姓名的联系人", 
                                          variable=self.merge_duplicates,
                                          font=("微软雅黑", 15), bg='#F5F5F5', fg='#000000',
                                          activebackground='#F5F5F5', selectcolor='#F5F5F5',
                                          command=self.on_merge_option_changed)
        self.merge_check.pack(side=tk.LEFT)

        tk.Label(row2_frame, text="电话分隔符：", font=("微软雅黑", 15), bg='#F5F5F5', fg='#000000').pack(side=tk.LEFT, padx=(20, 5))
        
        vcmd = (self.root.register(self.validate_separator), '%P')
        sep_entry = tk.Entry(row2_frame, textvariable=self.phone_separator, width=5, 
                            validate='key', validatecommand=vcmd,
                            font=("微软雅黑", 15), bg='#FFFFFF', fg='#000000',
                            relief='solid', bd=1, justify='center')
        sep_entry.pack(side=tk.LEFT)
        
        tk.Label(row2_frame, text="(默认分号)", 
                font=("微软雅黑", 9), fg="#888888", bg='#F5F5F5').pack(side=tk.LEFT, padx=(5, 0))

        # 统计信息
        self.stats_label = tk.Label(step2_frame, text="未加载数据", 
                                   font=("微软雅黑", 10), fg="#555555", bg='#F5F5F5')
        self.stats_label.pack(pady=(8, 0))

        # ========== 步骤 3：数据预览 ==========
        step3_frame = tk.LabelFrame(main_frame, text="步骤 3：数据预览", 
                                    padx=10, pady=10, bg='#F5F5F5', fg='#000000',
                                    font=('微软雅黑', 12, 'bold'))
        step3_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))

        # 预览标题栏
        preview_header = tk.Frame(step3_frame, bg='#F5F5F5')
        preview_header.pack(fill=tk.X, pady=(0, 5))

        self.preview_status_label = tk.Label(preview_header, text="等待加载数据...", 
                                            font=("微软雅黑", 18), fg="#555555", bg='#F5F5F5')
        self.preview_status_label.pack(side=tk.LEFT)

        self.convert_btn = StyledButton(preview_header, text="⬇ 导出 vCard", 
                                       command=self.convert_to_vcard,
                                       font=("微软雅黑", 20, "bold"), 
                                       padx=20, pady=5, state="disabled")
        self.convert_btn.pack(side=tk.RIGHT)

        # 表格
        tree_frame = tk.Frame(step3_frame, bg='#F5F5F5')
        tree_frame.pack(fill=tk.BOTH, expand=True)

        scrollbar_y = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL)
        scrollbar_x = ttk.Scrollbar(tree_frame, orient=tk.HORIZONTAL)

        style = ttk.Style()
        style.configure("Treeview", 
                       background="#FFFFFF",
                       foreground="#000000",
                       rowheight=26,
                       fieldbackground="#FFFFFF",
                       font=('微软雅黑', 18))
        style.configure("Treeview.Heading",
                       background="#E8E8E8",
                       foreground="#000000",
                       font=('微软雅黑', 18, 'bold'))
        style.map("Treeview",
                 background=[('selected', '#D0D0D0')],
                 foreground=[('selected', '#000000')])

        self.tree = ttk.Treeview(tree_frame, 
                                 columns=("序号", "姓名", "电话", "公司"),
                                 show="headings",
                                 yscrollcommand=scrollbar_y.set,
                                 xscrollcommand=scrollbar_x.set,
                                 height=18,
                                 style="Treeview")

        scrollbar_y.config(command=self.tree.yview)
        scrollbar_x.config(command=self.tree.xview)

        self.tree.heading("序号", text="序号")
        self.tree.heading("姓名", text="姓名")
        self.tree.heading("电话", text="电话")
        self.tree.heading("公司", text="公司")

        self.tree.column("序号", width=55, anchor="center")
        self.tree.column("姓名", width=140)
        self.tree.column("电话", width=200)
        self.tree.column("公司", width=280)

        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar_y.grid(row=0, column=1, sticky="ns")
        scrollbar_x.grid(row=1, column=0, sticky="ew")

        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

    def validate_separator(self, value):
        return len(value) > 0

    def browse_files(self):
        filenames = filedialog.askopenfilenames(
            title="选择 Excel 文件",
            filetypes=[("Excel 文件", "*.xlsx *.xls"), ("所有文件", "*.*")]
        )
        if filenames:
            self.add_files(list(filenames))

    def add_files(self, filenames):
        added_count = 0
        for f in filenames:
            if f not in self.file_paths:
                self.file_paths.append(f)
                added_count += 1
        
        self.update_file_display()
        if self.file_paths:
            self.refresh_column_list()
            if added_count > 0:
                self.preview_status_label.config(text=f"已添加 {added_count} 个文件，共 {len(self.file_paths)} 个")
        
        self.update_button_states()

    def clear_files(self):
        self.file_paths = []
        self.update_file_display()
        self.name_combo['values'] = []
        self.phone_combo['values'] = []
        self.company_combo['values'] = []
        self.preview_status_label.config(text="等待选择文件...")
        self.processed_contacts = []
        self.stats_label.config(text="未加载数据")
        self._update_preview_table()
        self.update_button_states()

    def update_file_display(self):
        """更新文件计数和文件名显示"""
        count = len(self.file_paths)
        self.file_count_label.config(text=f"已选择 {count} 个文件")
        
        if count == 0:
            self.file_list_label.config(text="")
        else:
            file_names = [os.path.basename(f) for f in self.file_paths]
            if count <= 5:
                display_text = "、".join(file_names)
            else:
                display_text = "、".join(file_names[:5]) + f" 等 {count} 个文件"
            self.file_list_label.config(text=display_text)

    def on_drop(self, event):
        files = event.data.strip()
        if files.startswith('{') and files.endswith('}'):
            files = files[1:-1]
        
        file_list = []
        for f in files.split('} {'):
            f = f.strip('{}')
            if f.lower().endswith(('.xlsx', '.xls')):
                file_list.append(f)
        
        if file_list:
            self.add_files(file_list)
        else:
            messagebox.showwarning("文件类型错误", "请拖入 Excel 文件")

    def refresh_column_list(self):
        if not self.file_paths:
            return

        try:
            df_temp = pd.read_excel(self.file_paths[0], nrows=0)
            columns = df_temp.columns.tolist()
            
            self.column_letters = []
            self.column_mapping = {}
            
            for i, col_name in enumerate(columns):
                letter = self._get_excel_column_letter(i)
                display_text = f"{letter} ({col_name})"
                self.column_letters.append(display_text)
                self.column_mapping[letter] = col_name
            
            self.name_combo['values'] = self.column_letters
            self.phone_combo['values'] = self.column_letters
            self.company_combo['values'] = self.column_letters
            
            if not self.name_col.get():
                self.name_col.set("AD")
            if not self.phone_col.get():
                self.phone_col.set("AE")
            if not self.company_col.get():
                self.company_col.set("AF")
            
            self.preview_status_label.config(text=f"已检测 {len(columns)} 列，默认 AD/AE/AF")
        except Exception as e:
            messagebox.showerror("读取失败", f"无法读取Excel文件:\n{str(e)}")

    def _get_excel_column_letter(self, index):
        result = ""
        n = index
        while n >= 0:
            result = chr(65 + (n % 26)) + result
            n = n // 26 - 1
        return result

    def _get_column_index_from_letter(self, letter):
        result = 0
        for char in letter.upper():
            if not char.isalpha():
                raise ValueError(f"无效的列字母: {letter}")
            result = result * 26 + (ord(char) - 64)
        return result - 1

    def _get_column_letter_from_selection(self, selection):
        if not selection:
            return ""
        if " " in selection:
            return selection.split()[0]
        return selection.upper()

    def _clean_phone_number(self, phone):
        if pd.isna(phone) or phone is None:
            return ""
        
        phone_str = str(phone).strip()
        if phone_str.lower() == "nan" or phone_str == "":
            return ""
        
        try:
            if '.' in phone_str:
                float_val = float(phone_str)
                if float_val.is_integer():
                    phone_str = str(int(float_val))
        except:
            pass
        
        return phone_str

    def _clean_text_value(self, value):
        if pd.isna(value) or value is None:
            return ""
        
        value_str = str(value).strip()
        return "" if value_str.lower() == "nan" else value_str

    def load_and_preview(self):
        if not self.file_paths:
            messagebox.showwarning("未选择文件", "请先选择 Excel 文件！")
            return

        name_selection = self.name_col.get()
        phone_selection = self.phone_col.get()
        company_selection = self.company_col.get()

        if not all([name_selection, phone_selection]):
            messagebox.showwarning("映射不完整", "请至少设置姓名和电话对应的列！")
            return

        if not self.phone_separator.get():
            self.phone_separator.set("; ")

        try:
            name_letter = self._get_column_letter_from_selection(name_selection)
            phone_letter = self._get_column_letter_from_selection(phone_selection)
            company_letter = self._get_column_letter_from_selection(company_selection) if company_selection else ""
            
            all_raw_data = []
            total_files = len(self.file_paths)
            skipped_files = []
            
            for idx, filepath in enumerate(self.file_paths, 1):
                self.preview_status_label.config(text=f"读取 {idx}/{total_files}: {os.path.basename(filepath)}...")
                self.root.update()
                
                try:
                    df = pd.read_excel(filepath, header=0)
                    
                    missing_cols = []
                    for col in [name_letter, phone_letter]:
                        if col not in df.columns:
                            try:
                                col_idx = self._get_column_index_from_letter(col)
                                if col_idx >= len(df.columns):
                                    missing_cols.append(col)
                            except:
                                missing_cols.append(col)
                    
                    if company_letter and company_letter not in df.columns:
                        try:
                            col_idx = self._get_column_index_from_letter(company_letter)
                            if col_idx >= len(df.columns):
                                missing_cols.append(company_letter)
                        except:
                            missing_cols.append(company_letter)
                    
                    if missing_cols:
                        skipped_files.append(f"{os.path.basename(filepath)}")
                        continue
                    
                    name_col_name = df.columns[self._get_column_index_from_letter(name_letter)] if name_letter in df.columns else df.columns[self._get_column_index_from_letter(name_letter)]
                    phone_col_name = df.columns[self._get_column_index_from_letter(phone_letter)] if phone_letter in df.columns else df.columns[self._get_column_index_from_letter(phone_letter)]
                    company_col_name = ""
                    if company_letter:
                        company_col_name = df.columns[self._get_column_index_from_letter(company_letter)] if company_letter in df.columns else df.columns[self._get_column_index_from_letter(company_letter)]
                    
                    for _, row in df.iterrows():
                        name = self._clean_text_value(row[name_col_name])
                        phone = self._clean_phone_number(row[phone_col_name])
                        company = ""
                        if company_col_name:
                            company = self._clean_text_value(row[company_col_name])
                        
                        if self.filter_empty_name.get() and not name:
                            continue
                        if self.filter_empty_phone.get() and not phone:
                            continue
                        
                        if name:
                            all_raw_data.append({
                                "name": name,
                                "phone": phone,
                                "company": company,
                            })
                            
                except Exception as e:
                    skipped_files.append(f"{os.path.basename(filepath)}")
                    continue
            
            original_count = len(all_raw_data)
            
            if original_count == 0:
                error_msg = "没有读取到任何有效数据！"
                if skipped_files:
                    error_msg += f"\n\n跳过 {len(skipped_files)} 个文件"
                messagebox.showwarning("无数据", error_msg)
                self.preview_status_label.config(text="未读取到数据")
                self.processed_contacts = []
                self._update_preview_table()
                self.update_button_states()
                return
            
            if self.merge_duplicates.get():
                self.preview_status_label.config(text="正在合并联系人...")
                self.root.update()
                self.processed_contacts = self._merge_contacts(all_raw_data)
            else:
                self.processed_contacts = [
                    {"name": d["name"], "phone": d["phone"], "company": d["company"]} 
                    for d in all_raw_data
                ]
            
            merged_count = len(self.processed_contacts)
            stats_text = f"📊 原始 {original_count} 条"
            if self.merge_duplicates.get():
                stats_text += f" → 合并后 {merged_count} 个联系人"
            else:
                stats_text += f" → {merged_count} 个联系人"
            
            if skipped_files:
                stats_text += f"  ·  跳过 {len(skipped_files)} 个文件"
            
            self.stats_label.config(text=stats_text)
            self._update_preview_table()
            self.preview_status_label.config(text=f"✅ 加载完成，共 {merged_count} 个联系人")
            
        except Exception as e:
            messagebox.showerror("加载失败", f"处理数据时出错:\n{str(e)}")
            import traceback
            traceback.print_exc()
            self.processed_contacts = []
            self._update_preview_table()
        
        self.update_button_states()

    def _merge_contacts(self, raw_data):
        merged = defaultdict(lambda: {"phones": set(), "company": ""})
        
        total = len(raw_data)
        for idx, item in enumerate(raw_data, 1):
            if idx % 5000 == 0:
                self.preview_status_label.config(text=f"合并中... {idx}/{total}")
                self.root.update()
            
            name = item["name"]
            if item["phone"]:
                merged[name]["phones"].add(item["phone"])
            if item["company"] and not merged[name]["company"]:
                merged[name]["company"] = item["company"]
        
        result = []
        separator = self.phone_separator.get() if self.phone_separator.get() else "; "
        
        for name, data in merged.items():
            phones = sorted(list(data["phones"]))
            phone_str = separator.join(phones) if phones else ""
            result.append({
                "name": name,
                "phone": phone_str,
                "company": data["company"]
            })
        
        return result

    def _update_preview_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        if not self.processed_contacts:
            return
        
        preview_limit = 1000
        preview_data = self.processed_contacts[:preview_limit]
        
        for i, contact in enumerate(preview_data, 1):
            self.tree.insert("", "end", values=(
                i,
                contact["name"],
                contact["phone"],
                contact["company"] if contact["company"] else ""
            ))
        
        if len(self.processed_contacts) > preview_limit:
            self.preview_status_label.config(text=f"预览前{preview_limit}条，共{len(self.processed_contacts)}条")

    def on_merge_option_changed(self):
        if self.df is not None or self.file_paths:
            self.load_and_preview()

    def convert_to_vcard(self):
        if not self.processed_contacts:
            messagebox.showwarning("无数据", "没有可导出的联系人数据！")
            return

        separator = self.phone_separator.get().strip()
        if not separator:
            separator = ";"
            self.phone_separator.set(separator)

        output_dir = os.path.dirname(self.file_paths[0])
        
        if len(self.file_paths) == 1:
            base_name = os.path.splitext(os.path.basename(self.file_paths[0]))[0]
            output_path = os.path.join(output_dir, f"{base_name}_通讯录.vcf")
        else:
            timestamp = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(output_dir, f"合并通讯录_{len(self.file_paths)}个文件_{timestamp}.vcf")

        try:
            total = len(self.processed_contacts)
            batch_size = 5000
            
            with open(output_path, 'wb') as f:
                for batch_start in range(0, total, batch_size):
                    batch_end = min(batch_start + batch_size, total)
                    self.preview_status_label.config(text=f"导出中... {batch_start+1}-{batch_end}/{total}")
                    self.root.update()
                    
                    batch_content = []
                    for contact in self.processed_contacts[batch_start:batch_end]:
                        name = contact["name"].strip()
                        phone = contact["phone"].strip()
                        company = contact["company"].strip()
                        
                        card_lines = []
                        card_lines.append("BEGIN:VCARD")
                        card_lines.append("VERSION:3.0")
                        card_lines.append(f"FN:{name}")
                        card_lines.append(f"N:;{name};;;")
                        
                        if company:
                            card_lines.append(f"ORG:{company}")
                        
                        if phone:
                            phones = [p.strip() for p in phone.split(separator) if p.strip()]
                            for p in phones:
                                card_lines.append(f"TEL:{p}")
                        
                        card_lines.append("END:VCARD")
                        batch_content.append("\r\n".join(card_lines))
                    
                    batch_text = "\r\n".join(batch_content)
                    if batch_start > 0:
                        f.write(b"\r\n")
                    f.write(batch_text.encode('utf-8'))
            
            self.preview_status_label.config(text=f"✅ 导出成功！共 {total} 个联系人")
            
            if messagebox.askyesno("导出成功", 
                                  f"已生成文件:\n{output_path}\n\n共导出 {total} 个联系人\n\n是否打开所在文件夹？"):
                self.open_folder(output_dir)
                
        except Exception as e:
            messagebox.showerror("导出失败", f"发生错误:\n{str(e)}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    if USE_DND:
        root = TkinterDnD.Tk()
    else:
        root = tk.Tk()
    app = ExcelToVCardApp(root)
    root.mainloop()