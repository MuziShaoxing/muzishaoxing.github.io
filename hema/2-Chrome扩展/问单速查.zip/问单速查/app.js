(function() {
    const $ = (sel) => document.querySelector(sel);
    const guideOverlay = $('#guideOverlay');
    const guideCard = $('#guideCard');
    const hiddenFileInput = $('#hiddenFileInput');

    // ===== 防刷新确认弹窗 =====
    const refreshOverlay = $('#refreshConfirmOverlay');
    let refreshPending = false;
    function showRefreshConfirm() {
        refreshOverlay.classList.add('active');
        refreshPending = true;
        // 强制聚焦到取消按钮，确保回车=取消
        const cancelBtn = $('#refreshCancelBtn');
        cancelBtn.focus();
        cancelBtn.style.outline = '2px solid #4a90d9';
    }
    function hideRefreshConfirm() {
        refreshOverlay.classList.remove('active');
        refreshPending = false;
    }
    function doRefresh() { location.reload(); }
    $('#refreshCancelBtn').addEventListener('click', hideRefreshConfirm);
    $('#refreshOkBtn').addEventListener('click', doRefresh);
    // 点击遮罩层取消
    refreshOverlay.addEventListener('click', (e) => { if (e.target === refreshOverlay) hideRefreshConfirm(); });
    // 弹窗内键盘拦截：回车=取消，空格不触发任何按钮
    refreshOverlay.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); hideRefreshConfirm(); }
        if (e.key === ' ') { e.preventDefault(); e.stopPropagation(); }
    });
    // 全局拦截：弹窗打开时回车一律取消，同时拦截 F5 / Ctrl+R
    document.addEventListener('keydown', (e) => {
        if (refreshPending) {
            if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); hideRefreshConfirm(); return; }
            e.preventDefault();
            return;
        }
        const isF5 = e.key === 'F5' || e.keyCode === 116;
        const isCtrlR = (e.ctrlKey || e.metaKey) && e.key === 'r';
        if (isF5 || isCtrlR) {
            e.preventDefault();
            showRefreshConfirm();
        }
    });
// ===== beforeunload：延迟到用户首次交互后绑定 =====
// Chrome 60+ 要求页面必须有过用户手势（click / keydown / input 等），
// 否则 beforeunload 确认框会被拦截（控制台出现 "Blocked attempt..." 提示）。
// 因此这里改为：用户首次交互后才注册监听器，确保确认框在真正需要时能够正常显示。

let beforeUnloadReady = false;

function setupBeforeUnload() {
    if (beforeUnloadReady) return;
    beforeUnloadReady = true;

    window.addEventListener('beforeunload', (e) => {
        // 仅在确实存在未保存数据时触发确认框
        // responsibilityReasonMap 非空，说明用户已经编辑过“核实原因”
        if (responsibilityReasonMap.size > 0) {
            e.preventDefault();
            e.returnValue = '';
        }
    });
}

// 监听首次用户交互，交互发生后立即注册 beforeunload
['click', 'keydown', 'input', 'touchstart'].forEach(evt => {
    document.addEventListener(evt, function handler() {
        setupBeforeUnload();
        // 一次性监听：注册 beforeunload 后立即移除这些引导监听器
        ['click', 'keydown', 'input', 'touchstart'].forEach(e =>
            document.removeEventListener(e, handler)
        );
    }, { once: true });
});

    let allData = [], badReviewData = [], coldThawData = [], logisticsDamageData = [];
    let filteredData = [], filteredBadReviewData = [], filteredColdThawData = [], filteredLogisticsDamageData = [];
    let selectedStore = null;
    let selectedReasons = new Set();
    let currentView = 'default';
    let pageSize = 20;
    let viewCurrentPages = { default: 1, badReview: 1, coldThaw: 1, logistics: 1 };
    let allStores = [];
    let manualDataMap = new Map();
    let badReviewManualMap = new Map();
    let coldThawManualMap = new Map();
    let logisticsManualMap = new Map();
    let responsibilityReasonMap = new Map();
    let rowIdCounter = 0;
    let duplicateBatchSet = new Set();
    let pickingBatchCounts = new Map(); // 拣货不完全批次计数
    let defaultNoRespRowIds = new Set(); // 数据生成时默认无责的行ID（用于后置排序）
    let currentPopup = null;
    let toastTimer;
    let previewUrls = [], previewIdx = 0;

    // 数据展示工作簿相关数据
    let dataDisplayWorkbook = null; // 存储"数据展示"工作簿
    let achievementCategories = []; // 问单类目名列表
    let shengxianLimits = {}; // 生鲜店标准上限
    let qianzhicangLimits = {}; // 前置仓标准上限
    let storeAchievements = {}; // 门店达成数据

    const TARGET_SHEET_KEYWORDS = ['问单速查','问单'];
    const TOOL_DISPLAY_NAME = '问单速查'; // 工具显示名称，用于页面标题和导出报告
    const TOOL_VERSION = 'WD1.0'; // 工具版本号
    const DATA_DISPLAY_KEYWORDS = ['数据展示'];
    const BAD_REVIEW_KEYWORDS = ['差评'];
    const IGNORE_KEYWORDS = ['sheet','数据源','汇总','模板','参数','配置','说明','备份','临时','测试'];

    // 初始化页面标题
    document.getElementById('pageTitle').textContent = TOOL_DISPLAY_NAME;
    document.getElementById('pageVersion').textContent = TOOL_VERSION;

    function findSheet(sheets, keywords) {
        for (let kw of keywords) {
            const exact = sheets.find(s => s.trim() === kw);
            if (exact) return exact;
        }
        for (let kw of keywords) {
            const fuzzy = sheets.find(s => s.trim().includes(kw));
            if (fuzzy) return fuzzy;
        }
        return null;
    }

    function shouldIgnore(sheetName) {
        const name = sheetName.trim().toLowerCase();
        for (let kw of IGNORE_KEYWORDS) if (name.includes(kw.toLowerCase())) return true;
        return false;
    }

    function getColValue(row, col) {
        if (row.hasOwnProperty(col)) return row[col];
        for (let k of Object.keys(row)) if (k.trim() === col.trim()) return row[k];
        return '';
    }

    function getXSpaceNote(row) {
        return getColValue(row, 'xspace退款工单备注') || getColValue(row, 'XSpace退款工单备注') || getColValue(row, 'XSPACE退款工单备注') || '';
    }

    function getAppRefundDesc(row) {
        const cols = ['app退款描述', 'APP退款描述', 'xspace退款工单备注', 'XSpace工单备注', 'XSPACE工单备注', 'sr评价内容', 'SR评价内容'];
        const values = [];
        cols.forEach(col => {
            const v = String(getColValue(row, col) || '').trim();
            if (v && v !== '-') values.push(v);
        });
        let joined = values.join(' ');
        if (!joined) return '';
        const dashCount = (joined.match(/-/g) || []).length;
        if (dashCount > 1) {
            joined = joined.replace(/-/g, '').trim();
        }
        return joined;
    }

    // 判断签收时间是否晚于最晚送达时间
    function isDeliveryLate(row) {
        const latestStr = String(getColValue(row, '最晚送达时间') || '').trim();
        const signedStr = String(getColValue(row, '签收时间') || '').trim();
        const latest = parseDateTime(latestStr);
        const signed = parseDateTime(signedStr);
        if (!latest || !signed) return false;
        return signed > latest;
    }

    function getDefaultVerifyReason(row) {
        const note = String(getXSpaceNote(row)).trim();
        if (note === '拒签退款') return '上报漏发';
        if (note === '缺货退款') return '门店缺货';
        const reason = (getColValue(row, '问题原因名称') || '').trim();
        if (reason === '拣货不完全') {
            const batch = String(getColValue(row, '批次号') || '').trim();
            const batchCount = batch ? (pickingBatchCounts.get(batch) || 0) : 0;
            if (batchCount > 1) return ''; // 重复批次，有责无备注
            return '门店漏发';
        }
        if (reason === '履约超时') {
            return isDeliveryLate(row) ? '配送超时' : '正常时效送达';
        }
        return '';
    }

    function getDefaultIsResponsible(row) {
        const note = String(getXSpaceNote(row)).trim();
        if (note === '缺货退款' || note === '拒签退款') return '无责';
        const reason = (getColValue(row, '问题原因名称') || '').trim();
        if (reason === '拣货不完全') {
            const batch = String(getColValue(row, '批次号') || '').trim();
            const batchCount = batch ? (pickingBatchCounts.get(batch) || 0) : 0;
            if (batchCount > 1) return '有责'; // 重复批次，有责
            return '无责';
        }
        if (reason === '履约超时') {
            return isDeliveryLate(row) ? '有责' : '无责';
        }
        return '有责';
    }

    function sortDefaultData(data) {
        const reasonCounts = new Map();
        data.forEach(r => {
            const reason = (getColValue(r, '问题原因名称') || '').trim();
            reasonCounts.set(reason, (reasonCounts.get(reason) || 0) + 1);
        });
        const batchCounts = new Map();
        data.forEach(r => {
            const batch = String(getColValue(r, '批次号') || '').trim();
            if (batch) batchCounts.set(batch, (batchCounts.get(batch) || 0) + 1);
        });
        data.sort((a, b) => {
            // 默认无责后置：数据生成时默认为无责的行排到最后，方便优先处理有责
            const aIsDefaultNoResp = defaultNoRespRowIds.has(a._rowId);
            const bIsDefaultNoResp = defaultNoRespRowIds.has(b._rowId);
            if (aIsDefaultNoResp !== bIsDefaultNoResp) return aIsDefaultNoResp ? 1 : -1;

            const aBatch = String(getColValue(a, '批次号') || '').trim();
            const bBatch = String(getColValue(b, '批次号') || '').trim();
            if (!aBatch && bBatch) return 1;
            if (aBatch && !bBatch) return -1;
            if (aBatch !== bBatch) {
                const aBatchCount = batchCounts.get(aBatch) || 0;
                const bBatchCount = batchCounts.get(bBatch) || 0;
                if (aBatchCount !== bBatchCount) return bBatchCount - aBatchCount;
                return aBatch.localeCompare(bBatch);
            }
            const aReason = (getColValue(a, '问题原因名称') || '').trim();
            const bReason = (getColValue(b, '问题原因名称') || '').trim();
            const aReasonCount = reasonCounts.get(aReason) || 0;
            const bReasonCount = reasonCounts.get(bReason) || 0;
            if (aReasonCount !== bReasonCount) return aReasonCount - bReasonCount;
            const aAppReason = (getColValue(a, 'app退款原因') || getColValue(a, 'APP退款原因') || '').trim();
            const aAppDesc = getAppRefundDesc(a);
            const bAppReason = (getColValue(b, 'app退款原因') || getColValue(b, 'APP退款原因') || '').trim();
            const bAppDesc = getAppRefundDesc(b);
            const aIsDash = (aAppReason === '-' || aAppReason === '') && !aAppDesc;
            const bIsDash = (bAppReason === '-' || bAppReason === '') && !bAppDesc;
            if (aIsDash !== bIsDash) return aIsDash ? 1 : -1;
            return 0;
        });
        return data;
    }

    function toast(msg) {
        const t = $('#toast');
        clearTimeout(toastTimer);
        t.textContent = msg; t.style.display = 'block'; t.style.animation = 'none';
        void t.offsetWidth;
        t.style.animation = 'toastIn 0.4s ease, toastOut 0.4s ease 1.8s forwards';
        toastTimer = setTimeout(() => t.style.display = 'none', 2300);
    }

    // 居中确认弹窗
    function showConfirmDialog(message) {
        return new Promise((resolve) => {
            const overlay = document.createElement('div');
            overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.4);z-index:10000;display:flex;align-items:center;justify-content:center;';
            const dialog = document.createElement('div');
            dialog.style.cssText = 'background:#fff;border-radius:16px;padding:28px 32px;max-width:420px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.18);text-align:center;';
            dialog.innerHTML = `
                <div style="font-size:15px;font-weight:600;color:#1a1a2e;margin-bottom:18px;line-height:1.6;">${message}</div>
                <div style="display:flex;gap:12px;justify-content:center;">
                    <button id="confirmNo" style="padding:8px 24px;border-radius:10px;border:1.5px solid #d5dcff;background:#f0f3ff;color:#4f6ef7;font-size:14px;font-weight:600;cursor:pointer;transition:all 0.2s;">否</button>
                    <button id="confirmYes" style="padding:8px 24px;border-radius:10px;border:none;background:linear-gradient(135deg,#4f6ef7,#6c5ce7);color:#fff;font-size:14px;font-weight:600;cursor:pointer;transition:all 0.2s;">是</button>
                </div>
            `;
            overlay.appendChild(dialog);
            document.body.appendChild(overlay);
            dialog.querySelector('#confirmYes').addEventListener('click', () => { document.body.removeChild(overlay); resolve(true); });
            dialog.querySelector('#confirmNo').addEventListener('click', () => { document.body.removeChild(overlay); resolve(false); });
            overlay.addEventListener('click', (e) => { if (e.target === overlay) { document.body.removeChild(overlay); resolve(false); } });
        });
    }

    function escapeHTML(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

    // 判断门店类型
    function getStoreType(storeName) {
        if (!storeName) return 'shengxian';
        return storeName.includes('前置仓') ? 'qianzhicang' : 'shengxian';
    }

    function getStoreTypeLabel(storeType) {
        return storeType === 'qianzhicang' ? '前置仓' : '生鲜店';
    }

    function getStoreTypeClass(storeType) {
        return storeType === 'qianzhicang' ? 'qianzhicang' : 'shengxian';
    }

    // parseDateTime 辅助函数
    function parseDateTime(str) {
        if (!str) return null;
        const s = String(str).trim();
        if (!s || s === '-' || s === '/') return null;
        // 支持 YYYYMMDD 纯数字文本格式（如 20260811）
        const ymd = s.match(/^(\d{4})(\d{2})(\d{2})$/);
        if (ymd) {
            const d2 = new Date(parseInt(ymd[1]), parseInt(ymd[2])-1, parseInt(ymd[3]));
            if (!isNaN(d2.getTime())) return d2;
        }
        // 支持整数和小数Excel序列号（如46183.74715）
        if (/^\d+(\.\d+)?$/.test(s)) {
            const num = parseFloat(s);
            if (num > 40000 && num < 60000) {
                return new Date((num - 25569) * 86400 * 1000);
            }
        }
        // 支持 yyyy-mm-dd / yyyy/m/d 及带时分秒格式
        const m = s.match(/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})(?:[\sT]+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
        if (m) {
            const d3 = new Date(parseInt(m[1]), parseInt(m[2])-1, parseInt(m[3]), parseInt(m[4]||0), parseInt(m[5]||0), parseInt(m[6]||0));
            if (!isNaN(d3.getTime())) return d3;
        }
        // 兜底：标准日期解析
        const d = new Date(s);
        if (!isNaN(d.getTime())) return d;
        return null;
    }

    // 解析数据展示工作簿
    function parseDataDisplaySheet(wb) {
        const sheetName = findSheet(wb.SheetNames, DATA_DISPLAY_KEYWORDS);
        if (!sheetName) {
            console.log('未找到数据展示工作簿');
            return false;
        }

        const sheet = wb.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: true });
        
        if (!jsonData || jsonData.length < 4) {
            console.log('数据展示工作簿数据不足');
            return false;
        }

        // 解析结构（行位置动态检测，避免表格迭代后行数不固定）
        // A列值为"类目"的行是问单类目名行（从B列开始是类目名）
        // A列值为"目标"的行按出现顺序：第1个是生鲜店标准上限百分比，第2个是前置仓标准上限百分比
        // 类目读取到"虚假拒收"为止
        // B列(index=1)从门店数据起始行开始是门店名
        // 每个门店行中各列是对应类目的达成百分比

        achievementCategories = [];
        shengxianLimits = {};
        qianzhicangLimits = {};
        storeAchievements = {};

        // 动态定位关键行
        let categoryRowIdx = -1;      // 类目名行
        const targetRowIdxs = [];     // "目标"行索引，依次为生鲜店、前置仓
        for (let r = 0; r < jsonData.length; r++) {
            const firstCol = String((jsonData[r] || [])[0] || '').trim();
            if (categoryRowIdx === -1 && firstCol === '类目') {
                categoryRowIdx = r;
            } else if (firstCol === '目标') {
                targetRowIdxs.push(r);
            }
        }

        const row4 = jsonData[categoryRowIdx] || [];      // 类目名行
        const row5 = jsonData[targetRowIdxs[0]] || [];    // 生鲜店上限行（第1个"目标"）
        const row44 = jsonData[targetRowIdxs[1]] || [];   // 前置仓上限行（第2个"目标"）

        // 读取类目名（从B列index=1开始，到"虚假拒收"为止）
        for (let colIdx = 1; colIdx < row4.length; colIdx++) {
            const categoryName = String(row4[colIdx] || '').trim();
            if (!categoryName) continue;
            const catIndex = achievementCategories.length; // 当前类目的索引（0-based）
            let sxLimit = parseFloat(row5[colIdx]) || 0;
            let qzcLimit = parseFloat(row44[colIdx]) || 0;
            // 百分比列（第1、4~12列，即index 0, 3~11），第8列(index 7)使用原始值，不乘
            if (catIndex === 0 || (catIndex >= 3 && catIndex <= 11)) {
                if (catIndex !== 7) {
                    sxLimit = sxLimit * 100;
                    qzcLimit = qzcLimit * 100;
                }
            }
            if (categoryName === '虚假拒收') {
                achievementCategories.push(categoryName);
                shengxianLimits[categoryName] = sxLimit;
                qianzhicangLimits[categoryName] = qzcLimit;
                break; // 读取到"虚假拒收"为止
            }
            achievementCategories.push(categoryName);
            shengxianLimits[categoryName] = sxLimit;
            qianzhicangLimits[categoryName] = qzcLimit;
        }

        // 读取门店数据（从第6行index=5开始，B列index=1）
        for (let rowIdx = 5; rowIdx < jsonData.length; rowIdx++) {
            const row = jsonData[rowIdx];
            if (!row || row.length < 2) continue;
            
            const storeName = String(row[1] || '').trim();
            if (!storeName) continue;

            const storeType = getStoreType(storeName);
            const achievements = {};

            for (let i = 0; i < achievementCategories.length; i++) {
                const colIdx = i + 2; // B列(index=1)是门店名，C列(index=2)开始才是达成数据
                const category = achievementCategories[i];
                let value = parseFloat(row[colIdx]) || 0;
                // 百分比列（第1、4~12列，即index 0, 3~11），第8列(index 7)使用原始值，不乘
                if (i === 0 || (i >= 3 && i <= 11)) {
                    if (i !== 7) {
                        value = value * 100;
                    }
                }
                achievements[category] = value;
            }

            storeAchievements[storeName] = {
                type: storeType,
                achievements: achievements
            };
        }

        console.log('数据展示工作簿解析完成:', {
            categories: achievementCategories,
            storeCount: Object.keys(storeAchievements).length
        });

        return true;
    }

    // 格式化达成值：第2、3列(index 1,2)显示小数2位，第8列(index 7)显示小数3位，其他列显示百分比3位小数
    function formatAchievementValue(value, category, catIndex) {
        if (catIndex === 1 || catIndex === 2) {
            return value.toFixed(2);
        }
        if (catIndex === 7) {
            return value.toFixed(3);
        }
        return value.toFixed(3) + '%';
    }
    // 格式化上限值：第2、3列(index 1,2)显示小数2位，第8列(index 7)显示小数3位，其他列显示百分比3位小数
    function formatLimitValue(value, category, catIndex) {
        if (catIndex === 1 || catIndex === 2) {
            return value.toFixed(2);
        }
        if (catIndex === 7) {
            return value.toFixed(3);
        }
        return value.toFixed(3) + '%';
    }

    // 渲染问单达成展示区
    function renderAchievementPanel() {
        const panel = $('#achievementPanel');
        const grid = $('#achievementGrid');

        if (!selectedStore || !storeAchievements[selectedStore]) {
            panel.style.display = 'none';
            return;
        }

        const storeData = storeAchievements[selectedStore];
        const storeType = storeData.type;
        const limits = storeType === 'qianzhicang' ? qianzhicangLimits : shengxianLimits;
        const achievements = storeData.achievements;

        let html = '';
        achievementCategories.forEach((category, catIndex) => {
            const actualValue = achievements[category] || 0;
            const limitValue = limits[category] || 0;
            const displayValue = formatAchievementValue(actualValue, category, catIndex);
            const displayLimit = formatLimitValue(limitValue, category, catIndex);

            // 颜色调度逻辑：超标红色，=0灰色，其他绿色
            let statusClass = 'normal';
            
            if (limitValue > 0 && actualValue > limitValue) {
                // 超标：红色
                statusClass = 'danger';
            } else if (actualValue === 0) {
                // 等于0：灰色
                statusClass = 'zero';
            } else {
                // 其他：绿色
                statusClass = 'normal';
            }

            html += `
                <div class="achievement-item">
                    <div class="achievement-item-name" title="${escapeHTML(category)}">${escapeHTML(category)}</div>
                    <div class="achievement-item-value ${statusClass}">${displayValue}</div>
                    <div class="achievement-item-limit">上限: ${displayLimit}</div>
                </div>
            `;
        });

        grid.innerHTML = html;
        panel.style.display = 'block';
    }

    // 渲染责任分析面板
    function renderResponsibilityPanel() {
        const panel = $('#responsibilityPanel');
        const content = $('#responsibilityContent');

        // 收集当前门店的所有数据
        const allViewData = [];

        // 问单数据（排除冷链商品化冻和物流损）
        const defaultData = allData.filter(r => {
            const reason = (getColValue(r,'问题原因名称')||'').trim();
            return reason !== '冷链商品化冻' && reason !== '物流损';
        });
        if (selectedStore) {
            defaultData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore).forEach(r => allViewData.push(r));
        } else {
            defaultData.forEach(r => allViewData.push(r));
        }

        // 冷链数据
        if (selectedStore) {
            coldThawData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore).forEach(r => allViewData.push(r));
        } else {
            coldThawData.forEach(r => allViewData.push(r));
        }

        // 物流损数据
        if (selectedStore) {
            logisticsDamageData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore).forEach(r => allViewData.push(r));
        } else {
            logisticsDamageData.forEach(r => allViewData.push(r));
        }

        // 差评数据
        if (selectedStore) {
            badReviewData.filter(r => String(getColValue(r,'门店')||'').trim() === selectedStore).forEach(r => allViewData.push(r));
        } else {
            badReviewData.forEach(r => allViewData.push(r));
        }

        if (!allViewData.length) {
            panel.style.display = 'none';
            return;
        }

        // 统计各类数据
        let totalNoResp = 0, totalResp = 0;
        let coldNoResp = 0, coldResp = 0;
        let logisticsNoResp = 0, logisticsResp = 0;
        let badReviewNoResp = 0, badReviewResp = 0;

        allViewData.forEach(row => {
            const map = badReviewData.includes(row) ? badReviewManualMap :
                        coldThawData.includes(row) ? coldThawManualMap :
                        logisticsDamageData.includes(row) ? logisticsManualMap : manualDataMap;
            const saved = map.get(row._rowId) || {};
            const isResponsible = saved.isResponsible || '有责';
            const isResp = isResponsible === '有责';

            if (isResp) totalResp++; else totalNoResp++;

            if (badReviewData.includes(row)) {
                if (isResp) badReviewResp++; else badReviewNoResp++;
            } else if (coldThawData.includes(row)) {
                if (isResp) coldResp++; else coldNoResp++;
            } else if (logisticsDamageData.includes(row)) {
                if (isResp) logisticsResp++; else logisticsNoResp++;
            }
        });

        // 计算有责率及颜色
        const calcRate = (noResp, resp) => {
            const total = noResp + resp;
            const rate = total > 0 ? (resp / total * 100) : 0;
            const rateStr = rate.toFixed(1) + '%';
            let color = '#27ae60';
            if (rate >= 50) color = '#e74c3c';
            else if (rate >= 30) color = '#f39c12';
            return { rateStr, color };
        };

        // 构建汇总行HTML
        let summaryHTML = '<div style="background:#f0f2f7;border-radius:8px;padding:10px;margin-bottom:10px;border:1px solid #e6e8f0;">';
        summaryHTML += '<div style="display:flex;flex-wrap:wrap;gap:8px;">';
        const totalAll = totalNoResp + totalResp;
        const totalRate = calcRate(totalNoResp, totalResp);
        summaryHTML += `<div style="flex:1;text-align:center;padding:6px;background:#fff;border-radius:6px;border:1px solid #e6e8f0;"><div style="font-size:11px;color:#5c5c78;">整体有责率</div><div style="font-size:16px;font-weight:700;color:${totalRate.color};">${totalRate.rateStr}</div><div style="font-size:10px;color:#8b8ba8;">(${totalResp}/${totalAll})</div></div>`;
        const coldTotal = coldNoResp + coldResp;
        const coldRate = calcRate(coldNoResp, coldResp);
        summaryHTML += `<div style="flex:1;text-align:center;padding:6px;background:#fff;border-radius:6px;border:1px solid #e6e8f0;"><div style="font-size:11px;color:#5c5c78;">冷链化冻</div><div style="font-size:16px;font-weight:700;color:${coldRate.color};">${coldRate.rateStr}</div><div style="font-size:10px;color:#8b8ba8;">(${coldResp}/${coldTotal})</div></div>`;
        const logisticsTotal = logisticsNoResp + logisticsResp;
        const logisticsRate = calcRate(logisticsNoResp, logisticsResp);
        summaryHTML += `<div style="flex:1;text-align:center;padding:6px;background:#fff;border-radius:6px;border:1px solid #e6e8f0;"><div style="font-size:11px;color:#5c5c78;">物流损</div><div style="font-size:16px;font-weight:700;color:${logisticsRate.color};">${logisticsRate.rateStr}</div><div style="font-size:10px;color:#8b8ba8;">(${logisticsResp}/${logisticsTotal})</div></div>`;
        const badReviewTotal = badReviewNoResp + badReviewResp;
        const badReviewRate = calcRate(badReviewNoResp, badReviewResp);
        summaryHTML += `<div style="flex:1;text-align:center;padding:6px;background:#fff;border-radius:6px;border:1px solid #e6e8f0;"><div style="font-size:11px;color:#5c5c78;">差评</div><div style="font-size:16px;font-weight:700;color:${badReviewRate.color};">${badReviewRate.rateStr}</div><div style="font-size:10px;color:#8b8ba8;">(${badReviewResp}/${badReviewTotal})</div></div>`;
        summaryHTML += '</div></div>';

        // 按问题原因名称统计
        const stats = new Map();
        // 收集每个问题原因下各条目的核实原因（用于动态默认值）
        const reasonTextMap = new Map(); // reasonName -> Map<核实原因文本, 出现次数>
        allViewData.forEach(row => {
            let reason = '';
            if (badReviewData.includes(row)) {
                const tag = (getColValue(row, '评价标签') || '').trim().replace(/^\d+[:：]/, '') || '';
                reason = tag ? '差评-' + tag : '差评';
            } else {
                reason = (getColValue(row, '问题原因名称') || '').trim() || '未知';
            }
            const map = badReviewData.includes(row) ? badReviewManualMap :
                        coldThawData.includes(row) ? coldThawManualMap :
                        logisticsDamageData.includes(row) ? logisticsManualMap : manualDataMap;
            const saved = map.get(row._rowId) || {};
            const isResponsible = saved.isResponsible || '有责';
            if (!stats.has(reason)) stats.set(reason, { name: reason, noResponsible: 0, responsible: 0 });
            const s = stats.get(reason);
            if (isResponsible === '有责') s.responsible++; else s.noResponsible++;

            // 收集该条目的核实原因文本
            const reasonKey = badReviewData.includes(row) ? 'verify' :
                              coldThawData.includes(row) ? 'verifyReason' : 'reason';
            const reasonText = (saved[reasonKey] || '').trim();
            if (reasonText) {
                if (!reasonTextMap.has(reason)) reasonTextMap.set(reason, new Map());
                const rMap = reasonTextMap.get(reason);
                rMap.set(reasonText, (rMap.get(reasonText) || 0) + 1);
            }
        });

        // 排序
        const sortOrder = { '冷链商品化冻': 0, '物流损': 1 };
        const sortedStats = [...stats.values()].sort((a, b) => {
            const aOrder = sortOrder[a.name] !== undefined ? sortOrder[a.name] : (a.name.startsWith('差评') ? 999 : 2);
            const bOrder = sortOrder[b.name] !== undefined ? sortOrder[b.name] : (b.name.startsWith('差评') ? 999 : 2);
            if (aOrder !== bOrder) return aOrder - bOrder;
            const aTotal = a.noResponsible + a.responsible;
            const bTotal = b.noResponsible + b.responsible;
            return bTotal - aTotal;
        });

        // 构建表格HTML - 使用table-fit-container容器
        let tableHTML = '<div class="table-fit-container"><table class="responsibility-table"><thead><tr><th>问题原因名称</th><th>总计</th><th>无责</th><th>有责</th><th>有责率</th><th>核实原因</th></tr></thead><tbody>';
        sortedStats.forEach(s => {
            const total = s.noResponsible + s.responsible;
            const rate = total > 0 ? (s.responsible / total * 100) : 0;
            const rateStr = rate.toFixed(1) + '%';
            let rateColor = '#27ae60';
            if (rate >= 50) rateColor = '#e74c3c';
            else if (rate >= 30) rateColor = '#f39c12';
            // 动态生成核实原因默认值：统计问单明细中各条目的核实原因
            let savedReason = responsibilityReasonMap.get(s.name) || '';
            if (!savedReason) {
                const rTextMap = reasonTextMap.get(s.name);
                if (rTextMap && rTextMap.size > 0) {
                    // 按出现次数降序排列
                    const sortedReasons = [...rTextMap.entries()].sort((a, b) => b[1] - a[1]);
                    savedReason = sortedReasons.map(([text, count]) => text + '*' + count).join('\n');
                }
            }
            const isBadReview = s.name.startsWith('差评');
            const nameStyle = isBadReview ? 'color:#e74c3c;font-weight:700;' : '';
            // 判断是用户手动值还是动态默认值
            const isUserSaved = responsibilityReasonMap.has(s.name);
            const inputClass = isUserSaved ? 'responsibility-input user-value' : 'responsibility-input placeholder-default';
            // 工具界面显示值：\n替换为逗号，避免换行撑开页面
            const inputValue = (isUserSaved ? savedReason : (savedReason || '')).replace(/\n/g, '，');
            // data-default-value 保留\n，供导出图片使用
            const dynamicDefault = savedReason || '';
            tableHTML += `<tr><td style="${nameStyle}">${escapeHTML(s.name)}</td><td>${total}</td><td>${s.noResponsible}</td><td>${s.responsible}</td><td style="color:${rateColor};font-weight:700;">${rateStr}</td><td><input class="${inputClass}" data-reason="${escapeHTML(s.name)}" data-default-value="${escapeHTML(dynamicDefault)}" value="${escapeHTML(inputValue)}" placeholder="输入核实原因" /></td></tr>`;
        });
        tableHTML += '</tbody></table></div>';

        content.innerHTML = summaryHTML + tableHTML;

        // 监听输入框变化
        content.querySelectorAll('.responsibility-input').forEach(inp => {
            // 聚焦时如果是placeholder默认值，自动清空并切换为正常输入模式
            inp.addEventListener('focus', function() {
                if (this.classList.contains('placeholder-default')) {
                    this.classList.remove('placeholder-default');
                    this.value = '';
                }
            });
            inp.addEventListener('input', function() {
                if (this.value.trim()) {
                    this.classList.add('user-value');
                    this.classList.remove('placeholder-default');
                    responsibilityReasonMap.set(this.dataset.reason, this.value);
                } else {
                    this.classList.remove('user-value');
                    responsibilityReasonMap.delete(this.dataset.reason);
                }
            });
            // 失焦时如果为空，从 data-default-value 恢复默认值（显示用逗号）
            inp.addEventListener('blur', function() {
                if (!this.value.trim() && this.dataset.defaultValue) {
                    this.value = this.dataset.defaultValue.replace(/\n/g, '，');
                    this.classList.add('placeholder-default');
                    this.classList.remove('user-value');
                }
            });
        });
        panel.style.display = 'block';
    }

    function openGuideView(title, subtitle, bodyHTML, footerHTML) {
        guideCard.innerHTML = `
            <button class="guide-close-btn" id="guideCloseBtn">✕</button>
            <div class="guide-title">${title}</div>
            <div class="guide-subtitle">${subtitle}</div>
            <div class="guide-body">${bodyHTML}</div>
            <div class="guide-footer">${footerHTML}</div>
        `;
        guideOverlay.style.display = 'flex';
        document.getElementById('guideCloseBtn').addEventListener('click', () => guideOverlay.style.display = 'none');
    }

    function showStoreSelection() {
        let html = `<input type="text" id="storeSearch" placeholder="🔍 搜索门店..." style="width:100%;padding:10px;border:1.5px solid #e6e8f0;border-radius:8px;margin-bottom:12px;font-size:0.82rem;"><div id="storeList" style="max-height:300px;overflow-y:auto;display:flex;flex-direction:column;">`;
        html += `<label style="display:flex;align-items:center;gap:8px;padding:9px 12px;cursor:pointer;border-radius:8px;" id="storeOptionAll"><input type="radio" name="storeRadio" value="__ALL__" ${selectedStore===null?'checked':''}> 🌐 全部门店</label>`;
        allStores.forEach(s => {
            const storeType = getStoreType(s);
            const typeLabel = getStoreTypeLabel(storeType);
            const typeClass = getStoreTypeClass(storeType);
            html += `<label style="display:flex;align-items:center;gap:8px;padding:9px 12px;cursor:pointer;border-radius:8px;"><input type="radio" name="storeRadio" value="${escapeHTML(s)}" ${selectedStore===s?'checked':''}> ${escapeHTML(s)}<span class="store-type-tag ${typeClass}">${typeLabel}</span></label>`;
        });
        html += `</div>`;
        openGuideView('选择门店', '请选择要分析的门店', html, '<button class="guide-btn primary" id="confirmStore">✓ 确认</button>');
        // 默认聚焦搜索框
        const searchInput = document.getElementById('storeSearch');
        setTimeout(() => searchInput.focus(), 50);
        // 搜索框回车：有输入选第一个匹配项，无输入选全部门店
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                e.stopPropagation();
                const term = this.value.trim();
                const labels = document.querySelectorAll('#storeList label[style*="flex"]');
                let target = null;
                if (term) {
                    for (const l of labels) {
                        if (l.textContent.toLowerCase().includes(term.toLowerCase())) { target = l.querySelector('input'); break; }
                    }
                } else {
                    target = document.querySelector('#storeOptionAll input');
                }
                if (target) { target.checked = true; }
                const radio = document.querySelector('input[name="storeRadio"]:checked');
                selectedStore = radio && radio.value !== '__ALL__' ? radio.value : null;
                guideOverlay.style.display = 'none';
                initializeMainUI();
            }
        });
        document.getElementById('confirmStore').addEventListener('click', () => {
            const radio = document.querySelector('input[name="storeRadio"]:checked');
            selectedStore = radio && radio.value !== '__ALL__' ? radio.value : null;
            guideOverlay.style.display = 'none';
            initializeMainUI();
        });
        document.getElementById('storeSearch').addEventListener('input', function() {
            const term = this.value.toLowerCase();
            document.querySelectorAll('#storeList label').forEach(l => l.style.display = l.textContent.toLowerCase().includes(term) ? 'flex' : 'none');
        });
    }

    async function handleFileUpload(file) {
        if (!file) return;

        // 显示进度条
        const progressWrap = document.getElementById('guideProgressWrap') || document.getElementById('initProgressWrap');
        const progressFill = document.getElementById('guideProgressFill') || document.getElementById('initProgressFill');
        const progressText = document.getElementById('guideProgressText') || document.getElementById('initProgressText');
        if (progressWrap) { progressWrap.style.display = 'block'; }
        if (progressFill) { progressFill.style.width = '5%'; }
        if (progressText) { progressText.textContent = '正在读取文件...'; }

        toast('⏳ 正在解析文件...');
        const reader = new FileReader();
        reader.onload = async function(e) {
            try {
                if (progressFill) progressFill.style.width = '15%';
                if (progressText) progressText.textContent = '正在解析Excel...';

                const wb = XLSX.read(new Uint8Array(e.target.result), { type:'array' });
                const targetSheets = wb.SheetNames.filter(s => !shouldIgnore(s));
                const mainSheetName = findSheet(targetSheets, TARGET_SHEET_KEYWORDS);
                const badReviewSheetName = findSheet(targetSheets, BAD_REVIEW_KEYWORDS);
                if (!mainSheetName) { toast('❌ 未找到「问单速查」工作簿'); if (progressWrap) progressWrap.style.display = 'none'; return; }

                if (progressFill) progressFill.style.width = '30%';
                if (progressText) progressText.textContent = '正在解析数据展示...';

                // 解析数据展示工作簿
                parseDataDisplaySheet(wb);

                if (progressFill) progressFill.style.width = '40%';
                if (progressText) progressText.textContent = '正在加载问单速查...';

                const rows = XLSX.utils.sheet_to_json(wb.Sheets[mainSheetName], { defval:'', raw:false });
                if (!rows.length) { toast('❌ 工作簿为空'); if (progressWrap) progressWrap.style.display = 'none'; return; }

                allData = []; manualDataMap.clear();
                pickingBatchCounts.clear();
                defaultNoRespRowIds.clear();
                const batchSize = 5000;
                const totalRows = rows.length;
                // 第一遍：收集所有数据
                for (let i = 0; i < rows.length; i += batchSize) {
                    const batch = rows.slice(i, i + batchSize);
                    batch.forEach(r => {
                        const nr = {};
                        for (let k in r) nr[k.trim()] = r[k];
                        nr._rowId = rowIdCounter++;
                        allData.push(nr);
                    });
                    // 更新进度
                    const pct = 40 + Math.round(((i + batch.length) / totalRows) * 25);
                    if (progressFill) progressFill.style.width = pct + '%';
                    if (progressText) progressText.textContent = `正在处理数据... ${Math.min(100, pct)}%`;
                    await new Promise(resolve => setTimeout(resolve, 0));
                }

                // 计算拣货不完全批次计数
                allData.forEach(r => {
                    const reason = (getColValue(r, '问题原因名称') || '').trim();
                    if (reason === '拣货不完全') {
                        const batch = String(getColValue(r, '批次号') || '').trim();
                        if (batch) pickingBatchCounts.set(batch, (pickingBatchCounts.get(batch) || 0) + 1);
                    }
                });

                // 第二遍：设置默认值
                allData.forEach(nr => {
                    const isResp = getDefaultIsResponsible(nr);
                    const verifyReason = getDefaultVerifyReason(nr);
                    manualDataMap.set(nr._rowId, { isResponsible: isResp, reason: verifyReason });
                    if (isResp === '无责') defaultNoRespRowIds.add(nr._rowId);
                });

                if (progressFill) progressFill.style.width = '80%';
                if (progressText) progressText.textContent = '正在分类数据...';

                coldThawData = allData.filter(r => (getColValue(r,'问题原因名称')||'').trim() === '冷链商品化冻');
                coldThawManualMap.clear();
                coldThawData.forEach(r => { const isResp = getDefaultIsResponsible(r); coldThawManualMap.set(r._rowId, { isThawIssue:'是', storeStandard:'不规范', deliveryStandard:'不规范', orderAttr:'内环', isResponsible:isResp, verifyReason:getDefaultVerifyReason(r) }); if (isResp === '无责') defaultNoRespRowIds.add(r._rowId); });

                // 物流损数据
                logisticsDamageData = allData.filter(r => (getColValue(r,'问题原因名称')||'').trim() === '物流损');
                logisticsManualMap.clear();
                logisticsDamageData.forEach(r => { const isResp = getDefaultIsResponsible(r); logisticsManualMap.set(r._rowId, { isResponsible:isResp, reason:getDefaultVerifyReason(r) }); if (isResp === '无责') defaultNoRespRowIds.add(r._rowId); });

                badReviewData = []; badReviewManualMap.clear();
                if (badReviewSheetName) {
                    const brRows = XLSX.utils.sheet_to_json(wb.Sheets[badReviewSheetName], { defval:'', raw:false });
                    brRows.forEach(r => {
                        const nr = {};
                        for (let k in r) nr[k.trim()] = r[k];
                        nr._rowId = rowIdCounter++;
                        badReviewData.push(nr);
                        const isResp = getDefaultIsResponsible(nr);
                        badReviewManualMap.set(nr._rowId, { isResponsible:isResp, verify:getDefaultVerifyReason(nr) });
                        if (isResp === '无责') defaultNoRespRowIds.add(nr._rowId);
                    });
                }

                if (progressFill) progressFill.style.width = '95%';
                if (progressText) progressText.textContent = '正在初始化界面...';

                allStores = [...new Set(allData.map(r => String(getColValue(r,'门店名称')).trim()).filter(Boolean))].sort();
                selectedReasons.clear();

                if (progressFill) progressFill.style.width = '100%';
                if (progressText) progressText.textContent = '加载完成！';

                toast('✅ 成功加载 ' + allData.length + ' 条记录');

                // 短暂延迟后隐藏进度条并弹出门店选择
                setTimeout(() => {
                    if (progressWrap) progressWrap.style.display = 'none';
                    showStoreSelection();
                }, 400);
            } catch(err) { toast('❌ 解析文件失败'); console.error(err); if (progressWrap) progressWrap.style.display = 'none'; }
        };
        reader.readAsArrayBuffer(file);
    }

    function initializeMainUI() {
        currentView = 'default';
        viewCurrentPages = { default:1, badReview:1, coldThaw:1, logistics:1 };
        duplicateBatchSet.clear();
        // 切换门店时清除用户输入的数据，避免数据冗余
        manualDataMap.clear();
        badReviewManualMap.clear();
        coldThawManualMap.clear();
        logisticsManualMap.clear();
        responsibilityReasonMap.clear();
        // 重新计算拣货不完全批次计数
        pickingBatchCounts.clear();
        allData.forEach(r => {
            const reason = (getColValue(r, '问题原因名称') || '').trim();
            if (reason === '拣货不完全') {
                const batch = String(getColValue(r, '批次号') || '').trim();
                if (batch) pickingBatchCounts.set(batch, (pickingBatchCounts.get(batch) || 0) + 1);
            }
        });
        // 重新初始化默认数据
        defaultNoRespRowIds.clear();
        allData.forEach(r => { const isResp = getDefaultIsResponsible(r); manualDataMap.set(r._rowId, { isResponsible:isResp, reason:getDefaultVerifyReason(r) }); if (isResp === '无责') defaultNoRespRowIds.add(r._rowId); });
        coldThawData.forEach(r => { const isResp = getDefaultIsResponsible(r); coldThawManualMap.set(r._rowId, { isThawIssue:'是', storeStandard:'不规范', deliveryStandard:'不规范', orderAttr:'内环', isResponsible:isResp, verifyReason:getDefaultVerifyReason(r) }); if (isResp === '无责') defaultNoRespRowIds.add(r._rowId); });
        logisticsDamageData.forEach(r => { const isResp = getDefaultIsResponsible(r); logisticsManualMap.set(r._rowId, { isResponsible:isResp, reason:getDefaultVerifyReason(r) }); if (isResp === '无责') defaultNoRespRowIds.add(r._rowId); });
        badReviewData.forEach(r => { const isResp = getDefaultIsResponsible(r); badReviewManualMap.set(r._rowId, { isResponsible:isResp, verify:getDefaultVerifyReason(r) }); if (isResp === '无责') defaultNoRespRowIds.add(r._rowId); });
        updateBubbles();
        applyFilters();
        ['filterBar','tableWrapper','statsPanel','achievementPanel'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = 'flex';
        });
        // achievementPanel是block显示
        $('#achievementPanel').style.display = 'block';
        updateViewBubblesVisibility();
        updateViewBubbleActiveState();
        updateCurrentStoreLabel();
        updateDataSourceText();
        renderAchievementPanel();
        renderResponsibilityPanel();
    }

    function updateDataSourceText() {
        const el = $('#dataSourceText');
        if (!allData.length) { el.textContent = '时间：--'; return; }
        
        // 获取问单速查中日期列第一个非空数值
        let firstDate = '';
        for (const row of allData) {
            const d = getColValue(row,'日期');
            if (d) {
                firstDate = String(d).trim();
                break;
            }
        }
        
        // 格式：当前时间：20260516
        el.textContent = '时间：' + (firstDate || '--');
    }

    function updateBubbles() {
        if (currentView !== 'default') { $('#bubbleContainer').innerHTML = '<span class="no-bubbles">当前视图不支持筛选</span>'; return; }
        let data = allData.filter(r => r && (getColValue(r,'问题原因名称')||'').trim() !== '冷链商品化冻' && (getColValue(r,'问题原因名称')||'').trim() !== '物流损');
        if (selectedStore) data = data.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore);
        const counts = new Map();
        data.forEach(r => { const k = (getColValue(r,'问题原因名称')||'').trim(); if (k) counts.set(k, (counts.get(k)||0)+1); });
        const reasons = [...counts.keys()].sort((a,b) => (counts.get(b)||0) - (counts.get(a)||0));
        
        const hasSelection = selectedReasons.size > 0;
        const allLabel = hasSelection ? '✕ 清空筛选' : '📋 全部';
        const allClass = hasSelection ? 'bubble-all has-selection' : 'bubble-all';
        
        let html = `<span class="bubble-tag ${allClass} ${!hasSelection?'active':''}" id="bubbleAll">${allLabel} <span class="bubble-count-inline">${data.length}条</span></span>`;
        reasons.forEach(r => html += `<span class="bubble-tag ${selectedReasons.has(r)?'active':''}" data-reason="${escapeHTML(r)}">${escapeHTML(r)} <span class="bubble-count-inline">${counts.get(r)}|${data.length?((counts.get(r)/data.length)*100).toFixed(1):0}%</span></span>`);
        $('#bubbleContainer').innerHTML = html;
        const ba = $('#bubbleAll');
        if (ba) ba.addEventListener('click', () => { selectedReasons.clear(); setCurrentPage(1); updateBubbles(); applyFilters(); });
        document.querySelectorAll('.bubble-tag[data-reason]').forEach(b => b.addEventListener('click', function() {
            const r = this.dataset.reason;
            if (selectedReasons.has(r)) {
                selectedReasons.clear(); // 再次点击取消选中
            } else {
                selectedReasons.clear(); // 单选：先清空
                selectedReasons.add(r);
            }
            setCurrentPage(1); updateBubbles(); applyFilters();
        }));
    }

    function applyFilters() {
        let data;
        if (currentView === 'default') {
            data = [...allData];
        } else if (currentView === 'badReview') {
            data = [...badReviewData];
        } else if (currentView === 'coldThaw') {
            data = [...coldThawData];
        } else if (currentView === 'logistics') {
            data = [...logisticsDamageData];
        } else {
            data = [...allData];
        }

        if (selectedStore) {
            const storeCol = currentView === 'badReview' ? '门店' : '门店名称';
            data = data.filter(r => String(getColValue(r, storeCol)).trim() === selectedStore);
        }

        if (currentView === 'default') {
            // 问单视图排除冷链和物流损
            data = data.filter(r => {
                const reason = (getColValue(r,'问题原因名称')||'').trim();
                return reason !== '冷链商品化冻' && reason !== '物流损';
            });
            if (selectedReasons.size) data = data.filter(r => selectedReasons.has((getColValue(r,'问题原因名称')||'').trim()));
        }

        // 问单明细排序（default / logistics 共用逻辑）
        if (currentView === 'default' || currentView === 'logistics') {
            // 第一步：统计每个问题原因名称的总数量
            const reasonCounts = new Map();
            data.forEach(r => {
                const reason = (getColValue(r, '问题原因名称') || '').trim();
                if (reason) reasonCounts.set(reason, (reasonCounts.get(reason) || 0) + 1);
            });
            // 第二步：统计每个批次号的总数量
            const batchCounts = new Map();
            data.forEach(r => {
                const batch = String(getColValue(r, '批次号') || '').trim();
                if (batch) batchCounts.set(batch, (batchCounts.get(batch) || 0) + 1);
            });
            // 第三步：排序（确保同批次号连续）
            sortDefaultData(data);
        } else if (currentView === 'badReview') {
            data.sort((a, b) => {
                const aDash = (getColValue(a, '评价文本') || '').trim() === '-';
                const bDash = (getColValue(b, '评价文本') || '').trim() === '-';
                if (aDash && !bDash) return 1;
                if (!aDash && bDash) return -1;
                return 0;
            });
        }

        // 计算重复批次（所有问单明细视图）
        duplicateBatchSet.clear();
        const batchCounts = new Map();
        data.forEach(r => { const b = String(getColValue(r,'批次号')||'').trim(); if (b) batchCounts.set(b, (batchCounts.get(b)||0)+1); });
        batchCounts.forEach((v,k) => { if (v > 1) duplicateBatchSet.add(k); });

        if (currentView === 'default') filteredData = data;
        else if (currentView === 'badReview') filteredBadReviewData = data;
        else if (currentView === 'coldThaw') filteredColdThawData = data;
        else if (currentView === 'logistics') {
            filteredLogisticsDamageData = data;
        }

        const cfd = currentView === 'default' ? filteredData : (currentView === 'badReview' ? filteredBadReviewData : (currentView === 'coldThaw' ? filteredColdThawData : filteredLogisticsDamageData));
        const totalPages = Math.ceil(cfd.length / pageSize) || 1;
        if (getCurrentPage() > totalPages) setCurrentPage(totalPages);
        renderTable();
        renderResponsibilityPanel();
    }

    function getCurrentPage() { return viewCurrentPages[currentView] || 1; }
    function setCurrentPage(p) { viewCurrentPages[currentView] = p; }

    function updateCurrentStoreLabel() {
        const el = $('#currentStoreName');
        if (!selectedStore) {
            el.textContent = '📍 门店：全部门店';
            return;
        }
        
        const storeType = getStoreType(selectedStore);
        const typeLabel = getStoreTypeLabel(storeType);
        const typeClass = getStoreTypeClass(storeType);
        
        // 单行结构：📍 当前门店：店名 [类型标签]
        el.innerHTML = `📍 门店：${escapeHTML(selectedStore)}<span class="store-type-tag ${typeClass}">${typeLabel}</span>`;
    }

    function renderTable() {
        const cfd = currentView === 'default' ? filteredData : (currentView === 'badReview' ? filteredBadReviewData : (currentView === 'coldThaw' ? filteredColdThawData : filteredLogisticsDamageData));
        const start = (getCurrentPage()-1) * pageSize, end = Math.min(start + pageSize, cfd.length);
        const pageData = cfd.slice(start, end);
        const thead = $('#tableHead'), tbody = $('#tableBody');

        if (currentView === 'default')
            thead.innerHTML = '<tr><th style="width:10%">问题原因名称</th><th style="width:15%">SKU名称</th><th style="width:10%">APP退款原因</th><th style="width:20%">APP退款描述</th><th style="width:10%">退款凭证</th><th style="width:5%">单号</th><th style="width:5%">配送员名</th><th style="width:5%">是否有责</th><th style="width:20%">核实原因</th></tr>';
        else if (currentView === 'badReview')
            thead.innerHTML = '<tr><th style="width:5%">交易日期</th><th style="width:15%">门店</th><th style="width:5%">配送员名称</th><th style="width:10%">单号</th><th style="width:25%">评价文本</th><th style="width:10%">评价标签</th><th style="width:10%">评价星级</th><th style="width:5%">是否有责</th><th style="width:15%">核实原因</th></tr>';
        else if (currentView === 'coldThaw')
            thead.innerHTML = '<tr><th style="width:10%">门店</th><th style="width:5%">配送员</th><th style="width:10%">商品名称</th><th style="width:5%">订单属性</th><th style="width:5%">是否化冻问题</th><th style="width:10%">店仓规范</th><th style="width:10%">配送规范</th><th style="width:15%">顾客原声</th><th style="width:5%">退款凭证</th><th style="width:5%">单号</th><th style="width:5%">时间戳</th><th style="width:10%">核实原因</th><th style="width:5%">是否有责</th></tr>';
        else if (currentView === 'logistics')
            thead.innerHTML = '<tr><th style="width:10%">问题原因名称</th><th style="width:15%">SKU名称</th><th style="width:10%">APP退款原因</th><th style="width:20%">APP退款描述</th><th style="width:10%">退款凭证</th><th style="width:5%">单号</th><th style="width:5%">配送员名</th><th style="width:5%">是否有责</th><th style="width:20%">核实原因</th></tr>';

        tbody.innerHTML = '';
        $('#emptyState').style.display = pageData.length ? 'none' : 'block';
        if (!pageData.length) { $('#paginationBar').innerHTML = ''; return; }

        const fragment = document.createDocumentFragment();
        pageData.forEach(row => {
            const tr = document.createElement('tr');
            if (duplicateBatchSet.has(String(getColValue(row,'批次号')||'').trim())) tr.classList.add('duplicate-batch');
            if (currentView === 'default') {
                tr.appendChild(createClickableCell(getColValue(row,'问题原因名称')));
                tr.appendChild(createClickableCell(getColValue(row,'sku名称')||getColValue(row,'SKU名称')));
                tr.appendChild(createClickableCell(getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')));
                tr.appendChild(createClickableCell(getAppRefundDesc(row)));
                tr.appendChild(createVoucherCell(row));
                tr.appendChild(createOrderCell(row, ['淘系主订单id','批次号','配送单号']));
                tr.appendChild(createPersonCell(row));
                tr.appendChild(createSelectCell(row, 'isResponsible', ['无责','有责'], manualDataMap, 1));
                tr.appendChild(createInputCell(row, 'reason', manualDataMap, getDefaultVerifyReason(row)));
            } else if (currentView === 'badReview') {
                tr.appendChild(createCell(getColValue(row,'交易日期')));
                tr.appendChild(createCell(getColValue(row,'门店')));
                tr.appendChild(createCell(getColValue(row,'配送员名称')));
                tr.appendChild(createOrderCell(row, ['评价父订单','盒马主订单','外部主订单','履约单号']));
                tr.appendChild(createClickableCell(getColValue(row,'评价文本')));
                tr.appendChild(createCell(getColValue(row,'评价标签')));
                tr.appendChild(createStarCell(row));
                tr.appendChild(createSelectCell(row, 'isResponsible', ['无责','有责'], badReviewManualMap, 1));
                tr.appendChild(createInputCell(row, 'verify', badReviewManualMap, getDefaultVerifyReason(row)));
            } else if (currentView === 'coldThaw') {
                tr.appendChild(createCell(getColValue(row,'门店名称')));
                tr.appendChild(createCell(getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'-'));
                tr.appendChild(createClickableCell(getColValue(row,'sku名称')||getColValue(row,'SKU名称')));
                tr.appendChild(createSelectCell(row, 'orderAttr', ['内环','外环','环外'], coldThawManualMap, 0));
                tr.appendChild(createSelectCell(row, 'isThawIssue', ['是','否'], coldThawManualMap));
                tr.appendChild(createSelectCell(row, 'storeStandard', ['不规范','规范'], coldThawManualMap, 0));
                tr.appendChild(createSelectCell(row, 'deliveryStandard', ['不规范','规范'], coldThawManualMap, 0));
                tr.appendChild(createClickableCell(getAppRefundDesc(row)));
                tr.appendChild(createVoucherCell(row));
                tr.appendChild(createOrderCell(row, ['淘系主订单id','批次号','配送单号']));
                tr.appendChild(createTimeCellWithInterval(row));
                tr.appendChild(createInputCell(row, 'verifyReason', coldThawManualMap, getDefaultVerifyReason(row)));
                tr.appendChild(createSelectCell(row, 'isResponsible', ['无责','有责'], coldThawManualMap, 1));
            } else if (currentView === 'logistics') {
                tr.appendChild(createClickableCell(getColValue(row,'问题原因名称')));
                tr.appendChild(createClickableCell(getColValue(row,'sku名称')||getColValue(row,'SKU名称')));
                tr.appendChild(createClickableCell(getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')));
                tr.appendChild(createClickableCell(getAppRefundDesc(row)));
                tr.appendChild(createVoucherCell(row));
                tr.appendChild(createOrderCell(row, ['淘系主订单id','批次号','配送单号']));
                tr.appendChild(createPersonCell(row));
                tr.appendChild(createSelectCell(row, 'isResponsible', ['无责','有责'], logisticsManualMap, 1));
                tr.appendChild(createInputCell(row, 'reason', logisticsManualMap, getDefaultVerifyReason(row)));
            }
            fragment.appendChild(tr);
        });
        tbody.appendChild(fragment);
        renderPagination(cfd);
    }

    function createCell(text) { const td = document.createElement('td'); td.textContent = text || '-'; return td; }
    function createClickableCell(fullText) {
        const td = document.createElement('td');
        td.textContent = fullText || '-';
        td.title = fullText || '-';
        return td;
    }
    function createVoucherCell(row) {
        const td = document.createElement('td');
        const urls = parseImageUrls(getColValue(row,'退款凭证')||'');
        if (urls.length) {
            const img = document.createElement('img');
            img.src = urls[0];
            img.style.cssText = 'width:80px;height:80px;object-fit:cover;border-radius:6px;cursor:pointer;border:1px solid #e6e8f0;';
            img.title = '点击全屏查看' + urls.length + '张图片';
            img.addEventListener('click', function(e) { e.stopPropagation(); openFullscreen(urls[0]); });
            td.appendChild(img);
        } else {
            const btn = document.createElement('span'); btn.className='cell-view-btn no-image'; btn.textContent='无凭证'; td.appendChild(btn);
        }
        return td;
    }
    function createOrderCell(row, fields) {
        const td = document.createElement('td');
        const values = fields.map(f => getColValue(row,f)||'');
        if (values.some(v => String(v).trim())) {
            const btn = document.createElement('span'); btn.className='cell-btn'; btn.textContent='📋 查看';
            btn.addEventListener('click', e => { e.stopPropagation(); showDetailPopup(btn, fields.map((f,i) => makePopupRow(f, values[i])).join('')); });
            td.appendChild(btn);
        } else {
            const btn = document.createElement('span'); btn.className='cell-btn no-data'; btn.textContent='无数据'; td.appendChild(btn);
        }
        return td;
    }
    function createPersonCell(row) {
        const td = document.createElement('td');
        const delivery = String(getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'').trim();
        td.textContent = delivery || '-';
        return td;
    }

    // 带时间间隔的时间戳单元格
    function createIntervalCell(row) {
        const td = document.createElement('td');
        const signTime = parseDateTime(getColValue(row,'签收时间'));
        const pickupTime = parseDateTime(getColValue(row,'揽收时间'));
        let intervalText = '-';
        let isAlert = false;
        if (signTime && pickupTime) {
            const diffMin = Math.round((signTime - pickupTime) / 60000);
            intervalText = diffMin + '分钟';
            isAlert = diffMin > 18;
        }
        const span = document.createElement('span');
        span.style.cssText = isAlert ? 'color:#e74c3c;font-weight:700;' : 'color:#3a3a58;';
        span.textContent = intervalText;
        td.appendChild(span);
        return td;
    }

    function createTimeCellWithInterval(row) {
        const td = document.createElement('td');
        const fields = ['批次生成时间','拣货完成时间','打包完成时间','揽收时间','签收时间','最晚送达时间'];
        const isColdThaw = currentView === 'coldThaw';
        const values = fields.map(f => formatTime(getColValue(row,f)||'', isColdThaw));
        if (values.some(v => String(v).trim())) {
            // 计算签收-揽收时间差（分钟）
            const signTime = parseDateTime(getColValue(row,'签收时间'));
            const pickupTime = parseDateTime(getColValue(row,'揽收时间'));
            let signPickupDiff = null;
            if (signTime && pickupTime) {
                signPickupDiff = Math.round((signTime - pickupTime) / 60000);
            }

            const isAlert = signPickupDiff !== null && signPickupDiff > 18;
            const btn = document.createElement('span');
            btn.className = 'cell-btn' + (isAlert ? ' alert' : '');
            btn.textContent = isAlert ? '⚠️ 查看' : '🕐 查看';
            btn.addEventListener('click', e => {
                e.stopPropagation();
                let popupContent = '';
                for (let i = 0; i < fields.length; i++) {
                    const val = values[i] || '-';
                    let intervalStr = '-';
                    let intervalColor = '#b0b0c0';
                    let intervalBold = false;
                    if (i > 0) {
                        const prevTime = parseDateTime(getColValue(row, fields[i-1]));
                        const currTime = parseDateTime(getColValue(row, fields[i]));
                        if (prevTime && currTime) {
                            const diffMin = Math.round((currTime - prevTime) / 60000);
                            intervalStr = diffMin + '分钟';
                            // 仅签收时间超过18分钟标红加粗
                            if (fields[i] === '签收时间' && diffMin > 18) {
                                intervalColor = '#e74c3c';
                                intervalBold = true;
                            } else {
                                intervalColor = '#3a3a58';
                            }
                        }
                    }
                    // 间隔时间替代复制按钮，签收时间超过18分钟标红
                    popupContent += `<div class="info-row"><span class="info-label">${escapeHTML(fields[i])}</span><span class="info-value">${escapeHTML(val)}</span><span class="info-copy-btn" style="cursor:default;color:${intervalColor};${intervalBold ? 'font-weight:700;' : ''}">${intervalStr}</span></div>`;
                }
                showDetailPopup(btn, popupContent);
            });
            td.appendChild(btn);
        } else {
            const btn = document.createElement('span'); btn.className='cell-btn no-data'; btn.textContent='无数据'; td.appendChild(btn);
        }
        return td;
    }

    function formatTime(str, onlyTime) {
        if (!str) return '';
        const s = String(str).trim();
        let fullStr = '';
        // 支持整数和小数Excel序列号（如46183.74715）
        if (/^\d+(\.\d+)?$/.test(s)) {
            const num = parseFloat(s);
            if (num > 40000 && num < 60000) {
                const d = new Date((num - 25569) * 86400 * 1000);
                fullStr = d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')+':'+String(d.getSeconds()).padStart(2,'0');
            }
        }
        if (!fullStr) {
            const m = s.match(/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})[\sT]?(\d{1,2})?:(\d{1,2})?:(\d{1,2})?/);
            if (m) {
                fullStr = m[1]+'-'+m[2].padStart(2,'0')+'-'+m[3].padStart(2,'0')+' '+(m[4]||'00').padStart(2,'0')+':'+(m[5]||'00').padStart(2,'0')+':'+(m[6]||'00').padStart(2,'0');
            } else {
                const d = new Date(s);
                if (!isNaN(d)) fullStr = d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')+':'+String(d.getSeconds()).padStart(2,'0');
                else fullStr = s;
            }
        }
        if (onlyTime) {
            const timeMatch = fullStr.match(/(\d{2}:\d{2}:\d{2})$/);
            return timeMatch ? timeMatch[1] : fullStr;
        }
        return fullStr;
    }
    function createStarCell(row) {
        const td = document.createElement('td');
        const v = parseInt(getColValue(row,'评价星级'));
        if (!isNaN(v) && v > 0) td.innerHTML = '<span class="star-rating">'+'★'.repeat(v)+'☆'.repeat(5-v)+'</span>';
        else td.textContent = getColValue(row,'评价星级')||'-';
        return td;
    }
    function createSelectCell(row, key, options, map, defaultIdx) {
        const td = document.createElement('td');
        const defIdx = defaultIdx || 0;
        const saved = map.get(row._rowId) || {};
        let currentIdx = options.indexOf(saved[key]);
        if (currentIdx === -1) currentIdx = defIdx;
        // 颜色类型映射
        const colorMap = {
            '有责': 'responsible', '无责': 'irresponsible',
            '不规范': 'nonstandard', '规范': 'standard',
            '是': 'yes', '否': 'no'
        };
        const btn = document.createElement('span');
        btn.className = 'cell-toggle-btn';
        btn.setAttribute('data-type', colorMap[options[currentIdx]] || '');
        const hint = document.createElement('span');
        hint.className = 'toggle-hint';
        hint.textContent = '🔄';
        btn.textContent = options[currentIdx];
        btn.appendChild(hint);
        // 首次加载呼吸动画引导
        setTimeout(() => btn.classList.add('pulse'), 100);
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            currentIdx = (currentIdx + 1) % options.length;
            btn.textContent = options[currentIdx];
            btn.setAttribute('data-type', colorMap[options[currentIdx]] || '');
            btn.appendChild(hint);
            btn.classList.remove('pulse');
            saved[key] = options[currentIdx];
            map.set(row._rowId, saved);
            renderResponsibilityPanel();
        });
        td.appendChild(btn); return td;
    }
    function createInputCell(row, key, map, defaultVal) {
        const td = document.createElement('td');
        const inp = document.createElement('textarea'); inp.className='cell-textarea';
        inp.rows = 1;
        inp.style.cssText = 'min-height:28px;max-height:120px;resize:none;overflow-y:auto;width:100%;box-sizing:border-box;';
        const saved = map.get(row._rowId) || {};
        inp.value = saved[key] || defaultVal || '';
        // 自动调整高度
        const autoResize = () => { inp.style.height = 'auto'; inp.style.height = Math.min(inp.scrollHeight, 120) + 'px'; };
        inp.addEventListener('input', () => { saved[key] = inp.value; map.set(row._rowId, saved); autoResize(); renderResponsibilityPanel(); });
        // 初始化高度
        setTimeout(autoResize, 0);
        td.appendChild(inp); return td;
    }
    function parseImageUrls(v) {
        if (!v) return [];
        return String(v).trim()
            .split(/[,，]+/)
            .map(s => s.trim())
            .filter(s => s && s.length > 3 && !['无','空','none','null'].includes(s.toLowerCase()))
            .map(s => {
                // 移除 ? 及其后的所有内容
                const qIndex = s.indexOf('?');
                return qIndex !== -1 ? s.substring(0, qIndex) : s;
            });
    }

    // 差评日期：读取差评列表中的"评价日期"列，加1天
    function getBadReviewDatePlusOne(row) {
        const dateStr = String(getColValue(row, '评价日期') || '').trim();
        const d = parseDateTime(dateStr);
        if (d) {
            d.setDate(d.getDate() + 1);
            return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
        }
        return '-';
    }

    // 冷链日期：读取问单明细中的"日期"列，加1天
    function getColdThawDatePlusOne(row) {
        const dateStr = String(getColValue(row, '日期') || '').trim();
        const d = parseDateTime(dateStr);
        if (d) {
            d.setDate(d.getDate() + 1);
            return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
        }
        return '-';
    }

    // 一键复制冷链数据
    async function copyAllColdThawData() {
        // 检测店仓规范、配送规范、核实原因是否规范/填写
        const issues = { storeStandard: [], deliveryStandard: [], verifyReason: [] };
        filteredColdThawData.forEach(row => {
            const ct = coldThawManualMap.get(row._rowId) || {};
            const orderInfo = `【${getColValue(row,'门店名称')||'-'} - ${getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'-'}】`;
            if (ct.storeStandard === '不规范') {
                issues.storeStandard.push(orderInfo);
            }
            if (ct.deliveryStandard === '不规范') {
                issues.deliveryStandard.push(orderInfo);
            }
            if (!ct.verifyReason || !ct.verifyReason.trim()) {
                issues.verifyReason.push(orderInfo);
            }
        });
        // 汇总所有问题，使用一个弹窗提示
        const allIssues = [];
        if (issues.storeStandard.length > 0) allIssues.push(`店仓不规范（${issues.storeStandard.length}条）`);
        if (issues.deliveryStandard.length > 0) allIssues.push(`配送不规范（${issues.deliveryStandard.length}条）`);
        if (issues.verifyReason.length > 0) allIssues.push(`核实原因未填（${issues.verifyReason.length}条）`);

        if (allIssues.length > 0) {
            const confirmed = await showConfirmDialog(`<div style="text-align:center;">检测到冷链数据存在以下问题：<br><b style="color:#e74c3c;">${allIssues.join('、<br>')}</b><br>是否继续复制？</div>`);
            if (!confirmed) return;
        }
        let text = '';
        filteredColdThawData.forEach(row => {
            const ct = coldThawManualMap.get(row._rowId) || {};
            const dateStr = getColdThawDatePlusOne(row);
            text += `门店：${getColValue(row,'门店名称')||'-'}（${dateStr}冷链化冻核实）\n`;
            text += `配送员：${getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'-'}\n`;
            text += `履约单号：${getColValue(row,'履约单号')||getColValue(row,'配送单号')||'-'}\n`;
            text += `商品名称：${getColValue(row,'sku名称')||getColValue(row,'SKU名称')||'-'}\n`;
            text += `订单属性：${ct.orderAttr||'内环'}\n`;
            text += `是否化冻问题：${ct.isThawIssue||'是'}\n`;
            text += `店仓规范：${ct.storeStandard||'不规范'}\n`;
            text += `配送规范：${ct.deliveryStandard||'不规范'}\n`;
            text += `核实原因：${ct.verifyReason||'-'}\n`;
            text += `是否有责：${ct.isResponsible||'有责'}\n`;
            text += '\n\n\n';
        });
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => toast('✅ 已复制冷链数据到剪贴板'));
        } else {
            toast('❌ 浏览器不支持剪贴板操作');
        }
    }

    // 一键复制差评数据
    async function copyAllBadReviewData() {
        // 检测核实原因是否为空
        const emptyRows = filteredBadReviewData.filter(row => {
            const br = badReviewManualMap.get(row._rowId) || {};
            return !br.verify || !br.verify.trim();
        });
        if (emptyRows.length > 0) {
            const confirmed = await showConfirmDialog(`检测到 <b style="color:#e74c3c;">${emptyRows.length}</b> 条差评数据的「核实原因」未填写，是否继续复制？`);
            if (!confirmed) return;
        }
        let text = '';
        filteredBadReviewData.forEach(row => {
            const br = badReviewManualMap.get(row._rowId) || {};
            const tag = (getColValue(row,'评价标签')||'').trim().replace(/^\d+[:：]/, '') || '-';
            const dateStr = getBadReviewDatePlusOne(row);
            text += `门店：${getColValue(row,'门店')||'-'}（${dateStr}差评核实）\n`;
            text += `配送员：${getColValue(row,'配送员名称')||'-'}\n`;
            text += `履约单号：${getColValue(row,'评价父订单')||getColValue(row,'盒马主订单')||getColValue(row,'外部主订单')||getColValue(row,'履约单号')||'-'}\n`;
            text += `评价标签：${tag}\n`;
            text += `客户原声：${getColValue(row,'评价文本')||'-'}\n`;
            text += `核实原因：${br.verify||'-'}\n`;
            text += `是否有责：${br.isResponsible||'-'}\n`;
            text += '\n\n\n';
        });
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => toast('✅ 已复制差评数据到剪贴板'));
        } else {
            toast('❌ 浏览器不支持剪贴板操作');
        }
    }

    function openImagePreview(urls, startIdx = 0) {
        if (!urls || !urls.length) return;
        previewUrls = [...urls]; previewIdx = Math.max(0, Math.min(startIdx, urls.length - 1));
        showPreviewImage();
        $('#previewBubble').style.display = 'block';
        setTimeout(() => document.addEventListener('click', closePreviewOnClickOutside), 50);
    }
    function closePreviewOnClickOutside(e) {
        const pb = $('#previewBubble');
        if (pb.style.display === 'none') { document.removeEventListener('click', closePreviewOnClickOutside); return; }
        if (pb.contains(e.target) || e.target.closest('.cell-view-btn')) return;
        closeImagePreview();
    }
    function closeImagePreview() {
        $('#previewBubble').style.display = 'none';
        previewUrls = [];
        document.removeEventListener('click', closePreviewOnClickOutside);
    }
    function showPreviewImage() {
        const pb = $('#previewBubble');
        pb.innerHTML = `
            <button class="preview-close" id="previewClose">✕</button>
            <img id="previewImg" src="${previewUrls[previewIdx]}" alt="预览">
            <div class="preview-controls">
                <button id="prevPreview" ${previewIdx===0?'disabled':''}>◀</button>
                <span class="preview-counter">${previewIdx+1}/${previewUrls.length}</span>
                <button id="nextPreview" ${previewIdx>=previewUrls.length-1?'disabled':''}>▶</button>
                <button id="openFullscreen">🖥 全屏</button>
            </div>
        `;
        pb.style.top = '50%'; pb.style.left = '50%'; pb.style.transform = 'translate(-50%,-50%)';
        document.getElementById('previewImg').addEventListener('click', (e) => e.stopPropagation());
        document.getElementById('previewClose').addEventListener('click', (e) => { e.stopPropagation(); closeImagePreview(); });
        document.getElementById('prevPreview').addEventListener('click', (e) => { e.stopPropagation(); if (previewIdx > 0) { previewIdx--; showPreviewImage(); } });
        document.getElementById('nextPreview').addEventListener('click', (e) => { e.stopPropagation(); if (previewIdx < previewUrls.length-1) { previewIdx++; showPreviewImage(); } });
        document.getElementById('openFullscreen').addEventListener('click', (e) => { e.stopPropagation(); openFullscreen(previewUrls[previewIdx]); });
    }
    function openFullscreen(url) { $('#fullscreenImage').src = url; $('#fullscreenOverlay').style.display = 'flex'; }
    $('#btnCloseFullscreen').addEventListener('click', () => $('#fullscreenOverlay').style.display = 'none');
    $('#fullscreenOverlay').addEventListener('click', e => { if (e.target === $('#fullscreenOverlay')) $('#fullscreenOverlay').style.display = 'none'; });

    // 分页
    function renderPagination(cfd) {
        const bar = $('#paginationBar');
        bar.innerHTML = '';
        const totalPages = Math.ceil(cfd.length / pageSize) || 1;
        if (totalPages <= 1 && cfd.length <= pageSize) {
            if (cfd.length) bar.innerHTML = '<span class="page-info">显示全部 ' + cfd.length + ' 条</span>';
            return;
        }
        const cp = getCurrentPage();

        const btnFirst = document.createElement('button'); btnFirst.textContent = '首页';
        btnFirst.disabled = cp === 1;
        btnFirst.addEventListener('click', () => { setCurrentPage(1); applyFilters(); });
        bar.appendChild(btnFirst);

        const btnPrev = document.createElement('button'); btnPrev.textContent = '上一页';
        btnPrev.disabled = cp === 1;
        btnPrev.addEventListener('click', () => { setCurrentPage(cp - 1); applyFilters(); });
        bar.appendChild(btnPrev);

        let sp = Math.max(1, cp - 3), ep = Math.min(totalPages, cp + 3);
        for (let p = sp; p <= ep; p++) {
            const bp = document.createElement('button');
            bp.textContent = p;
            if (p === cp) bp.classList.add('active-page');
            bp.addEventListener('click', () => { setCurrentPage(p); applyFilters(); });
            bar.appendChild(bp);
        }

        const btnNext = document.createElement('button'); btnNext.textContent = '下一页';
        btnNext.disabled = cp >= totalPages;
        btnNext.addEventListener('click', () => { setCurrentPage(cp + 1); applyFilters(); });
        bar.appendChild(btnNext);

        const btnLast = document.createElement('button'); btnLast.textContent = '末页';
        btnLast.disabled = cp >= totalPages;
        btnLast.addEventListener('click', () => { setCurrentPage(totalPages); applyFilters(); });
        bar.appendChild(btnLast);

        const sel = document.createElement('select');
        [10, 20, 30, 50, 100].forEach(n => { const o = document.createElement('option'); o.value = n; o.textContent = '每页' + n + '条'; if (n === pageSize) o.selected = true; sel.appendChild(o); });
        sel.addEventListener('change', () => { pageSize = +sel.value; setCurrentPage(1); applyFilters(); });
        bar.appendChild(sel);

        const info = document.createElement('span'); info.className = 'page-info';
        info.textContent = '共 ' + totalPages + ' 页 / ' + cfd.length + ' 条';
        bar.appendChild(info);
    }

    function updateViewBubblesVisibility() {
        const showBad = badReviewData.length && (!selectedStore || badReviewData.some(r => String(getColValue(r,'门店')||'').trim() === selectedStore));
        $('#viewBubbleBadReview').style.display = showBad ? 'inline-flex' : 'none';
        if (showBad) $('#badReviewBadge').textContent = selectedStore ? badReviewData.filter(r => String(getColValue(r,'门店')||'').trim()===selectedStore).length : badReviewData.length;
        const showCold = coldThawData.length && (!selectedStore || coldThawData.some(r => String(getColValue(r,'门店名称')||'').trim() === selectedStore));
        $('#viewBubbleColdThaw').style.display = showCold ? 'inline-flex' : 'none';
        if (showCold) $('#coldThawBadge').textContent = selectedStore ? coldThawData.filter(r => String(getColValue(r,'门店名称')||'').trim()===selectedStore).length : coldThawData.length;
        const showLogistics = logisticsDamageData.length && (!selectedStore || logisticsDamageData.some(r => String(getColValue(r,'门店名称')||'').trim() === selectedStore));
        $('#viewBubbleLogistics').style.display = showLogistics ? 'inline-flex' : 'none';
        if (showLogistics) $('#logisticsBadge').textContent = selectedStore ? logisticsDamageData.filter(r => String(getColValue(r,'门店名称')||'').trim()===selectedStore).length : logisticsDamageData.length;
        const defaultData = allData.filter(r => {
            const reason = (getColValue(r,'问题原因名称')||'').trim();
            return reason !== '冷链商品化冻' && reason !== '物流损';
        });
        $('#defaultBadge').textContent = selectedStore ? defaultData.filter(r => String(getColValue(r,'门店名称')||'').trim()===selectedStore).length : defaultData.length;
        // 一键复制按钮在冷链和差评视图时显示
        if (currentView === 'coldThaw') {
            $('#copyAllBtn').style.display = 'inline-flex';
            $('#copyAllBtn').textContent = '📋 一键复制冷链';
        } else if (currentView === 'badReview') {
            $('#copyAllBtn').style.display = 'inline-flex';
            $('#copyAllBtn').textContent = '📋 一键复制差评';
        } else {
            $('#copyAllBtn').style.display = 'none';
        }
        updateViewBubbleActiveState();
        if (currentView !== 'default') $('#bubbleContainer').innerHTML = '<span class="no-bubbles">当前视图不支持筛选</span>';
    }

    function updateViewBubbleActiveState() {
        $('#viewBubbleDefault').className = 'view-switch-bubble' + (currentView==='default'?' active-default':'');
        $('#viewBubbleBadReview').className = 'view-switch-bubble' + (currentView==='badReview'?' active-bad':'');
        $('#viewBubbleColdThaw').className = 'view-switch-bubble' + (currentView==='coldThaw'?' active-cold':'');
        $('#viewBubbleLogistics').className = 'view-switch-bubble' + (currentView==='logistics'?' active-logistics':'');
    }

    $('#viewBubbleDefault').addEventListener('click', () => switchView('default'));
    $('#viewBubbleBadReview').addEventListener('click', () => switchView('badReview'));
    $('#viewBubbleColdThaw').addEventListener('click', () => switchView('coldThaw'));
    $('#viewBubbleLogistics').addEventListener('click', () => switchView('logistics'));
    $('#copyAllBtn').addEventListener('click', function() {
        if (currentView === 'coldThaw') copyAllColdThawData();
        else if (currentView === 'badReview') copyAllBadReviewData();
    });

    function switchView(v) {
        if (currentView === v) return;
        currentView = v; setCurrentPage(1);
        updateViewBubbleActiveState(); updateBubbles(); applyFilters();
        updateViewBubblesVisibility();
    }

    document.getElementById('headerMenuBtn').addEventListener('click', e => { e.stopPropagation(); $('#headerMenuDropdown').classList.toggle('show'); });
    document.addEventListener('click', e => { if (!e.target.closest('.header-menu-btn')) $('#headerMenuDropdown').classList.remove('show'); });
    document.getElementById('menuReupload').addEventListener('click', () => {
        openGuideView('📂 导入文件', '请导入物流问单Excel',
            '<div class="file-upload-area" id="guideUploadArea"><span class="upload-text-lg">📁 点击选择文件</span></div><div class="upload-hint">💡 选择大文件时页面可能出现短暂卡顿，请耐心等待加载完成。<br>如页面提示"无响应"，请点击<b>「等待」</b>按钮，切勿关闭页面。</div><div class="upload-progress-wrap" id="guideProgressWrap"><div class="upload-progress-bar"><div class="upload-progress-fill" id="guideProgressFill"></div></div><div class="upload-progress-text" id="guideProgressText">准备中...</div></div>',
            '<button class="guide-btn primary" id="guideConfirmBtn">确认</button>');
        document.getElementById('guideUploadArea').addEventListener('click', () => hiddenFileInput.click());
        // change 监听已在初始化时通过 addEventListener 绑定，这里不再重复绑定（避免文件被解析两次）
    });
    document.getElementById('menuSelectStore').addEventListener('click', showStoreSelection);
    document.getElementById('menuExportImage').addEventListener('click', showExportImageOptions);

    function showExportImageOptions() {
        const panelHTML = `
            <div class="export-select-panel">
                <div class="export-select-title">🖼️ 选择导出内容</div>
                <div class="export-checkbox-list">
                    <label class="export-checkbox-item checked" data-key="analysis">
                        <input type="checkbox" value="analysis" checked>
                        <span>📊 问单分析（达成情况 + 责任分析）</span>
                    </label>
                    <label class="export-checkbox-item checked" data-key="default">
                        <input type="checkbox" value="default" checked>
                        <span>📋 问单明细</span>
                    </label>
                    <label class="export-checkbox-item checked" data-key="logistics">
                        <input type="checkbox" value="logistics" checked>
                        <span>📦 物流损明细</span>
                    </label>
                    <label class="export-checkbox-item checked" data-key="coldThaw">
                        <input type="checkbox" value="coldThaw" checked>
                        <span>❄️ 冷链明细</span>
                    </label>
                    <label class="export-checkbox-item checked" data-key="badReview">
                        <input type="checkbox" value="badReview" checked>
                        <span>💬 差评明细</span>
                    </label>
                </div>
                <div class="export-select-footer">
                    <button class="guide-btn secondary" id="exportImgCancel">取消</button>
                    <button class="guide-btn primary" id="exportImgConfirm">📥 导出图片</button>
                </div>
            </div>
        `;
        openGuideView('', '', panelHTML, '');
        // 隐藏guide-card默认的标题和关闭按钮区域
        guideCard.querySelector('.guide-title').style.display = 'none';
        guideCard.querySelector('.guide-subtitle').style.display = 'none';
        guideCard.querySelector('.guide-close-btn').style.display = 'none';
        guideCard.querySelector('.guide-footer').style.display = 'none';
        guideCard.style.padding = '0';
        guideCard.style.background = 'transparent';
        guideCard.style.boxShadow = 'none';

        // checkbox联动样式
        document.querySelectorAll('.export-checkbox-item').forEach(item => {
            const cb = item.querySelector('input[type="checkbox"]');
            cb.addEventListener('change', () => {
                item.classList.toggle('checked', cb.checked);
            });
        });

        document.getElementById('exportImgCancel').addEventListener('click', () => {
            guideOverlay.style.display = 'none';
            // 恢复guide-card样式
            guideCard.style.padding = '';
            guideCard.style.background = '';
            guideCard.style.boxShadow = '';
            guideCard.querySelector('.guide-title').style.display = '';
            guideCard.querySelector('.guide-subtitle').style.display = '';
            guideCard.querySelector('.guide-close-btn').style.display = '';
        });
        document.getElementById('exportImgConfirm').addEventListener('click', () => {
            const selected = [];
            document.querySelectorAll('.export-checkbox-item input:checked').forEach(cb => selected.push(cb.value));
            guideOverlay.style.display = 'none';
            // 恢复guide-card样式
            guideCard.style.padding = '';
            guideCard.style.background = '';
            guideCard.style.boxShadow = '';
            guideCard.querySelector('.guide-title').style.display = '';
            guideCard.querySelector('.guide-subtitle').style.display = '';
            guideCard.querySelector('.guide-close-btn').style.display = '';
            if (selected.length === 0) {
                toast('❌ 请至少选择一项导出内容');
                return;
            }
            doExportImage(selected);
        });
    }



    async function doExportImage(selectedSections) {
        // ===== 弹窗1：检测所有「核实原因」未填写情况 =====
        // 根据当前门店重新计算各视图的过滤数据（不依赖当前浏览的视图）
        const storeFilteredData = selectedStore ? allData.filter(r => {
            const reason = (getColValue(r,'问题原因名称')||'').trim();
            return reason !== '冷链商品化冻' && reason !== '物流损' && String(getColValue(r,'门店名称')).trim() === selectedStore;
        }) : allData.filter(r => {
            const reason = (getColValue(r,'问题原因名称')||'').trim();
            return reason !== '冷链商品化冻' && reason !== '物流损';
        });
        const storeFilteredBadReviewData = selectedStore ? badReviewData.filter(r => String(getColValue(r,'门店')||'').trim() === selectedStore) : badReviewData;
        const storeFilteredColdThawData = selectedStore ? coldThawData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore) : coldThawData;
        const storeFilteredLogisticsData = selectedStore ? logisticsDamageData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore) : logisticsDamageData;

        const verifyIssues = [];
        // 差评核实原因
        if (selectedSections.includes('badReview')) {
            const emptyCount = storeFilteredBadReviewData.filter(row => {
                const br = badReviewManualMap.get(row._rowId) || {};
                return !br.verify || !br.verify.trim();
            }).length;
            if (emptyCount > 0) verifyIssues.push(`差评(${emptyCount}条)`);
        }
        // 冷链核实原因
        if (selectedSections.includes('coldThaw')) {
            const emptyCount = storeFilteredColdThawData.filter(row => {
                const ct = coldThawManualMap.get(row._rowId) || {};
                return !ct.verifyReason || !ct.verifyReason.trim();
            }).length;
            if (emptyCount > 0) verifyIssues.push(`冷链(${emptyCount}条)`);
        }
        // 问单核实原因
        if (selectedSections.includes('default')) {
            const emptyCount = storeFilteredData.filter(row => {
                const item = manualDataMap.get(row._rowId) || {};
                return !item.reason || !item.reason.trim();
            }).length;
            if (emptyCount > 0) verifyIssues.push(`问单(${emptyCount}条)`);
        }
        // 物流损核实原因
        if (selectedSections.includes('logistics')) {
            const emptyCount = storeFilteredLogisticsData.filter(row => {
                const item = logisticsManualMap.get(row._rowId) || {};
                return !item.reason || !item.reason.trim();
            }).length;
            if (emptyCount > 0) verifyIssues.push(`物流损(${emptyCount}条)`);
        }
        // 责任分析核实原因 - 仅检测当前门店的数据
        const allReasonNames = new Set();
        if (selectedSections.includes('analysis')) {
            // 根据是否选择了门店，过滤数据
            const filteredAllData = selectedStore ? allData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore) : allData;
            const filteredBadReviewDataForAnalysis = selectedStore ? badReviewData.filter(r => String(getColValue(r,'门店')||'').trim() === selectedStore) : badReviewData;
            const filteredColdThawDataForAnalysis = selectedStore ? coldThawData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore) : coldThawData;
            const filteredLogisticsDataForAnalysis = selectedStore ? logisticsDamageData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore) : logisticsDamageData;

            filteredAllData.forEach(r => {
                const reason = (getColValue(r,'问题原因名称')||'').trim();
                if (reason && reason !== '冷链商品化冻' && reason !== '物流损') allReasonNames.add(reason);
            });
            filteredBadReviewDataForAnalysis.forEach(r => {
                const reason = (getColValue(r,'评价标签')||'').trim().replace(/^\d+[:：]/, '');
                if (reason) allReasonNames.add('差评-' + reason);
            });
            filteredColdThawDataForAnalysis.forEach(() => allReasonNames.add('冷链商品化冻'));
            filteredLogisticsDataForAnalysis.forEach(() => allReasonNames.add('物流损'));
        }
        const emptyResponsibilityReasons = [];
        allReasonNames.forEach(reason => {
            const value = responsibilityReasonMap.get(reason);
            if (!value || !value.trim()) {
                emptyResponsibilityReasons.push(reason);
            }
        });
        if (emptyResponsibilityReasons.length > 0) {
            verifyIssues.push(`责任分析(${emptyResponsibilityReasons.length}条)`);
        }
        // 弹窗1：显示所有核实原因未填写
        if (verifyIssues.length > 0) {
            const confirmed = await showConfirmDialog(`<div style="text-align:center;">检测到：<br><b style="color:#e74c3c;">${verifyIssues.join('、')}</b><br>「核实原因」未填写是否继续导出？</div>`);
            if (!confirmed) return;
        }

        // ===== 弹窗2：检测店仓不规范、配送不规范、有责率 =====
        const standardIssues = [];
        // 店仓不规范、配送不规范（仅冷链视图）- 使用按门店过滤后的数据
        if (selectedSections.includes('coldThaw')) {
            const storeStandardCount = storeFilteredColdThawData.filter(row => {
                const ct = coldThawManualMap.get(row._rowId) || {};
                return ct.storeStandard === '不规范';
            }).length;
            const deliveryStandardCount = storeFilteredColdThawData.filter(row => {
                const ct = coldThawManualMap.get(row._rowId) || {};
                return ct.deliveryStandard === '不规范';
            }).length;
            if (storeStandardCount > 0) standardIssues.push(`店仓不规范(${storeStandardCount}条)`);
            if (deliveryStandardCount > 0) standardIssues.push(`配送不规范(${deliveryStandardCount}条)`);
        }
        // 有责率统计 - 使用按门店过滤后的数据
        const allViewData = [];
        storeFilteredData.forEach(r => allViewData.push(r));
        storeFilteredColdThawData.forEach(r => allViewData.push(r));
        storeFilteredLogisticsData.forEach(r => allViewData.push(r));
        storeFilteredBadReviewData.forEach(r => allViewData.push(r));
        let totalResp = 0, totalAll = 0;
        allViewData.forEach(row => {
            const map = badReviewData.includes(row) ? badReviewManualMap :
                        coldThawData.includes(row) ? coldThawManualMap :
                        logisticsDamageData.includes(row) ? logisticsManualMap : manualDataMap;
            const saved = map.get(row._rowId) || {};
            const isResponsible = saved.isResponsible || '有责';
            totalAll++;
            if (isResponsible === '有责') totalResp++;
        });
        if (totalResp > 0) {
            const rate = (totalResp / totalAll * 100).toFixed(1);
            standardIssues.push(`有责率<b style="color:#e74c3c;">${rate}%</b>（${totalResp}/${totalAll}）`);
        }
        // 弹窗2：显示店仓/配送不规范和有责率
        if (standardIssues.length > 0) {
            const confirmed = await showConfirmDialog(`<div style="text-align:center;">检测到以下问题：<br><b style="color:#e74c3c;">${standardIssues.join('、<br>')}</b><br>是否继续导出？</div>`);
            if (!confirmed) return;
        }

        const storeName = selectedStore || '全部门店';
        const now = new Date();
        const timestamp = String(now.getFullYear()).slice(2) + String(now.getMonth()+1).padStart(2,'0') + String(now.getDate()).padStart(2,'0');
        const title = `${storeName}-${timestamp}问单核实`;

        // 创建临时容器用于渲染报告
        const tempContainer = document.createElement('div');
        tempContainer.style.cssText = `
            position: fixed;
            left: -9999px;
            top: 0;
            width: 1400px;
            background: #f0f2f7;
            padding: 20px;
            z-index: -1;
        `;
        document.body.appendChild(tempContainer);

        // 构建静态表格HTML
        const buildStaticTable = (data, viewType) => {
            if (!data || !data.length) return '<p style="text-align:center;color:#b0b0c0;padding:20px;">暂无数据</p>';
            // 问单视图与物流损视图：同排序逻辑
            if (viewType === 'default' || viewType === 'logistics') {
                sortDefaultData(data);
            }
            let html = '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:12px;min-width:800px;">';
            if (viewType === 'default') {
                html += '<thead><tr style="background:#f8f9fd;"><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">问题原因名称</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:15%;">SKU名称</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">APP退款原因</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:20%;">APP退款描述</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:15%;">单号</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">配送员名</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">是否有责</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;width:20%;">核实原因</th></tr></thead><tbody>';
                data.forEach(row => {
                    const item = manualDataMap.get(row._rowId) || {};
                    html += `<tr style="background:#fff;"><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(getColValue(row,'问题原因名称'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:15%;">${escapeHTML(getColValue(row,'sku名称')||getColValue(row,'SKU名称'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(getColValue(row,'app退款原因')||getColValue(row,'APP退款原因'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:20%;">${escapeHTML(getAppRefundDesc(row))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:15%;">${escapeHTML(getColValue(row,'淘系主订单id')||getColValue(row,'批次号')||getColValue(row,'配送单号')||'-')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'-')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(item.isResponsible||'有责')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:20%;word-break:break-all;line-height:1.3;">${escapeHTML(item.reason||'')}</td></tr>`;
                });
            } else if (viewType === 'logistics') {
                html += '<thead><tr style="background:#f8f9fd;"><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">问题原因名称</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:15%;">SKU名称</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">APP退款原因</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:20%;">APP退款描述</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:15%;">单号</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">配送员名</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">是否有责</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;width:20%;">核实原因</th></tr></thead><tbody>';
                data.forEach(row => {
                    const item = logisticsManualMap.get(row._rowId) || {};
                    html += `<tr style="background:#fff;"><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(getColValue(row,'问题原因名称'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:15%;">${escapeHTML(getColValue(row,'sku名称')||getColValue(row,'SKU名称'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(getColValue(row,'app退款原因')||getColValue(row,'APP退款原因'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:20%;">${escapeHTML(getAppRefundDesc(row))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:15%;">${escapeHTML(getColValue(row,'淘系主订单id')||getColValue(row,'批次号')||getColValue(row,'配送单号')||'-')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'-')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(item.isResponsible||'有责')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:20%;word-break:break-all;line-height:1.3;">${escapeHTML(item.reason||'')}</td></tr>`;
                });
            } else if (viewType === 'badReview') {
                html += '<thead><tr style="background:#f8f9fd;"><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">交易日期</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:15%;">门店</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">配送员名称</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">评价文本</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:25%;">评价标签</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">评价星级</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">是否有责</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;width:15%;">核实原因</th></tr></thead><tbody>';
                data.forEach(row => {
                    const item = badReviewManualMap.get(row._rowId) || {};
                    html += `<tr style="background:#fff;"><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(getColValue(row,'交易日期'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:15%;">${escapeHTML(getColValue(row,'门店'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(getColValue(row,'配送员名称'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(getColValue(row,'评价文本'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:25%;">${escapeHTML(getColValue(row,'评价标签'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(getColValue(row,'评价星级'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(item.isResponsible||'有责')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:15%;word-break:break-all;line-height:1.3;">${escapeHTML(item.verify||'')}</td></tr>`;
                });
            } else if (viewType === 'coldThaw') {
                // 降序排序：按门店名称降序
                data = [...data].sort((a, b) => {
                    const aStore = String(getColValue(a,'门店名称')||'').trim();
                    const bStore = String(getColValue(b,'门店名称')||'').trim();
                    return bStore.localeCompare(aStore);
                });
                html += '<thead><tr style="background:#f8f9fd;"><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">门店</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">配送员</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:15%;">履约单号</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:10%;">商品名称</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">订单属性</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">是否化冻问题</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">店仓规范</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">配送规范</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:20%;">顾客原声</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;width:15%;">核实原因</th><th style="padding:10px 7px;text-align:center;font-weight:700;font-size:11px;color:#6b6b88;border-bottom:2px solid #e2e5ee;white-space:nowrap;width:5%;">是否有责</th></tr></thead><tbody>';
                data.forEach(row => {
                    const ct = coldThawManualMap.get(row._rowId) || {};
                    html += `<tr style="background:#fff;"><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(getColValue(row,'门店名称'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'-')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:15%;">${escapeHTML(getColValue(row,'履约单号')||getColValue(row,'配送单号')||'-')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:10%;">${escapeHTML(getColValue(row,'sku名称')||getColValue(row,'SKU名称'))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(ct.orderAttr||'内环')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(ct.isThawIssue||'是')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(ct.storeStandard||'不规范')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(ct.deliveryStandard||'不规范')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:20%;">${escapeHTML(getAppRefundDesc(row))}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:15%;word-break:break-all;line-height:1.3;">${escapeHTML(ct.verifyReason||'')}</td><td style="padding:8px 7px;border-bottom:1px solid #f0f2f7;text-align:center;color:#3a3a58;font-size:11px;width:5%;">${escapeHTML(ct.isResponsible||'有责')}</td></tr>`;
                });
            }
            html += '</tbody></table></div>';
            return html;
        };

        // 构建问单达成静态HTML（图片版）
        const buildAchievementImageHTML = () => {
            if (!selectedStore || !storeAchievements[selectedStore]) return '';
            const storeData = storeAchievements[selectedStore];
            const storeType = storeData.type;
            const limits = storeType === 'qianzhicang' ? qianzhicangLimits : shengxianLimits;
            const achievements = storeData.achievements;
            if (!achievementCategories.length) return '';
            
            // 收集无上限类目的值用于热力渲染
            const noLimitCats = achievementCategories.filter(cat => (limits[cat] || 0) === 0);
            const noLimitVals = noLimitCats.map(cat => achievements[cat] || 0).filter(v => v > 0);
            const maxNoLimit = noLimitVals.length > 0 ? Math.max(...noLimitVals) : 0;
            const minNoLimit = noLimitVals.length > 0 ? Math.min(...noLimitVals) : 0;
            
            let html = '<div style="background:#fff;border:1px solid #e6e8f0;border-radius:14px;padding:8px 10px;margin-bottom:8px;box-shadow:0 1px 3px rgba(0,0,0,0.04);">';
            html += '<div style="font-size:12px;font-weight:700;color:#1a1a2e;margin-bottom:8px;">📊 问单达成情况</div>';
            html += '<div style="display:grid;grid-template-columns:repeat(6,1fr);gap:4px;">';
            achievementCategories.forEach((category, catIndex) => {
                const actualValue = achievements[category] || 0;
                const limitValue = limits[category] || 0;
                const displayValue = formatAchievementValue(actualValue, category, catIndex);
                const displayLimit = formatLimitValue(limitValue, category, catIndex);
                
                // 颜色调度逻辑
                let valueColor = '#27ae60';
                if (limitValue > 0 && actualValue > limitValue) {
                    valueColor = '#e74c3c'; // 超标红色
                } else if (actualValue === 0) {
                    valueColor = '#b0b0c0'; // 等于0灰色
                } else if (limitValue === 0 && maxNoLimit > minNoLimit && actualValue > 0) {
                    // 无上限：热力渲染（最大黄色，最小绿色）
                    const ratio = (actualValue - minNoLimit) / (maxNoLimit - minNoLimit);
                    const hue = 120 - ratio * 60;
                    valueColor = `hsl(${Math.round(hue)}, 70%, 45%)`;
                } else if (limitValue > 0 && actualValue >= limitValue * 0.9) {
                    valueColor = '#e67e22';
                }
                html += '<div style="background:#fafbfd;border:1px solid #eef0f6;border-radius:5px;padding:4px 2px;text-align:center;"><div style="font-size:11px;color:#5c5c78;margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="' + escapeHTML(category) + '">' + escapeHTML(category) + '</div><div style="font-size:14px;font-weight:700;color:' + valueColor + ';">' + displayValue + '</div><div style="font-size:10px;color:#8b8ba8;margin-top:2px;">上限: ' + displayLimit + '</div></div>';
            });
            html += '</div></div>';
            return html;
        };

        const achievementImageHTML = buildAchievementImageHTML();

        // 构建责任分析图片HTML（使用flex布局，彻底避免表格溢出）
        const buildResponsibilityImageHTML = () => {
            const allViewData = [];
            const defaultFiltered = allData.filter(r => {
                const reason = (getColValue(r,'问题原因名称')||'').trim();
                return reason !== '冷链商品化冻' && reason !== '物流损';
            });
            if (selectedStore) {
                defaultFiltered.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore).forEach(r => allViewData.push(r));
                coldThawData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore).forEach(r => allViewData.push(r));
                logisticsDamageData.filter(r => String(getColValue(r,'门店名称')).trim() === selectedStore).forEach(r => allViewData.push(r));
                badReviewData.filter(r => String(getColValue(r,'门店')||'').trim() === selectedStore).forEach(r => allViewData.push(r));
            } else {
                defaultFiltered.forEach(r => allViewData.push(r));
                coldThawData.forEach(r => allViewData.push(r));
                logisticsDamageData.forEach(r => allViewData.push(r));
                badReviewData.forEach(r => allViewData.push(r));
            }
            if (!allViewData.length) return '';

            // 分类统计
            let totalNoResp = 0, totalResp = 0;
            let coldNoResp = 0, coldResp = 0;
            let logisticsNoResp = 0, logisticsResp = 0;
            let badReviewNoResp = 0, badReviewResp = 0;

            // 按问题原因名称统计
            const stats = new Map();
            allViewData.forEach(row => {
                let reason = '';
                if (badReviewData.includes(row)) {
                    const tag = (getColValue(row, '评价标签') || '').trim().replace(/^\d+[:：]/, '') || '';
                    reason = tag ? '差评-' + tag : '差评';
                } else {
                    reason = (getColValue(row, '问题原因名称') || '').trim() || '未知';
                }
                const map = badReviewData.includes(row) ? badReviewManualMap :
                            coldThawData.includes(row) ? coldThawManualMap :
                            logisticsDamageData.includes(row) ? logisticsManualMap : manualDataMap;
                const saved = map.get(row._rowId) || {};
                const isResponsible = saved.isResponsible || '有责';
                const isResp = isResponsible === '有责';
                if (isResp) totalResp++; else totalNoResp++;
                if (badReviewData.includes(row)) { if (isResp) badReviewResp++; else badReviewNoResp++; }
                else if (coldThawData.includes(row)) { if (isResp) coldResp++; else coldNoResp++; }
                else if (logisticsDamageData.includes(row)) { if (isResp) logisticsResp++; else logisticsNoResp++; }
                if (!stats.has(reason)) stats.set(reason, { name: reason, noResponsible: 0, responsible: 0, coldNoResp: 0, coldResp: 0, logisticsNoResp: 0, logisticsResp: 0 });
                const s = stats.get(reason);
                if (isResp) s.responsible++; else s.noResponsible++;
                if (coldThawData.includes(row)) { if (isResp) s.coldResp++; else s.coldNoResp++; }
                if (logisticsDamageData.includes(row)) { if (isResp) s.logisticsResp++; else s.logisticsNoResp++; }
            });

            // 排序：冷链商品化冻=0，物流损=1，其他按总数降序=2，差评=999
            const sortOrder = { '冷链商品化冻': 0, '物流损': 1 };
            const sortedStats = [...stats.values()].sort((a, b) => {
                const aOrder = sortOrder[a.name] !== undefined ? sortOrder[a.name] : (a.name.startsWith('差评') ? 999 : 2);
                const bOrder = sortOrder[b.name] !== undefined ? sortOrder[b.name] : (b.name.startsWith('差评') ? 999 : 2);
                if (aOrder !== bOrder) return aOrder - bOrder;
                const aTotal = a.noResponsible + a.responsible;
                const bTotal = b.noResponsible + b.responsible;
                return bTotal - aTotal;
            });
            // 有责率颜色计算
            const calcImgRate = (noResp, resp) => {
                const total = noResp + resp;
                const rate = total > 0 ? (resp / total * 100) : 0;
                const rateStr = rate.toFixed(1) + '%';
                let color = '#27ae60';
                if (rate >= 50) color = '#e74c3c';
                else if (rate >= 30) color = '#f39c12';
                return { rateStr, color };
            };

            // 汇总卡片（与面板一致，无蓝色背景）
            let html = '<div style="background:#fff;border:1px solid #e6e8f0;border-radius:14px;padding:8px;margin-bottom:8px;box-shadow:0 1px 3px rgba(0,0,0,0.04);">';
            html += '<div style="font-size:12px;font-weight:700;color:#1a1a2e;margin-bottom:6px;">📊 责任分析</div>';
            html += '<div style="background:#f0f2f7;border-radius:8px;padding:6px;margin-bottom:8px;border:1px solid #e6e8f0;">';
            html += '<div style="display:flex;flex-wrap:wrap;gap:6px;">';
            const tAll = totalNoResp + totalResp;
            const tRate = calcImgRate(totalNoResp, totalResp);
            html += `<div style="flex:1;min-width:100px;text-align:center;padding:4px;background:#fff;border-radius:6px;border:1px solid #e6e8f0;"><div style="font-size:10px;color:#5c5c78;">整体有责率</div><div style="font-size:16px;font-weight:700;color:${tRate.color};">${tRate.rateStr}</div><div style="font-size:9px;color:#8b8ba8;">(${totalResp}/${tAll})</div></div>`;
            const cTotal = coldNoResp + coldResp;
            const cRate = calcImgRate(coldNoResp, coldResp);
            html += `<div style="flex:1;min-width:80px;text-align:center;padding:4px;background:#fff;border-radius:6px;border:1px solid #e6e8f0;"><div style="font-size:10px;color:#5c5c78;">冷链化冻</div><div style="font-size:16px;font-weight:700;color:${cRate.color};">${cRate.rateStr}</div><div style="font-size:9px;color:#8b8ba8;">(${coldResp}/${cTotal})</div></div>`;
            const lTotal = logisticsNoResp + logisticsResp;
            const lRate = calcImgRate(logisticsNoResp, logisticsResp);
            html += `<div style="flex:1;min-width:80px;text-align:center;padding:4px;background:#fff;border-radius:6px;border:1px solid #e6e8f0;"><div style="font-size:10px;color:#5c5c78;">物流损</div><div style="font-size:16px;font-weight:700;color:${lRate.color};">${lRate.rateStr}</div><div style="font-size:9px;color:#8b8ba8;">(${logisticsResp}/${lTotal})</div></div>`;
            const bTotal = badReviewNoResp + badReviewResp;
            const bRate = calcImgRate(badReviewNoResp, badReviewResp);
            html += `<div style="flex:1;min-width:80px;text-align:center;padding:4px;background:#fff;border-radius:6px;border:1px solid #e6e8f0;"><div style="font-size:10px;color:#5c5c78;">差评</div><div style="font-size:16px;font-weight:700;color:${bRate.color};">${bRate.rateStr}</div><div style="font-size:9px;color:#8b8ba8;">(${badReviewResp}/${bTotal})</div></div>`;
            html += '</div></div>';

            // 表头行 - 百分比列宽不变，核实原因列固定25个中文字符宽度
            html += '<div style="display:flex;border-bottom:2px solid #e2e5ee;padding:3px 0;background:#f8f9fd;border-radius:4px 4px 0 0;">';
            html += '<div style="width:30%;padding:2px 4px;text-align:center;font-size:18px;font-weight:700;color:#6b6b88;">问题原因名称</div>';
            html += '<div style="width:10%;padding:2px 4px;text-align:center;font-size:18px;font-weight:700;color:#6b6b88;">总计</div>';
            html += '<div style="width:10%;padding:2px 4px;text-align:center;font-size:18px;font-weight:700;color:#6b6b88;">无责</div>';
            html += '<div style="width:10%;padding:2px 4px;text-align:center;font-size:18px;font-weight:700;color:#6b6b88;">有责</div>';
            html += '<div style="width:10%;padding:2px 4px;text-align:center;font-size:18px;font-weight:700;color:#6b6b88;">有责率</div>';
            html += '<div style="width:30%;padding:2px 4px;text-align:center;font-size:18px;font-weight:700;color:#6b6b88;">核实原因</div>';
            html += '</div>';
            // 数据行
            sortedStats.forEach(s => {
                const total = s.noResponsible + s.responsible;
                const rate = total > 0 ? (s.responsible / total * 100) : 0;
                const rateStr = rate.toFixed(1) + '%';
                let rateColor = '#27ae60';
                if (rate >= 50) rateColor = '#e74c3c';
                else if (rate >= 30) rateColor = '#f39c12';
                // 从页面输入框读取核实原因（优先用户值，否则读取动态默认值）
                const inputEl = document.querySelector('.responsibility-input[data-reason="' + escapeHTML(s.name).replace(/"/g, '\\"') + '"]');
                // 导出图片优先使用 data-default-value（含\n换行），用户修改过则用用户值
                const verifyReason = inputEl
                    ? (inputEl.classList.contains('placeholder-default')
                        ? (inputEl.dataset.defaultValue || '').trim()
                        : (inputEl.value || '').trim() || (inputEl.dataset.defaultValue || '').trim())
                    : '-';
                // 核实原因：先按\n分割，每段再按25个中文字符宽度换行
                const wrapReason = (text) => {
                    if (!text || text === '-') return escapeHTML(text);
                    const segments = text.split('\n');
                    const lines = [];
                    segments.forEach(seg => {
                        let currentLine = '';
                        let currentWidth = 0;
                        for (const ch of seg) {
                            const w = ch.charCodeAt(0) > 127 ? 2 : 1;
                            if (currentWidth + w > 50 && currentLine) {
                                lines.push(currentLine);
                                currentLine = ch;
                                currentWidth = w;
                            } else {
                                currentLine += ch;
                                currentWidth += w;
                            }
                        }
                        if (currentLine) lines.push(currentLine);
                    });
                    return lines.map(l => escapeHTML(l)).join('<br>');
                };
                // 差评标签红色加粗
                const isBadReview = s.name.startsWith('差评');
                const nameColor = isBadReview ? '#e74c3c' : '#3a3a58';
                const nameWeight = isBadReview ? '700' : '400';
                html += '<div style="display:flex;align-items:center;border-bottom:1px solid #f0f2f7;padding:3px 0;">';
                html += '<div style="width:30%;padding:2px 4px;text-align:center;font-size:18px;color:' + nameColor + ';font-weight:' + nameWeight + ';overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + escapeHTML(s.name) + '">' + escapeHTML(s.name) + '</div>';
                html += '<div style="width:10%;padding:2px 4px;text-align:center;font-size:18px;color:#3a3a58;">' + total + '</div>';
                html += '<div style="width:10%;padding:2px 4px;text-align:center;font-size:18px;color:#3a3a58;">' + s.noResponsible + '</div>';
                html += '<div style="width:10%;padding:2px 4px;text-align:center;font-size:18px;color:#3a3a58;">' + s.responsible + '</div>';
                html += '<div style="width:10%;padding:2px 4px;text-align:center;font-size:18px;color:' + rateColor + ';font-weight:700;">' + rateStr + '</div>';
                html += '<div style="width:30%;padding:2px 4px;text-align:center;font-size:18px;color:#3a3a58;line-height:1.3;">' + wrapReason(verifyReason) + '</div>';
                html += '</div>';
            });
            html += '</div>';
            return html;
        };

        const responsibilityImageHTML = buildResponsibilityImageHTML();

        // 根据选择动态构建报告
        const getDefaultData = () => allData.filter(r => !selectedStore || String(getColValue(r,'门店名称')).trim() === selectedStore).filter(r => { const reason = (getColValue(r,'问题原因名称')||'').trim(); return reason !== '冷链商品化冻' && reason !== '物流损'; });
        const getLogisticsData = () => logisticsDamageData.filter(r => !selectedStore || String(getColValue(r,'门店名称')).trim() === selectedStore);
        const getColdThawData = () => coldThawData.filter(r => !selectedStore || String(getColValue(r,'门店名称')).trim() === selectedStore);
        const getBadReviewData = () => badReviewData.filter(r => !selectedStore || String(getColValue(r,'门店')||'').trim() === selectedStore);

        const sectionConfigs = [
            { key: 'badReview', label: '差评明细', hasData: () => getBadReviewData().length > 0, buildContent: () => '<h2 style="margin:20px 0 10px;font-size:16px;color:#1a1a2e;">💬 差评明细</h2>' + buildStaticTable(getBadReviewData(), 'badReview') },
            { key: 'coldThaw', label: '冷链明细', hasData: () => getColdThawData().length > 0, buildContent: () => '<h2 style="margin:20px 0 10px;font-size:16px;color:#1a1a2e;">❄️ 冷链明细</h2>' + buildStaticTable(getColdThawData(), 'coldThaw') },
            { key: 'logistics', label: '物流损明细', hasData: () => getLogisticsData().length > 0, buildContent: () => '<h2 style="margin:20px 0 10px;font-size:16px;color:#1a1a2e;">📦 物流损明细</h2>' + buildStaticTable(getLogisticsData(), 'logistics') },
            { key: 'default', label: '问单明细', hasData: () => getDefaultData().length > 0, buildContent: () => '<h2 style="margin:20px 0 10px;font-size:16px;color:#1a1a2e;">📋 问单明细</h2>' + buildStaticTable(getDefaultData(), 'default') },
            { key: 'analysis', label: '问单分析', hasData: () => (achievementImageHTML + responsibilityImageHTML).length > 0, buildContent: () => achievementImageHTML + responsibilityImageHTML }
        ];

        const selectedConfigs = sectionConfigs.filter(c => selectedSections.includes(c.key) && c.hasData());

        // 获取工具显示名称和版本号用于导出报告
        const toolNameForExport = document.getElementById('pageTitle').textContent;
        const toolVersionForExport = document.getElementById('pageVersion').textContent;

        toast('🎨 正在生成图片报告，请稍候...');

        let exportedCount = 0;
        for (const config of selectedConfigs) {
            const isAnalysis = config.key === 'analysis';
            const sectionTitle = `${storeName}-${timestamp}${config.label}`;

            // 问单分析使用窄宽度+两行布局，其他视图使用原始宽度
            if (isAnalysis) {
                tempContainer.style.width = '720px';
                tempContainer.style.padding = '10px';
            } else {
                tempContainer.style.width = '1400px';
                tempContainer.style.padding = '20px';
            }

            let reportHTML;
            if (isAnalysis) {
                // 问单分析：窄宽度+与其他视图一致的布局
                reportHTML = `
                    <div style="max-width:700px;margin:0 auto;background:#fff;border-radius:10px;padding:12px;box-shadow:0 2px 12px rgba(0,0,0,0.05);">
                        <div style="text-align:center;padding:8px 0 4px;margin-bottom:10px;">
                            <h1 style="font-size:18px;font-weight:750;color:#1a1a2e;margin:0;">📋 ${config.label}</h1>
                        </div>
                        <div style="background:#fff;border:1px solid #e6e8f0;border-radius:8px;padding:8px 10px;margin-bottom:10px;display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap;">
                            <div style="text-align:center;flex:1;min-width:200px;">
                                <span style="font-weight:700;font-size:16px;color:#1a1a2e;">📍 门店：${storeName}</span>
                            </div>
                            <div style="text-align:center;flex:1;min-width:120px;">
                                <span style="font-weight:700;font-size:16px;color:#1a1a2e;">时间：${timestamp}</span>
                            </div>
                        </div>
                        ${config.buildContent()}
                        <div style="text-align:center;margin-top:12px;padding:8px;font-size:10px;color:#8b8ba8;">报告由${toolNameForExport} · ${toolVersionForExport}生成 · ${storeName} · ${timestamp}</div>
                    </div>
                `;
            } else {
                // 其他视图：原始宽度+原始布局
                reportHTML = `
                    <div style="max-width:1400px;margin:0 auto;background:#fff;border-radius:14px;padding:20px;box-shadow:0 2px 12px rgba(0,0,0,0.05);">
                        <div style="text-align:center;padding:12px 0 6px;margin-bottom:14px;">
                            <h1 style="font-size:24px;font-weight:750;color:#1a1a2e;margin:0;">📋 ${config.label}</h1>
                        </div>
                        <div style="background:#fff;border:1px solid #e6e8f0;border-radius:10px;padding:12px 14px;margin-bottom:12px;display:flex;gap:10px;align-items:center;justify-content:space-between;">
                            <div style="flex:1;text-align:center;">
                                <span style="font-weight:750;font-size:28px;color:#1a1a2e;">📍 门店：${storeName}</span>
                            </div>
                            <div style="flex:1;text-align:center;">
                                <span style="font-weight:750;font-size:28px;color:#1a1a2e;">${$('#dataSourceText').textContent}</span>
                            </div>
                        </div>
                        ${config.buildContent()}
                        <div style="text-align:center;margin-top:20px;padding:10px;font-size:12px;color:#8b8ba8;">报告由${toolNameForExport} · ${toolVersionForExport}生成 · ${storeName} · ${timestamp}</div>
                    </div>
                `;
            }

            tempContainer.innerHTML = reportHTML;

            try {
                const canvas = await html2canvas(tempContainer, {
                    scale: 2,
                    useCORS: true,
                    allowTaint: true,
                    backgroundColor: '#f0f2f7',
                    logging: false,
                    width: isAnalysis ? 740 : 1440,
                    height: tempContainer.scrollHeight
                });

                const link = document.createElement('a');
                link.download = sectionTitle + '.png';
                link.href = canvas.toDataURL('image/png', 1.0);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                exportedCount++;
            } catch (err) {
                console.error('导出' + config.label + '图片失败:', err);
            }
        }

        document.body.removeChild(tempContainer);
        toast('📥 已导出 ' + exportedCount + ' 张图片报告');
    }

    function closeAllPopups() { if (currentPopup) { currentPopup.remove(); currentPopup = null; } }
    document.addEventListener('click', function(e) {
        if (currentPopup && !currentPopup.contains(e.target) && !e.target.closest('.cell-btn') && !e.target.closest('.cell-clickable') && !e.target.closest('.ratio-main-bubble') && !e.target.closest('.cell-view-btn')) {
            closeAllPopups();
        }
    });

    function showDetailPopup(anchor, contentHTML, isPlainText = false) {
        closeAllPopups();
        const popup = document.createElement('div'); popup.className = 'detail-popup';
        if (isPlainText) popup.innerHTML = `<div style="max-height:42vh;overflow-y:auto;white-space:pre-wrap;">${escapeHTML(contentHTML)}</div>`;
        else popup.innerHTML = contentHTML;
        document.body.appendChild(popup);
        positionPopup(anchor, popup);
        currentPopup = popup;
        popup.querySelectorAll('.info-copy-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const txt = this.dataset.copy || '';
                if (navigator.clipboard) { navigator.clipboard.writeText(txt).then(() => { this.classList.add('copied'); setTimeout(() => this.classList.remove('copied'), 1500); }); }
            });
        });
    }

    function positionPopup(anchor, popup) {
        const rect = anchor.getBoundingClientRect();
        const pw = popup.offsetWidth || 200, ph = popup.offsetHeight || 150;
        let top = rect.bottom + 8, left = rect.left + rect.width/2 - pw/2;
        if (top + ph > window.innerHeight - 10) top = rect.top - ph - 8;
        if (top < 10) top = 10;
        if (left < 10) left = 10;
        else if (left + pw > window.innerWidth - 10) left = window.innerWidth - pw - 10;
        popup.style.top = top + 'px'; popup.style.left = left + 'px';
    }

    function makePopupRow(label, value) {
        return `<div class="info-row"><span class="info-label">${escapeHTML(label)}</span><span class="info-value">${escapeHTML(value||'-')}</span><span class="info-copy-btn" data-copy="${escapeHTML(value||'')}">📋 复制</span></div>`;
    }

    // 初始化
    ['filterBar','tableWrapper','statsPanel','achievementPanel'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display='none';
    });
    openGuideView('📂 选择物流问单Excel', '请选择要处理的"物流问单"',
        '<div class="file-upload-area" id="initUploadArea"><span class="upload-text-lg">📁 点击选择文件</span></div><div class="upload-hint">💡 选择大文件时页面可能出现短暂卡顿，请耐心等待加载完成。<br>如页面提示"无响应"，请点击<b>「等待」</b>按钮，切勿关闭页面。</div><div class="upload-progress-wrap" id="initProgressWrap"><div class="upload-progress-bar"><div class="upload-progress-fill" id="initProgressFill"></div></div><div class="upload-progress-text" id="initProgressText">准备中...</div></div>', '');
    document.getElementById('initUploadArea').addEventListener('click', () => hiddenFileInput.click());
    hiddenFileInput.addEventListener('change', e => { if (e.target.files[0]) handleFileUpload(e.target.files[0]); });
})();