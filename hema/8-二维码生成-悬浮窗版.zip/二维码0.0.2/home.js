/**
 * 当DOM加载完成后执行初始化函数
 */
document.addEventListener('DOMContentLoaded', () => {
    initSettingsPage();
    initQRCodePage();
    adjustContainerSize();
    setupSizeSelector();
});

/**
 * 设置尺寸选择器
 */
function setupSizeSelector() {
    const sizeButtons = document.querySelectorAll('.size-btn');
    
    if (sizeButtons.length > 0) {
        // 从存储加载保存的尺寸
        chrome.storage.local.get(['qrSize'], (result) => {
            const size = result.qrSize || 'medium';
            setActiveSize(size);
        });
        
        // 添加按钮点击事件
        sizeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const size = btn.dataset.size;
                setActiveSize(size);
                
                // 保存选择的尺寸
                chrome.storage.local.set({ qrSize: size });
                
                // 调整容器尺寸
                adjustContainerSize();
            });
        });
        
        function setActiveSize(size) {
            // 更新按钮激活状态
            sizeButtons.forEach(btn => {
                btn.classList.toggle('active', btn.dataset.size === size);
            });
        }
    }
}

/**
 * 调整容器大小
 */
function adjustContainerSize() {
    chrome.storage.local.get(['qrSize'], (result) => {
        const size = result.qrSize || 'medium';
        const container = document.querySelector('.container');
        if (container) {
            // 移除所有尺寸类
            container.classList.remove('small-size', 'medium-size', 'large-size');
            // 添加当前尺寸类
            container.classList.add(`${size}-size`);
            
            // 设置按钮激活状态
            const buttons = document.querySelectorAll('.size-btn');
            if (buttons.length > 0) {
                buttons.forEach(btn => {
                    btn.classList.toggle('active', btn.dataset.size === size);
                });
            }
        }
    });
}

/**
 * 初始化设置页面
 */
function initSettingsPage() {
    if (window.location.pathname.includes('options.html')) {
        loadSettings();
        setupSaveButton();
        
        const title = document.querySelector('h1');
        if (title) {
            const handleClick = () => goToAdmirePage();
            
            title.addEventListener('mouseover', function() {
                this.textContent = '👉🏻 赞赏 👈🏻';
                this.style.color = 'red';
                this.addEventListener('click', handleClick);
            });
            
            title.addEventListener('mouseout', function() {
                this.textContent = '👉🏻 设置 👈🏻';
                this.style.color = '#555';
                this.removeEventListener('click', handleClick);
            });
        }
    }
}

/**
 * 初始化二维码页面
 */
function initQRCodePage() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('text')) {
        setupQRCode();
    }
}

/**
 * 设置保存按钮功能
 */
function setupSaveButton() {
    const saveButton = document.getElementById('saveSettings');
    if (saveButton) {
        saveButton.addEventListener('click', () => {
            const settings = {
                enablePhoneNumberDetection: document.getElementById('enablePhoneNumberDetection').checked,
                enableVCardGeneration: document.getElementById('enableVCardGeneration').checked,
                enableNewContactFormat: document.getElementById('enableNewContactFormat').checked
            };
            
            chrome.storage.local.set(settings, () => {
                showSaveAlert();
            });
        });
    }
}

/**
 * 显示保存成功提示
 */
function showSaveAlert() {
    const alertDiv = document.createElement('div');
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '50%';
    alertDiv.style.left = '50%';
    alertDiv.style.transform = 'translate(-50%, -50%)';
    alertDiv.style.padding = '15px 25px';
    alertDiv.style.backgroundColor = '#0078d4';
    alertDiv.style.color = 'white';
    alertDiv.style.borderRadius = '8px';
    alertDiv.style.zIndex = '1000';
    alertDiv.style.textAlign = 'center';
    alertDiv.style.boxShadow = '0 6px 18px rgba(0, 0, 0, 0.2)';
    alertDiv.style.fontSize = '16px';
    alertDiv.textContent = '设置已保存！';
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        document.body.removeChild(alertDiv);
        window.close();
    }, 2000);
}

/**
 * 加载设置
 */
function loadSettings() {
    const settingsKeys = [
        'enablePhoneNumberDetection',
        'enableVCardGeneration',
        'enableNewContactFormat'
    ];
    
    chrome.storage.local.get(settingsKeys, (result) => {
        settingsKeys.forEach(key => {
            const element = document.getElementById(key);
            if (element) {
                element.checked = result[key] !== false;
            }
        });
    });
}

/**
 * 跳转到赞赏页面
 */
function goToAdmirePage() {
    if (document.getElementById('admire-overlay')) return;
    
    const overlay = document.createElement('div');
    overlay.id = 'admire-overlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    overlay.style.zIndex = '9999';
    overlay.style.display = 'flex';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';
    overlay.style.backdropFilter = 'blur(5px)';
    
    const container = document.createElement('div');
    container.style.backgroundColor = 'white';
    container.style.padding = '25px';
    container.style.borderRadius = '16px';
    container.style.boxShadow = '0 12px 30px rgba(0, 0, 0, 0.25)';
    container.style.textAlign = 'center';
    container.style.maxWidth = '320px';
    container.style.width = '90%';
    
    const img = document.createElement('img');
    img.src = './icons/admire.png';
    img.alt = '赞赏二维码';
    img.style.width = '250px';
    img.style.height = '250px';
    img.style.display = 'block';
    img.style.margin = '0 auto 15px';
    img.style.borderRadius = '8px';
    img.draggable = false;
    
    const text = document.createElement('p');
    text.textContent = '扫描上方二维码支持开发者';
    text.style.color = '#333';
    text.style.marginBottom = '5px';
    text.style.fontSize = '16px';
    text.style.fontWeight = '500';
    
    const note = document.createElement('p');
    note.textContent = '您的支持是我持续更新的动力';
    note.style.color = '#666';
    note.style.marginBottom = '15px';
    note.style.fontSize = '14px';
    
    container.appendChild(img);
    container.appendChild(text);
    container.appendChild(note);
    overlay.appendChild(container);
    document.body.appendChild(overlay);
    
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            document.body.removeChild(overlay);
        }
    });
}

/**
 * 设置二维码页面
 */
function setupQRCode() {
    const urlParams = new URLSearchParams(window.location.search);
    let text = urlParams.get('text') || 'options.html';
    chrome.storage.local.get([
        'enablePhoneNumberDetection',
        'enableVCardGeneration',
        'enableNewContactFormat'
    ], (result) => {
        const settings = {
            enablePhoneNumberDetection: result.enablePhoneNumberDetection !== false,
            enableVCardGeneration: result.enableVCardGeneration !== false,
            enableNewContactFormat: result.enableNewContactFormat !== false
        };
        
        const qrText = processInputText(text, settings);
        document.getElementById('url').value = qrText;
        
        const qrcodeElement = document.getElementById('qrcode');
        new QRCode(qrcodeElement, {
            text: qrText,
            width: 200,
            height: 200,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
        });
        
        qrcodeElement.addEventListener('dblclick', goToAdmirePage);
    });
}

/**
 * 处理输入文本
 */
function processInputText(inputText, settings) {
    const minutePattern = /^(194\d{17})(?:分钟：\d+单)?$/;
    if (minutePattern.test(inputText) && 
       (inputText.endsWith('40') || inputText.includes('分钟：'))) {
        return inputText.slice(0, 18);
    }
    
    if (settings.enablePhoneNumberDetection && /^1\d{10}$/.test(inputText)) {
        return `tel:${inputText}`;
    }
    
    if (settings.enableVCardGeneration) {
        const namePhonePattern = /([\u4e00-\u9fa5]+)[(（](1\d{10})[)）]/;
        const matchResult = inputText.match(namePhonePattern);
        if (matchResult && matchResult.length === 3) {
            const [_, name, phone] = matchResult;
            return `BEGIN:VCARD
VERSION:3.0
N:${name}
FN:${name}
TEL;TYPE=CELL:${phone}
END:VCARD`;
        }
    }
    
    if (settings.enableNewContactFormat) {
        const newContactPattern = /([\u4e00-\u9fa5]+)\s+(1\d{10})/;
        const matchResult = inputText.match(newContactPattern);
        if (matchResult && matchResult.length === 3) {
            const [_, name, phone] = matchResult;
            return `BEGIN:VCARD
VERSION:3.0
N:${name}
FN:${name}
TEL;TYPE=CELL:${phone}
END:VCARD`;
        }
    }
    
    return inputText;
}