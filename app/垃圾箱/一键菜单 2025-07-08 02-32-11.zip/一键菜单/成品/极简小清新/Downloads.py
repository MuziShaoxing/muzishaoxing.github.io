import os
from datetime import datetime

class DirectoryTreeGenerator:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.folder_name = os.path.basename(folder_path)
        self.html_content = []
        self.generated_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def generate_html(self):
        self.html_content.append('<!DOCTYPE html>')
        self.html_content.append('<html lang="zh-CN">')
        self.html_content.append('<head>')
        self.html_content.append('<meta charset="UTF-8">')
        self.html_content.append('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
        self.html_content.append(f'<title>{self.folder_name} 目录结构</title>')
        # 引入Font Awesome图标
        self.html_content.append('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">')
        self.html_content.append('<style>')
        self.html_content.append('''
            :root {
                --primary-color: #4a90e2;
                --secondary-color: #347ab7;
                --bg-color: #f9fafc;
                --card-bg: #ffffff;
                --text-color: #333333;
                --border-color: #eaeaea;
                --hover-color: #f0f7ff;
                --shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
                --transition: all 0.2s ease;
                --spacing: 12px;
            }

            body.dark {
                --bg-color: #181818;
                --card-bg: #242424;
                --text-color: #ffffff;
                --border-color: #333333;
                --hover-color: #333333;
                --primary-color: #74c3ff;
            }

            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            
            body {
                font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
                background-color: var(--bg-color);
                color: var(--text-color);
                padding: 15px;
                line-height: 1.6;
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            
            .container {
                max-width: 900px;
                width: 100%;
                background-color: var(--card-bg);
                border-radius: 8px;
                box-shadow: var(--shadow);
                padding: 25px;
                margin-top: 20px;
                transition: var(--transition);
            }
            
            .header {
                text-align: center;
                margin-bottom: 20px;
                padding-bottom: 15px;
                border-bottom: 1px solid var(--border-color);
            }
            
            h1 {
                color: var(--primary-color);
                font-size: 1.7rem;
                font-weight: 500;
                margin-bottom: 8px;
            }
            
            .search-container {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 12px;
                margin: 20px 0;
            }
            
            .search-container button {
                background: none;
                border: 1px solid var(--border-color);
                width: 40px;
                height: 40px;
                border-radius: 6px;
                cursor: pointer;
                transition: var(--transition);
                display: flex;
                align-items: center;
                justify-content: center;
                color: var(--text-color);
            }
            
            .search-container button:hover {
                background-color: var(--hover-color);
                border-color: var(--primary-color);
                color: var(--primary-color);
            }
            
            .search-container input {
                flex: 1;
                padding: 10px 15px;
                border: 1px solid var(--border-color);
                border-radius: 6px;
                font-size: 15px;
                transition: var(--transition);
                min-width: 250px;
                max-width: 500px;
            }
            
            .search-container input:focus {
                outline: none;
                border-color: var(--primary-color);
                box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
            }
            
            .tree {
                list-style: none;
                margin: 0;
                padding: 0;
            }
            
            .tree li {
                margin-bottom: 8px;
                padding: 12px 15px;
                position: relative;
                background-color: var(--card-bg);
                border-radius: 6px;
                border: 1px solid var(--border-color);
                transition: var(--transition);
                cursor: pointer;
            }
            
            .tree li:hover {
                background-color: var(--hover-color);
                border-color: var(--primary-color);
            }
            
            .tree .directory-wrapper {
                display: flex;
                align-items: center;
            }
            
            .tree .toggle {
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 10px;
                color: var(--primary-color);
            }
            
            .tree .directory, .tree .file-name {
                flex: 1;
                font-size: 15px;
            }
            
            .tree ul {
                display: none;
                padding-left: 20px;
                margin-top: 8px;
                list-style: none;
            }
            
            .tree li.open > ul {
                display: block;
            }
            
            .tree .file {
                display: flex;
                align-items: center;
                padding-left: 30px;
            }
            
            .file-icon {
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 10px;
                color: var(--primary-color);
            }
            
            a {
                text-decoration: none;
                color: inherit;
            }
            
            a:hover {
                color: var(--primary-color);
            }
            
            .generated-time {
                text-align: center;
                margin-top: 30px;
                padding-top: 15px;
                border-top: 1px solid var(--border-color);
                color: #666;
                font-size: 14px;
                opacity: 0.8;
            }
            
            .time-icon {
                margin-right: 6px;
                color: var(--primary-color);
            }
        ''')
        self.html_content.append('</style>')
        self.html_content.append('</head>')
        self.html_content.append('<body>')
        self.html_content.append('<div class="container">')
        self.html_content.append('<div class="header">')
        self.html_content.append(f'<h1>{self.folder_name} 目录结构</h1>')
        self.html_content.append('</div>')
        self.html_content.append('<div class="search-container">')
        self.html_content.append('<button id="toggle-theme"><i class="fas fa-moon"></i></button>')
        self.html_content.append('<button id="toggle-all"><i class="fas fa-folder-open"></i></button>')
        self.html_content.append('<input type="text" id="search-input" placeholder="搜索文件或文件夹...">')
        self.html_content.append('<button id="reset-search"><i class="fas fa-redo"></i></button>')
        self.html_content.append('</div>')
        self.html_content.append('<ul class="tree">')
        self.process_directory(self.folder_path)
        self.html_content.append('</ul>')
        self.html_content.append(f'<div class="generated-time">')
        self.html_content.append('<i class="fas fa-clock time-icon"></i>')
        self.html_content.append(f'<span>生成时间: {self.generated_time}</span>')
        self.html_content.append('</div>')
        self.html_content.append('</div>')
        self.html_content.append('<script>')
        self.html_content.append('''
            document.addEventListener('DOMContentLoaded', function() {
                // 目录项点击事件
                document.querySelectorAll('.tree .directory-wrapper').forEach(wrapper => {
                    wrapper.addEventListener('click', function(e) {
                        if(e.target === this.querySelector('.toggle') || 
                           e.target.parentElement === this.querySelector('.toggle')) {
                            const parent = this.parentElement;
                            parent.classList.toggle('open');
                            const icon = this.querySelector('i');
                            icon.className = parent.classList.contains('open') 
                                ? 'fas fa-folder-open' : 'fas fa-folder';
                        }
                    });
                });

                // 主题切换
                const toggleTheme = document.getElementById('toggle-theme');
                toggleTheme.addEventListener('click', function() {
                    document.body.classList.toggle('dark');
                    localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
                    this.querySelector('i').className = 
                        document.body.classList.contains('dark') ? 'fas fa-sun' : 'fas fa-moon';
                });

                // 初始化主题
                if (localStorage.getItem('theme') === 'dark') {
                    document.body.classList.add('dark');
                    toggleTheme.querySelector('i').className = 'fas fa-sun';
                }

                // 展开/折叠全部
                const toggleAll = document.getElementById('toggle-all');
                toggleAll.addEventListener('click', function() {
                    const isExpanded = this.querySelector('i').className === 'fas fa-folder-open';
                    document.querySelectorAll('.tree li').forEach(li => {
                        const icon = li.querySelector('.directory-wrapper i');
                        if(icon) {
                            li.classList.toggle('open', !isExpanded);
                            icon.className = isExpanded ? 'fas fa-folder' : 'fas fa-folder-open';
                        }
                    });
                    this.querySelector('i').className = isExpanded ? 'fas fa-folder' : 'fas fa-folder-open';
                });

                // 搜索功能
                const searchInput = document.getElementById('search-input');
                const resetSearch = document.getElementById('reset-search');
                
                searchInput.addEventListener('input', function() {
                    const term = this.value.toLowerCase();
                    document.querySelectorAll('.tree li').forEach(li => {
                        const text = li.textContent.toLowerCase();
                        const isMatch = text.includes(term);
                        li.style.display = isMatch ? '' : 'none';
                        
                        if(isMatch) {
                            let parent = li.parentElement;
                            while(parent && parent.classList.contains('tree') === false) {
                                parent.style.display = '';
                                parent.classList.add('open');
                                const icon = parent.querySelector('.directory-wrapper i');
                                if(icon) icon.className = 'fas fa-folder-open';
                                parent = parent.parentElement;
                            }
                        }
                    });
                });

                resetSearch.addEventListener('click', function() {
                    searchInput.value = '';
                    document.querySelectorAll('.tree li').forEach(li => {
                        li.style.display = '';
                    });
                    const toggleAllIcon = document.getElementById('toggle-all').querySelector('i');
                    toggleAllIcon.className = 'fas fa-folder-open';
                    document.querySelectorAll('.tree li').forEach(li => {
                        li.classList.add('open');
                        const icon = li.querySelector('.directory-wrapper i');
                        if(icon) icon.className = 'fas fa-folder-open';
                    });
                });
            });
        ''')
        self.html_content.append('</script>')
        self.html_content.append('</body>')
        self.html_content.append('</html>')

    def process_directory(self, directory_path):
        dir_name = os.path.basename(directory_path)
        self.html_content.append('<li>')
        self.html_content.append('<div class="directory-wrapper">')
        self.html_content.append('<span class="toggle"><i class="fas fa-folder"></i></span>')
        self.html_content.append(f'<span class="directory">{dir_name}</span>')
        self.html_content.append('</div>')
        self.html_content.append('<ul>')

        try:
            contents = os.listdir(directory_path)
            dirs = []
            files = []
            for item in contents:
                if item.startswith('.') or item.lower().endswith('.html'):
                    continue
                item_path = os.path.join(directory_path, item)
                if os.path.isdir(item_path):
                    dirs.append(item)
                else:
                    files.append(item)
            
            dirs.sort(key=lambda x: x.lower())
            files.sort(key=lambda x: x.lower())
            
            for item in files:
                item_path = os.path.join(directory_path, item)
                self.html_content.append('<li>')
                self.html_content.append('<div class="file">')
                self.html_content.append('<span class="file-icon"><i class="fas fa-file"></i></span>')
                self.html_content.append(f'<a href="./{os.path.relpath(item_path, self.folder_path).replace("\\", "/")}">{item}</a>')
                self.html_content.append('</div>')
                self.html_content.append('</li>')
                
            for item in dirs:
                item_path = os.path.join(directory_path, item)
                self.process_directory(item_path)
                
        except Exception as e:
            print(f"无法访问目录 {directory_path}: {e}")

        self.html_content.append('</ul>')
        self.html_content.append('</li>')

def main():
    folder_path = input("请输入文件夹路径: ").strip()
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        print("指定的路径不存在或不是一个文件夹，请检查后重新输入。")
        return

    generator = DirectoryTreeGenerator(folder_path)
    generator.generate_html()

    html_output = os.path.join(folder_path, "目录树.html")
    with open(html_output, 'w', encoding='utf-8') as f:
        f.write('\n'.join(generator.html_content))

    print(f"HTML文件已生成：{html_output}")
    print(f"生成时间: {generator.generated_time}")

if __name__ == "__main__":
    main()