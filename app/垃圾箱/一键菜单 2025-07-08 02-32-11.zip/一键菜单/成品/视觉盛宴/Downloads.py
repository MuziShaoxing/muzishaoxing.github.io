import os
from datetime import datetime

class DirectoryTreeGenerator:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.html_content = []
        self.generated_html_name = "目录树.html"
        self.icon_path = os.path.join(folder_path, "./.APP/favicon.ico")
        self.has_icon = os.path.exists(self.icon_path)

    def generate_html(self):
        # 获取文件夹名
        folder_name = os.path.basename(self.folder_path)
        
        self.html_content.append('<!DOCTYPE html>')
        self.html_content.append('<html lang="zh-CN">')
        self.html_content.append('<head>')
        self.html_content.append('<meta charset="UTF-8">')
        self.html_content.append('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
        
        # 添加生成时间
        generation_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.html_content.append(f'<meta name="generation-time" content="{generation_time}">')
        
        # 添加网站图标（如果存在）
        if self.has_icon:
            self.html_content.append(f'<link rel="icon" href="./.APP/favicon.ico" type="image/x-icon">')
            self.html_content.append(f'<link rel="shortcut icon" href="./.APP/favicon.ico" type="image/x-icon">')
        
        self.html_content.append(f'<title>{folder_name} - 目录</title>')
        # 添加Material Icons字体
        self.html_content.append('<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">')
        self.html_content.append('<style>')
        self.html_content.append('''
            :root {
                /* 默认主题 - 蓝色 */
                --background-color: #f9fbff;
                --container-bg: #ffffff;
                --text-color: #4a5a7a;
                --primary-color: #6c8dcd;
                --secondary-color: #7da3e6;
                --light-color: #f3f8ff;
                --dark-color: #1d2430;
                --gray-color: #273142;
                --shadow-color: rgba(108, 141, 205, 0.08);
                --dark-shadow: rgba(0, 0, 0, 0.2);
                --button-size: 46px;
                --spacing: 15px;
                --transition-time: 0.3s;
                --border-radius: 12px;
            }
            
            /* 绿色主题 */
            .theme-green {
                --background-color: #f5fbf8;
                --container-bg: #ffffff;
                --text-color: #4a7a6c;
                --primary-color: #5daa8e;
                --secondary-color: #6dc5a3;
                --light-color: #f0faf5;
                --dark-color: #1c2824;
                --gray-color: #24322d;
                --shadow-color: rgba(93, 170, 142, 0.08);
            }
            
            /* 紫色主题 */
            .theme-purple {
                --background-color: #f9f7ff;
                --container-bg: #ffffff;
                --text-color: #5a4a7a;
                --primary-color: #8d6ccd;
                --secondary-color: #a37de6;
                --light-color: #f3f0ff;
                --dark-color: #201d30;
                --gray-color: #2a273f;
                --shadow-color: rgba(141, 108, 205, 0.08);
            }
            
            /* 红色主题 */
            .theme-red {
                --background-color: #fff9f9;
                --container-bg: #ffffff;
                --text-color: #7a4a4a;
                --primary-color: #cd6c6c;
                --secondary-color: #e67d7d;
                --light-color: #fff0f0;
                --dark-color: #301d1d;
                --gray-color: #3f2727;
                --shadow-color: rgba(205, 108, 108, 0.08);
            }
            
            /* 橙色主题 */
            .theme-orange {
                --background-color: #fffbf5;
                --container-bg: #ffffff;
                --text-color: #7a684a;
                --primary-color: #cd9a6c;
                --secondary-color: #e6b07d;
                --light-color: #fff7f0;
                --dark-color: #30241d;
                --gray-color: #3f2f27;
                --shadow-color: rgba(205, 154, 108, 0.08);
            }
            
            /* 深蓝主题 */
            .theme-deepblue {
                --background-color: #f5f9ff;
                --container-bg: #ffffff;
                --text-color: #4a5a7a;
                --primary-color: #3a6ea5;
                --secondary-color: #4a8cc7;
                --light-color: #f0f5ff;
                --dark-color: #1a222e;
                --gray-color: #222c3d;
                --shadow-color: rgba(58, 110, 165, 0.08);
            }

            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            body {
                font-family: 'Segoe UI', 'Microsoft YaHei', 'Roboto', sans-serif;
                background-color: var(--background-color);
                color: var(--text-color);
                padding: 20px;
                transition: background-color var(--transition-time), color var(--transition-time);
                display: flex;
                flex-direction: column;
                align-items: center;
                min-height: 100vh;
                background-image: linear-gradient(135deg, var(--background-color) 0%, var(--light-color) 100%);
            }
            .container {
                max-width: 1000px;
                width: 100%;
                background-color: var(--container-bg);
                padding: 30px;
                border-radius: var(--border-radius);
                box-shadow: 0 8px 25px var(--shadow-color);
                transition: all 0.4s ease;
                margin-top: 20px;
                position: relative;
                overflow: hidden;
            }
            .container::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background: linear-gradient(90deg, var(--primary-color), var(--secondary-color), var(--primary-color));
                border-radius: var(--border-radius) var(--border-radius) 0 0;
            }
            .header {
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 25px;
                flex-wrap: wrap;
                gap: 15px;
                padding-bottom: 15px;
                border-bottom: 1px solid #e8f0ff;
            }
            .logo {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .logo-icon {
                /* 增大图标尺寸 */
                width: 52px;
                height: 52px;
                object-fit: contain;
                border-radius: 0%;
                box-shadow: 0 2px 8px rgba(var(--primary-color-rgb), 0.15);
            }
            .logo-text {
                /* 增大文字尺寸并加粗 */
                font-size: 2.2em;
                font-weight: 700;
                color: var(--text-color);
                letter-spacing: 0.5px;
                background: linear-gradient(135deg, var(--primary-color), var(--text-color));
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                /* 添加文字阴影增强可读性 */
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
            }
            .search-container {
                display: flex;
                justify-content: center;
                align-items: center;
                margin-bottom: 30px;
                flex-wrap: wrap;
                gap: var(--spacing);
                position: relative;
            }
            .button-group {
                display: flex;
                gap: var(--spacing);
            }
            .search-container button {
                background: var(--light-color);
                color: var(--primary-color);
                border: 1px solid #e0ebff;
                width: var(--button-size);
                height: var(--button-size);
                border-radius: 50%;
                cursor: pointer;
                font-size: 1.2em;
                transition: all var(--transition-time);
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                box-shadow: 0 2px 8px rgba(var(--primary-color-rgb), 0.08);
            }
            .search-container button:hover {
                background-color: #e6f0ff;
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(var(--primary-color-rgb), 0.12);
            }
            .search-container button:active {
                transform: translateY(0);
                box-shadow: 0 2px 6px rgba(var(--primary-color-rgb), 0.08);
            }
            .search-container input {
                flex: 1;
                padding: 14px 20px;
                border: 1px solid #e0ebff;
                border-radius: 30px;
                font-size: 16px;
                transition: all var(--transition-time);
                max-width: 600px;
                min-width: 200px;
                background: #fafcff;
                color: var(--text-color);
                box-shadow: 0 2px 8px rgba(var(--primary-color-rgb), 0.05);
            }
            .search-container input:focus {
                border-color: var(--primary-color);
                outline: none;
                box-shadow: 0 0 0 3px rgba(var(--primary-color-rgb), 0.15);
                background: #fff;
            }
            .search-container input::placeholder {
                color: #b8cbe8;
            }
            .tree {
                margin: 0;
                padding: 0;
                list-style: none;
            }
            .tree li {
                margin: 0;
                padding: 10px 0;
                position: relative;
                background-color: var(--container-bg);
                border-radius: 8px;
                transition: all var(--transition-time);
                cursor: pointer;
                padding: 12px 18px;
                box-shadow: 0 2px 6px rgba(var(--primary-color-rgb), 0.04);
                margin-bottom: 8px;
                border-left: 3px solid transparent;
            }
            .tree li:hover {
                background-color: var(--light-color);
                border-left-color: var(--primary-color);
                transform: translateX(5px);
            }
            .tree .directory-wrapper {
                display: flex;
                align-items: center;
                padding-left: 10px;
            }
            .tree .toggle {
                margin-right: 12px;
                cursor: pointer;
                user-select: none;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 28px;
                height: 28px;
                color: var(--primary-color);
                font-size: 14px;
                flex-shrink: 0;
                background: #e6f0ff;
                border-radius: 50%;
            }
            .material-icons {
                font-size: 20px;
                transition: transform 0.2s;
            }
            .tree .directory {
                font-weight: 600;
                color: var(--text-color);
                font-size: 1.05em;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .tree .directory::before {
                content: '';
                display: inline-block;
                width: 24px;
                height: 24px;
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236c8dcd'%3E%3Cpath d='M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z'/%3E%3C/svg%3E");
                background-size: contain;
            }
            .theme-green .tree .directory::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%235daa8e'%3E%3Cpath d='M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z'/%3E%3C/svg%3E");
            }
            .theme-purple .tree .directory::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%238d6ccd'%3E%3Cpath d='M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z'/%3E%3C/svg%3E");
            }
            .theme-red .tree .directory::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23cd6c6c'%3E%3Cpath d='M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z'/%3E%3C/svg%3E");
            }
            .theme-orange .tree .directory::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23cd9a6c'%3E%3Cpath d='M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z'/%3E%3C/svg%3E");
            }
            .theme-deepblue .tree .directory::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%233a6ea5'%3E%3Cpath d='M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z'/%3E%3C/svg%3E");
            }
            .tree .file {
                display: flex;
                align-items: center;
                padding-left: 40px;
                position: relative;
            }
            .tree .file::before {
                content: '';
                position: absolute;
                left: 15px;
                width: 24px;
                height: 24px;
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%237da3e6'%3E%3Cpath d='M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6z'/%3E%3C/svg%3E");
                background-size: contain;
            }
            .theme-green .tree .file::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236dc5a3'%3E%3Cpath d='M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6z'/%3E%3C/svg%3E");
            }
            .theme-purple .tree .file::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23a37de6'%3E%3Cpath d='M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6z'/%3E%3C/svg%3E");
            }
            .theme-red .tree .file::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23e67d7d'%3E%3Cpath d='M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6z'/%3E%3C/svg%3E");
            }
            .theme-orange .tree .file::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23e6b07d'%3E%3Cpath d='M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6z'/%3E%3C/svg%3E");
            }
            .theme-deepblue .tree .file::before {
                background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%234a8cc7'%3E%3Cpath d='M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6z'/%3E%3C/svg%3E");
            }
            .tree .file a {
                text-decoration: none;
                color: var(--text-color);
                transition: all var(--transition-time);
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                padding: 4px 0;
                border-bottom: 1px dashed transparent;
            }
            .tree .file a:hover {
                color: var(--primary-color);
                border-bottom: 1px dashed var(--primary-color);
                text-decoration: none;
            }
            .tree ul {
                display: none;
                padding-left: 25px;
                margin-top: 10px;
                list-style: none;
                border-left: 1px dashed #e0ebff;
                margin-left: 12px;
            }
            .tree li.open > ul {
                display: block;
            }

            /* 暗色主题 */
            body.dark {
                --background-color: var(--dark-color);
                --container-bg: var(--gray-color);
                --text-color: #d5e3ff;
                --primary-color: var(--secondary-color);
                --light-color: #222b3d;
                --shadow-color: rgba(0, 15, 30, 0.3);
                background-image: linear-gradient(135deg, var(--dark-color) 0%, #171e2a 100%);
            }

            /* 高分辨率屏幕上的图标大小 */
            @media (min-resolution: 2dppx) {
                .material-icons {
                    font-size: 22px;
                }
            }

            /* 平板上的布局调整 */
            @media (max-width: 992px) {
                .container {
                    padding: 20px 15px;
                }
                .search-container {
                    flex-direction: column;
                    gap: 10px;
                }
                .search-container input {
                    width: 100%;
                    max-width: 100%;
                }
                .button-group {
                    width: 100%;
                    justify-content: center;
                }
            }

            /* 手机上的布局优化 */
            @media (max-width: 576px) {
                body {
                    padding: 10px;
                }
                .container {
                    padding: 20px 12px;
                    margin-top: 10px;
                }
                .logo-text {
                    /* 在移动端也增大标题文字大小 */
                    font-size: 1.8em;
                }
                .logo-icon {
                    /* 在移动端也增大图标尺寸 */
                    width: 44px;
                    height: 44px;
                }
                .search-container input {
                    padding: 12px 16px;
                }
                .tree li {
                    padding: 10px 14px;
                }
                .tree .file {
                    padding-left: 35px;
                }
                .tree .file::before {
                    left: 10px;
                }
                .tree ul {
                    padding-left: 20px;
                }
            }

            /* 重置按钮样式 */
            #reset-search {
                background-color: var(--light-color);
                border-color: #e0ebff;
                color: var(--primary-color);
                display: flex;
                align-items: center;
                justify-content: center;
                width: var(--button-size);
                height: var(--button-size);
                border-radius: 50%;
                cursor: pointer;
                font-size: 1.2em;
                transition: all var(--transition-time);
            }

            #reset-search:hover {
                background-color: #e6f0ff;
            }
            
            /* 滚动条样式 */
            .tree {
                max-height: 65vh;
                overflow-y: auto;
                padding-right: 8px;
                margin-top: 10px;
            }
            
            /* 自定义滚动条 */
            .tree::-webkit-scrollbar {
                width: 8px;
            }
            
            .tree::-webkit-scrollbar-track {
                background: rgba(var(--primary-color-rgb), 0.05);
                border-radius: 4px;
            }
            
            .tree::-webkit-scrollbar-thumb {
                background: rgba(var(--primary-color-rgb), 0.15);
                border-radius: 4px;
            }
            
            .tree::-webkit-scrollbar-thumb:hover {
                background: rgba(var(--primary-color-rgb), 0.25);
            }
            
            body.dark .tree::-webkit-scrollbar-track {
                background: rgba(29, 36, 48, 0.3);
            }
            
            body.dark .tree::-webkit-scrollbar-thumb {
                background: rgba(125, 163, 230, 0.25);
            }
            
            body.dark .tree::-webkit-scrollbar-thumb:hover {
                background: rgba(125, 163, 230, 0.35);
            }

            /* 全局操作按钮样式 */
            .global-action {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 8px 18px;
                background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
                color: white;
                border: none;
                border-radius: 30px;
                cursor: pointer;
                font-size: 15px;
                transition: all var(--transition-time);
                height: var(--button-size);
                box-shadow: 0 4px 12px rgba(var(--primary-color-rgb), 0.2);
            }

            .global-action:hover {
                background: linear-gradient(135deg, var(--primary-color-dark), var(--secondary-color-dark));
                transform: translateY(-3px);
                box-shadow: 0 6px 15px rgba(var(--primary-color-rgb), 0.25);
            }

            .global-action:active {
                transform: translateY(0);
                box-shadow: 0 2px 8px rgba(var(--primary-color-rgb), 0.2);
            }

            /* 高亮匹配项 */
            .match-highlight {
                background-color: rgba(var(--primary-color-rgb), 0.12) !important;
                border: 1px solid rgba(var(--primary-color-rgb), 0.2) !important;
                box-shadow: 0 0 10px rgba(var(--primary-color-rgb), 0.08) !important;
            }
            
            /* 动画效果 */
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .container {
                animation: fadeIn 0.5s ease-out;
            }
            
            /* 主题选择器 */
            .theme-selector {
                display: flex;
                justify-content: center;
                gap: 8px;
                margin-top: 15px;
                flex-wrap: wrap;
            }
            
            .theme-btn {
                width: 30px;
                height: 30px;
                border-radius: 50%;
                border: 2px solid transparent;
                cursor: pointer;
                transition: all 0.2s ease;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            
            .theme-btn:hover {
                transform: scale(1.1);
                box-shadow: 0 3px 8px rgba(0,0,0,0.15);
            }
            
            .theme-btn.active {
                border-color: #fff;
                box-shadow: 0 0 0 2px var(--primary-color);
            }
            
            .theme-default { background: linear-gradient(135deg, #6c8dcd, #7da3e6); }
            .theme-green { background: linear-gradient(135deg, #5daa8e, #6dc5a3); }
            .theme-purple { background: linear-gradient(135deg, #8d6ccd, #a37de6); }
            .theme-red { background: linear-gradient(135deg, #cd6c6c, #e67d7d); }
            .theme-orange { background: linear-gradient(135deg, #cd9a6c, #e6b07d); }
            .theme-deepblue { background: linear-gradient(135deg, #3a6ea5, #4a8cc7); }
        ''')
        self.html_content.append('</style>')
        self.html_content.append('</head>')
        self.html_content.append('<body class="theme-default">')
        self.html_content.append('<div class="container">')
        
        # 添加logo区域
        self.html_content.append('<div class="header">')
        if self.has_icon:
            self.html_content.append(f'<div class="logo">')
            self.html_content.append(f'<img src="./.APP/favicon.ico" alt="Folder Icon" class="logo-icon">')
            self.html_content.append(f'<div class="logo-text">{folder_name}</div>')
            self.html_content.append('</div>')
        else:
            self.html_content.append(f'<div class="logo">')
            self.html_content.append(f'<div class="logo-text">{folder_name}</div>')
            self.html_content.append('</div>')
        
        # 添加生成时间显示
        self.html_content.append(f'<p style="font-size: 0.8em; color: var(--text-color); margin-top: 5px;">生成时间：{generation_time}</p>')
        
        self.html_content.append('</div>')
        
        self.html_content.append('<div class="search-container">')
        self.html_content.append('<div class="button-group">')
        self.html_content.append('<button id="toggle-theme" aria-label="切换主题"><span class="material-icons">light_mode</span></button>')
        self.html_content.append('<button id="toggle-all" aria-label="展开/折叠全部">')
        self.html_content.append('<span class="material-icons">unfold_more</span>')
        self.html_content.append('</button>')
        self.html_content.append('</div>')
        self.html_content.append('<input type="text" id="search-input" placeholder="搜索文件或文件夹...">')
        self.html_content.append('<div class="button-group">')
        self.html_content.append('<button id="reset-search" aria-label="重置搜索"><span class="material-icons">refresh</span></button>')
        self.html_content.append('</div>')
        self.html_content.append('</div>')
        self.html_content.append('<ul class="tree">')
        self.process_directory(self.folder_path)
        self.html_content.append('</ul>')
        
        # 添加主题选择器
        self.html_content.append('<div class="theme-selector">')
        self.html_content.append('<div class="theme-btn theme-default active" data-theme="default" title="默认主题"></div>')
        self.html_content.append('<div class="theme-btn theme-green" data-theme="green" title="绿色主题"></div>')
        self.html_content.append('<div class="theme-btn theme-purple" data-theme="purple" title="紫色主题"></div>')
        self.html_content.append('<div class="theme-btn theme-red" data-theme="red" title="红色主题"></div>')
        self.html_content.append('<div class="theme-btn theme-orange" data-theme="orange" title="橙色主题"></div>')
        self.html_content.append('<div class="theme-btn theme-deepblue" data-theme="deepblue" title="深蓝主题"></div>')
        self.html_content.append('</div>')
        
        self.html_content.append('</div>')
        self.html_content.append('<script>')
        self.html_content.append('''
            document.addEventListener('DOMContentLoaded', function() {
                // 为所有目录项添加点击事件
                document.querySelectorAll('.tree .directory-wrapper').forEach(wrapper => {
                    wrapper.addEventListener('click', function() {
                        const parentLi = this.parentElement;
                        parentLi.classList.toggle('open');
                        const toggleIcon = this.querySelector('.toggle .material-icons');
                        if (parentLi.classList.contains('open')) {
                            toggleIcon.textContent = 'expand_more';
                        } else {
                            toggleIcon.textContent = 'chevron_right';
                        }
                    });
                });

                // 默认展开所有节点
                expandAll(document.querySelector('.tree'));

                // 切换主题按钮
                const toggleThemeButton = document.getElementById('toggle-theme');
                toggleThemeButton.addEventListener('click', function() {
                    const body = document.body;
                    if (body.classList.contains('dark')) {
                        body.classList.remove('dark');
                        this.querySelector('.material-icons').textContent = 'light_mode';
                        localStorage.setItem('darkMode', 'false');
                    } else {
                        body.classList.add('dark');
                        this.querySelector('.material-icons').textContent = 'dark_mode';
                        localStorage.setItem('darkMode', 'true');
                    }
                });

                // 检查本地存储中的主题设置
                const savedDarkMode = localStorage.getItem('darkMode');
                if (savedDarkMode === 'true') {
                    document.body.classList.add('dark');
                    document.getElementById('toggle-theme').querySelector('.material-icons').textContent = 'dark_mode';
                }
                
                // 检查保存的主题
                const savedTheme = localStorage.getItem('theme');
                if (savedTheme) {
                    setTheme(savedTheme);
                }

                // 展开&折叠按钮
                const toggleAllButton = document.getElementById('toggle-all');
                toggleAllButton.addEventListener('click', function() {
                    const icon = this.querySelector('.material-icons');
                    if (icon.textContent === 'unfold_more') {
                        collapseAll(document.querySelector('.tree'));
                        icon.textContent = 'unfold_less';
                    } else {
                        expandAll(document.querySelector('.tree'));
                        icon.textContent = 'unfold_more';
                    }
                });

                // 搜索功能
                const searchInput = document.getElementById('search-input');
                const resetSearchButton = document.getElementById('reset-search');
                const tree = document.querySelector('.tree');

                searchInput.addEventListener('input', function() {
                    const searchTerm = this.value.trim().toLowerCase();
                    filterTree(tree, searchTerm);
                    
                    // 显示/隐藏重置按钮
                    if (searchTerm.length > 0) {
                        resetSearchButton.style.display = 'flex';
                    } else {
                        resetSearchButton.style.display = 'none';
                    }
                });

                // 初始隐藏重置按钮
                resetSearchButton.style.display = 'none';

                // 重置搜索框按钮
                resetSearchButton.addEventListener('click', function() {
                    searchInput.value = '';
                    filterTree(tree, '');
                    this.style.display = 'none';
                    // 重置后恢复展开状态
                    expandAll(document.querySelector('.tree'));
                    // 更新切换按钮状态
                    const toggleAllButton = document.getElementById('toggle-all');
                    toggleAllButton.querySelector('.material-icons').textContent = 'unfold_more';
                });
                
                // 主题选择器
                document.querySelectorAll('.theme-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const theme = this.dataset.theme;
                        setTheme(theme);
                        
                        // 更新活动按钮
                        document.querySelectorAll('.theme-btn').forEach(b => {
                            b.classList.remove('active');
                        });
                        this.classList.add('active');
                    });
                });
                
                function setTheme(theme) {
                    document.body.className = '';
                    if (theme !== 'default') {
                        document.body.classList.add('theme-' + theme);
                    }
                    
                    // 更新暗色模式状态
                    const isDark = document.body.classList.contains('dark');
                    if (isDark) {
                        document.getElementById('toggle-theme').querySelector('.material-icons').textContent = 'dark_mode';
                    } else {
                        document.getElementById('toggle-theme').querySelector('.material-icons').textContent = 'light_mode';
                    }
                    
                    localStorage.setItem('theme', theme);
                }
            });

            function expandAll(node) {
                node.querySelectorAll('.directory-wrapper').forEach(wrapper => {
                    const parentLi = wrapper.parentElement;
                    parentLi.classList.add('open');
                    const toggleIcon = wrapper.querySelector('.toggle .material-icons');
                    toggleIcon.textContent = 'expand_more';
                });
            }

            function collapseAll(node) {
                node.querySelectorAll('.directory-wrapper').forEach(wrapper => {
                    const parentLi = wrapper.parentElement;
                    parentLi.classList.remove('open');
                    const toggleIcon = wrapper.querySelector('.toggle .material-icons');
                    toggleIcon.textContent = 'chevron_right';
                });
            }

            function filterTree(node, searchTerm) {
                const listItems = node.querySelectorAll('li');
                let hasMatches = false;
                
                // 重置所有显示状态
                listItems.forEach(item => {
                    item.style.display = '';
                    item.classList.remove('match-highlight');
                });
                
                if (searchTerm === '') {
                    return;
                }
                
                listItems.forEach(item => {
                    const text = item.textContent.toLowerCase();
                    
                    if (text.includes(searchTerm)) {
                        hasMatches = true;
                        // 高亮匹配项
                        item.classList.add('match-highlight');
                        
                        // 确保所有祖先项都可见并展开
                        let parent = item.parentElement;
                        while (parent && parent.classList.contains('tree') === false) {
                            if (parent.tagName === 'UL') {
                                parent.style.display = 'block';
                                const parentLi = parent.parentElement;
                                if (parentLi && parentLi.classList.contains('li')) {
                                    parentLi.classList.add('open');
                                    const toggleIcon = parentLi.querySelector('.toggle .material-icons');
                                    if (toggleIcon) {
                                        toggleIcon.textContent = 'expand_more';
                                    }
                                }
                            }
                            parent = parent.parentElement;
                        }
                    } else {
                        // 只隐藏没有子匹配项的项
                        const hasVisibleChildren = item.querySelector('li[style*="display:"]') !== null;
                        if (!hasVisibleChildren) {
                            item.style.display = 'none';
                        }
                    }
                });
                
                // 如果没有匹配项，显示提示
                if (!hasMatches) {
                    const noResults = document.createElement('li');
                    noResults.textContent = '没有找到匹配项';
                    noResults.style.textAlign = 'center';
                    noResults.style.padding = '20px';
                    noResults.style.color = '#999';
                    node.appendChild(noResults);
                }
            }
        ''')
        self.html_content.append('</script>')
        self.html_content.append('</body>')
        self.html_content.append('</html>')

    def process_directory(self, directory_path):
        dir_name = os.path.basename(directory_path)
        self.html_content.append('<li>')
        self.html_content.append('<div class="directory-wrapper">')
        self.html_content.append('<span class="toggle"><span class="material-icons">chevron_right</span></span>')
        self.html_content.append(f'<span class="directory">{dir_name}</span>')
        self.html_content.append('</div>')
        self.html_content.append('<ul>')

        try:
            contents = os.listdir(directory_path)
        except Exception as e:
            print(f"无法访问目录 {directory_path}: {e}")
            contents = []

        folders = []
        files = []
        for item in contents:
            if item.startswith('.') or item == self.generated_html_name:
                continue
            item_path = os.path.join(directory_path, item)
            if os.path.isdir(item_path):
                folders.append(item)
            else:
                files.append(item)

        files.sort(key=lambda x: x.lower())
        folders.sort(key=lambda x: x.lower())

        for file in files:
            file_path = os.path.join(directory_path, file)
            self.html_content.append('<li>')
            self.html_content.append('<div class="file">')
            self.html_content.append(f'<a href="./{os.path.relpath(file_path, self.folder_path).replace("\\", "/")}" target="_blank">{file}</a>')
            self.html_content.append('</div>')
            self.html_content.append('</li>')

        for folder in folders:
            folder_path = os.path.join(directory_path, folder)
            self.process_directory(folder_path)

        self.html_content.append('</ul>')
        self.html_content.append('</li>')

def main():
    folder_path = input("请输入文件夹路径: ").strip()
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        print("指定的路径不存在或不是一个文件夹，请检查后重新输入。")
        return

    generator = DirectoryTreeGenerator(folder_path)
    generator.generate_html()

    html_output = os.path.join(folder_path, generator.generated_html_name)
    with open(html_output, 'w', encoding='utf-8') as f:
        f.write('\n'.join(generator.html_content))

    print(f"HTML文件已生成：{html_output}")
    
    # 提示用户关于图标的使用
    if generator.has_icon:
        print("提示：已使用文件夹中的 ./.APP/favicon.ico 作为网站图标")
    else:
        print("提示：您可以在文件夹中添加名为 './.APP/favicon.ico' 的文件作为网站图标")
    print("注意：生成的HTML文件将不会显示在目录树中")

if __name__ == "__main__":
    main()