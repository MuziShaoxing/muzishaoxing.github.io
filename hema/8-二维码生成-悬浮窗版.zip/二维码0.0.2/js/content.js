// 创建悬浮窗容器（完全透明）
function createQRPopupContainer(content, width, height) {
    // 移除现有的悬浮窗和遮罩层
    const existingPopup = document.getElementById('qr-gen-popup-container');
    const existingOverlay = document.querySelector('.qr-gen-overlay');
    if (existingPopup) existingPopup.remove();
    if (existingOverlay) existingOverlay.remove();

    // 创建完全透明的遮罩层
    const overlay = document.createElement('div');
    overlay.className = 'qr-gen-overlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0,0,0,0)'; // 完全透明
    overlay.style.zIndex = '9999';
    overlay.style.display = 'flex';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';
    overlay.style.cursor = 'pointer'; // 显示为可点击
    
    // 创建二维码容器（完全透明）
    const container = document.createElement('div');
    container.id = 'qr-gen-popup-container';
    container.style.position = 'relative';
    container.style.zIndex = '10000';
    container.style.width = `${width}px`;
    container.style.height = `${height}px`;
    container.style.backgroundColor = 'transparent';
    container.style.border = 'none';
    container.style.boxShadow = 'none';
    container.style.display = 'flex';
    container.style.flexDirection = 'column';
    container.style.overflow = 'hidden';
    container.style.pointerEvents = 'none'; // 防止容器拦截点击事件

    // 创建iframe（完全透明）
    const iframe = document.createElement('iframe');
    iframe.src = chrome.runtime.getURL(`popup.html?text=${encodeURIComponent(content)}`);
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    iframe.style.backgroundColor = 'transparent';
    iframe.style.pointerEvents = 'auto'; // 允许iframe内的事件
    iframe.setAttribute('allowtransparency', 'true'); // 确保透明支持
    container.appendChild(iframe);

    // 添加到遮罩层
    overlay.appendChild(container);
    document.body.appendChild(overlay);

    // 点击遮罩层关闭
    overlay.addEventListener('click', (e) => {
        // 只有当点击的是遮罩层本身时才关闭
        if (e.target === overlay) {
            overlay.remove();
        }
    });

    // 按ESC键关闭
    const closeOnEsc = (e) => {
        if (e.key === 'Escape') {
            overlay.remove();
            document.removeEventListener('keydown', closeOnEsc);
        }
    };
    document.addEventListener('keydown', closeOnEsc);
}

// 监听来自background的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "showQRPopup") {
        createQRPopupContainer(message.content, message.width, message.height);
    }
});