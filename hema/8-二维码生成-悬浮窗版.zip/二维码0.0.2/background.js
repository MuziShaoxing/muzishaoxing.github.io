// 插件安装时创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({id: "generateQRCode", title: "文本二维码", contexts: ["selection"]});
    chrome.contextMenus.create({id: "generateAudioQRCode", title: "音频二维码", contexts: ["audio"]});
    chrome.contextMenus.create({id: "generateLinkQRCode", title: "链接二维码", contexts: ["link"]});
    chrome.contextMenus.create({id: "generateImageQRCode", title: "图片二维码", contexts: ["image"]});
    chrome.contextMenus.create({id: "generatePageQRCode", title: "页面二维码", contexts: ["page"]});
});

// 创建二维码弹窗的通用函数
async function createQRPopup(content) {
    // 获取存储的尺寸设置
    chrome.storage.local.get(['qrSize'], (result) => {
        const size = result.qrSize || 'medium';
        
        // 根据尺寸设置宽高
        let width, height;
        switch(size) {
            case 'small':
                width = 300;
                height = 300;
                break;
            case 'large':
                width = 500;
                height = 500;
                break;
            default: // medium
                width = 400;
                height = 400;
        }
        
        // 获取当前活动标签页
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0] && tabs[0].id) {
                // 确保内容脚本已注入
                chrome.scripting.executeScript({
                    target: {tabId: tabs[0].id},
                    files: ['js/content.js']
                }, () => {
                    // 发送消息到内容脚本
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: "showQRPopup",
                        content: content,
                        width: width,
                        height: height
                    });
                });
            }
        });
    });
}

// 处理右键菜单点击事件
chrome.contextMenus.onClicked.addListener((info, tab) => {
    let content = null;
    
    switch (info.menuItemId) {
        case "generateQRCode": content = info.selectionText; break;
        case "generateLinkQRCode": content = info.linkUrl; break;
        case "generateAudioQRCode": content = info.srcUrl; break;
        case "generateImageQRCode": content = info.srcUrl; break;
        case "generatePageQRCode": content = tab.url; break;
        default:
            const contentSource = ["linkUrl", "selectionText", "srcUrl", "frameUrl", "pageUrl"]
                .find(source => info[source]);
            content = info[contentSource];
    }

    if (content) {
        createQRPopup(content);
    } else {
        alert("请选择要生成二维码的有效内容。");
    }
});