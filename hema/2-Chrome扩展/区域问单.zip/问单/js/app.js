        (function() {
            const $ = (sel) => document.querySelector(sel);
            const guideOverlay = $('#guideOverlay');
            const guideCard = $('#guideCard');
            const hiddenFileInput = $('#hiddenFileInput');
            const aboutDocOverlay = $('#aboutDocOverlay');

            // ==========================================
            // 关于文档：核心逻辑清单（左侧面板内容）
            // 维护方式：新增/调整功能后，同步更新此数组
            // 写作要求：描述"能做什么 + 怎么完成的"，不引用具体函数名/变量名
            // ==========================================
            const ABOUT_DOC_LOGIC = [
                {
                    group: '一、这是一个什么工具',
                    items: [
                        { name: '用途', desc: '面向片区专用的问单数据分析工具：把 Excel 问单明细一键导入，自动按片区/门店类型拆分、计算达成率、识别问题门店，并支持重点维度排行与一键复制，最终输出报告。' },
                        { name: '使用流程', desc: '导入 Excel → 选择片区/门店 → 浏览问单达成情况与明细 → 进入重点分析看排行 → 一键复制或导出报告。' },
                        { name: '数据来源', desc: '一份 Excel 含三个工作表：问单明细（每条问单）、差评（每条差评）、数据展示（门店达成率与上限）。支持一次导入多个文件，按日合并。' }
                    ]
                },
                {
                    group: '二、导入与数据合并机制',
                    items: [
                        { name: '识别三个工作表', desc: '按名称匹配"问单明细""差评""数据展示"，其余 sheet（如汇总/模板/参数）自动忽略，避免误读。' },
                        { name: '达成率二次计算', desc: '数据展示表里前 12 列是百分比，原始明细数据在后面列。导入时用原始数据列重新算一遍前 12 列，确保数值准确（第 2、3、8 列含 ×10000 换算）。' },
                        { name: '多文件合并', desc: '导入多个文件时，先把每个文件当天的达成数据存成快照，再对所有快照的原始数据列求和、重新计算前 12 列，得到合并后的达成率。' },
                        { name: '片区识别', desc: '从数据展示表 A 列识别片区名：保留包含"苏南"的行，剔除"片区"（标题行）和"000"两类无效行，建立片区→门店映射。' },
                        { name: '门店类型区分', desc: '门店名含"前置仓"的归为前置仓，其余为生鲜店，两者上限值不同，分别独立计算热力图范围。' }
                    ]
                },
                {
                    group: '三、问单达成情况展示',
                    items: [
                        { name: '两区三段', desc: '主页面分两大区：顶部汇总达成面板（紫框）展示各片区整体达成率，下方门店明细按生鲜店（蓝框）、前置仓（橙框）两段分开展示，每个类目对应一个上限，超标标红。' },
                        { name: '热力图', desc: '前 12 个百分比类目按当前范围内的最低值（绿）到最高值（黄）渐变着色，让问题门店一眼可见；生鲜店和前置仓各自独立计算颜色范围。' },
                        { name: '汇总行', desc: '每段顶部有汇总行：把范围内所有门店的原始数据列求和、重算前 12 列，得到该段整体达成率。全部片区时还会按片区分别列汇总行。' },
                        { name: '查看上限', desc: '点击表头"!"按钮可弹出当前生鲜店/前置仓各分类的上限值。' }
                    ]
                },
                {
                    group: '四、问单明细浏览',
                    items: [
                        { name: '四视图切换', desc: '问单 / 物流损 / 冷链 / 差评四个视图气泡切换，顶部显示各视图数据条数。' },
                        { name: '筛选联动', desc: '门店下拉、问题原因下拉、评价标签下拉（仅差评视图）三层筛选；选冷链/物流损原因时自动跳到对应视图，清空筛选自动回问单视图。' },
                        { name: '可编辑列', desc: '表格中"责任归属"可下拉、"原因"可输入，编辑结果随会话保留，导出时一并带上。' },
                        { name: '内联弹窗', desc: '点击 APP 退款描述、单号、时间戳等单元格弹出气泡显示完整内容；鼠标移出弹窗与触发元素 150ms 后自动关闭，避免遮挡。' },
                        { name: '图片预览', desc: '退款凭证图可点击预览，支持翻页与全屏查看。' }
                    ]
                },
                {
                    group: '五、重点分析（排行）',
                    items: [
                        { name: '四个分析视图', desc: '问单 → 冷链化冻 → 物流损 → 差评，依次切换；每视图左侧上下两栏是尾部门店/头部门店排行，右侧是辅助排行（SKU/配送员/评价标签）。' },
                        { name: '尾部与头部合并', desc: '尾部=达成数值最高的若干门店，优先取非零项；仅当非零门店不足 TOP 数量时，才把达成=0 的门店合并成一行排在末尾（可展开）。头部=达成数值最低的若干门店；仅当最低值=0 时才把所有=0 门店合并展示，最低值非 0 则逐条列出。' },
                        { name: '排行设置', desc: '设置弹窗可调整：门店类型（生鲜店/前置仓是否纳入）、达成排行榜 TOP 数量、SKU 排行 TOP 数量。' },
                        { name: '字号自适应', desc: '排行榜字号根据可用高度自动缩放，保证任何屏幕下 5 行/10 行都填满不溢出、无滚动条。' }
                    ]
                },
                {
                    group: '六、一键复制',
                    items: [
                        { name: '六个复制按钮', desc: '达成面板顶部：差评 / 冷链 / 蛋糕 / 鸡蛋 / 达标 / 统计，一键把当前筛选范围内的数据复制到剪贴板。' },
                        { name: '受片区筛选限制', desc: '六个复制按钮都跟随当前选中的片区/门店范围：单门店只复制该店、单片区只复制该片区内门店、全部片区复制全部。差评/冷链在全部片区时按片区排序输出（不含片区列），统计在全部片区时按片区分组汇总。' },
                        { name: '差评复制', desc: '复制差评明细（剔除片区列与表头），保留门店排序。' },
                        { name: '冷链复制', desc: '复制冷链化冻明细前 5 列：日期、SKU、门店、配送单号、配送员。' },
                        { name: '蛋糕复制', desc: '从物流损明细中筛选 SKU 名称含"草莓盒子"的记录，输出日期、片区、门店、SKU、配送单号、配送员。' },
                        { name: '鸡蛋复制', desc: '从物流损明细中按关键词组筛选 SKU：同时含"鸡蛋"和"枚"，或同时含"谷物蛋"和"枚"，任一组成立即纳入；输出列同蛋糕。' },
                        { name: '统计复制', desc: '汇总输出冷链化冻条数 + 差评条数（含服务态度差评），按片区/门店明细降序列出。' },
                        { name: '达标复制', desc: '按门店输出达标/不达标，以第一个类目是否超上限为判定依据。' }
                    ]
                },
                {
                    group: '七、导出',
                    items: [
                        { name: '三种导出方式', desc: '导出图片、导出 Excel 表格、复制文案；全部片区时禁用图片导出（数据量过大）。' },
                        { name: '模块化图片', desc: '按达成情况、物流损、冷链、差评四个模块分别导出独立 PNG，紧凑表格样式适合粘贴到文档。' },
                        { name: '多 Sheet Excel', desc: '导出含达成情况/差评/冷链/物流损/全部问单的多 sheet 工作簿，便于线下二次分析。' },
                        { name: '片区门店表导出', desc: '片区选择弹窗左上角「📥」按钮可导出"所属片区 + 门店"两列的 Excel，便于核对片区门店归属。' },
                        { name: '过载保护', desc: '图片渲染结果为空白（数据 URL 过短）时弹窗提示，请缩小筛选范围后重试。' }
                    ]
                }
            ];

            // ==========================================
            // 关于文档：更新日志（右侧面板内容）
            // 维护规则：
            //   1. 仅从 V1.0 起登记变更，前置历史不记录
            //   2. 每次调整完成 → 经用户确认 → 在数组头部插入新版本
            //   3. 同步备份当前文件到 /workspace/backups/1-区域问单_v{X.X}.html
            // ==========================================
            const ABOUT_DOC_CHANGELOG = [
                {
                    version: 'V1.1',
                    date: '2026-11-13',
                    changes: [
                        '问单达成面板新增「蛋糕」「鸡蛋」两个一键复制按钮：从物流损明细中按 SKU 关键词筛选，输出日期/片区/门店/SKU/配送单号/配送员',
                        '蛋糕：SKU 名称含"草莓盒子"',
                        '鸡蛋：支持多关键词组——同时含"鸡蛋"和"枚"，或同时含"谷物蛋"和"枚"，任一组成立即纳入（组内 AND、组间 OR）',
                        '片区选择弹窗左上角新增「📥」导出按钮：导出"所属片区 + 门店"两列 Excel',
                        '同步更新核心逻辑文档：一键复制章节补充蛋糕/鸡蛋说明，导出章节补充片区门店表导出'
                    ]
                },
                {
                    version: 'V1.0',
                    date: '2026-10-04',
                    changes: [
                        '建立"关于文档"入口（菜单栏 → 📖 关于文档），左侧记录核心逻辑及作用，右侧记录更新日志',
                        '版本基线定义为 V1.0，前置历史版本（v1~v19）不予记录',
                        '确立后续维护流程：每次调整完成 → 经用户确认 → 同步更新日志 + 备份当前版本到 /workspace/backups/',
                        '全面校准核心逻辑描述与代码注释，确保文档与实际逻辑一致'
                    ]
                }
            ];

            let allData = [], badReviewData = [], coldThawData = [], logisticsData = [];
            let filteredData = [], filteredBadReviewData = [], filteredColdThawData = [], filteredLogisticsData = [];
            let selectedStore = null;
            let selectedReasons = new Set();
            let filterStoreName = '__all__';   // 下拉门店筛选值
            let filterReasonName = '__all__';   // 下拉问题原因筛选值
            let filterReviewTag = '__all__';    // 下拉评价标签筛选值
            let currentView = 'default';
            let pageSize = 20;
            let viewCurrentPages = { default: 1, badReview: 1, coldThaw: 1, logistics: 1 };
            let allStores = [];
            let selectedArea = null; // 当前选中的片区
            let areaStoreMap = {}; // 片区→门店列表映射
            let areaNames = []; // 片区名称列表
            let manualDataMap = new Map();
            let badReviewManualMap = new Map();
            let coldThawManualMap = new Map();
            let rowIdCounter = 0;
            let duplicateBatchSet = new Set();
            let currentPopup = null;
            let toastTimer;
            let previewUrls = [], previewIdx = 0;

            // 数据展示工作簿相关数据
            let dataDisplayWorkbook = null; // 存储"数据展示"工作簿
            let achievementCategories = []; // 问单类目名列表（存储唯一key，如"库存缺货@0"）
            let categoryKeyToDisplay = new Map(); // key → 显示名（如"库存缺货@0" → "库存缺货"）
            let shengxianLimits = {}; // 生鲜店标准上限
            let qianzhicangLimits = {}; // 前置仓标准上限
            let storeAchievements = {}; // 门店达成数据
            let mergedStoreAchievements = {}; // 多文件合并后的汇总达成数据
            let dailyAchievementSnapshots = []; // 每个文件（每日）的达成数据快照 [{date, storeAchievements}]
            let isMultiFile = false; // 是否为多文件合并模式
            let uploadedFileCount = 0; // 已上传文件数量
            let currentAnalysisType = 'order'; // 问单类目分析当前类型：coldThaw | logistics | order | badReview
            let isAnalysisPageVisible = false; // 是否显示问单类目分析页面
            let filterStoreTypes = { qianzhicang: true, shengxian: true }; // 门店类型筛选（默认全部勾选）
            let rankTopCount = 5; // 达成排行榜TOP数量（默认5）
            let skuTopCount = 10;  // 商品排行榜TOP数量（默认10）

            // 重点分析公共配置：四视图（冷链化冻/物流损/问单/差评）共享参数，修改此处同步影响全部视图
            // 超标色/字重引用 CSS 变量，改 --ar-over-color 即可统一四视图超标颜色
            const ANALYSIS_COMMON = {
                overColor: 'var(--ar-over-color)',     // 超标标红颜色
                overWeight: 'var(--ar-over-weight)',   // 超标字重
                tableClass: 'analysis-table',          // 统一表格样式类（四视图所有排行榜共用，无区分）
                // 各视图排行榜表头（公共提取，统一管理）
                headers: {
                    achievement: ['排行','片区','门店','达成占比','问单数量'],
                    order:      ['排行','片区','门店','达成占比','问单数量'],
                    badReview:  ['排行','片区','门店','达成占比','差评数量','服务差评数量'],
                    sku:        ['排行','SKU名称','出现次数'],
                    delivery:   ['排行','配送员名','门店','出现次数'],
                    tag:        ['排行','评价标签','数量']
                }
            };

            const TARGET_SHEET_KEYWORDS = ['问单明细','问单'];
            const DATA_DISPLAY_KEYWORDS = ['数据展示'];
            const BAD_REVIEW_KEYWORDS = ['差评'];
            const IGNORE_KEYWORDS = ['sheet','数据源','汇总','模板','参数','配置','说明','备份','临时','测试'];

            function findSheet(sheets, keywords) {
                for (let kw of keywords) {
                    const exact = sheets.find(s => s.trim() === kw);
                    if (exact) return exact;
                }
                for (let kw of keywords) {
                    const fuzzy = sheets.find(s => s.trim().includes(kw));
                    if (fuzzy) return fuzzy;
                }
                return null;
            }

            function shouldIgnore(sheetName) {
                const name = sheetName.trim().toLowerCase();
                for (let kw of IGNORE_KEYWORDS) if (name.includes(kw.toLowerCase())) return true;
                return false;
            }

            function getColValue(row, col) {
                if (row.hasOwnProperty(col)) return row[col];
                for (let k of Object.keys(row)) if (k.trim() === col.trim()) return row[k];
                return '';
            }

            // 获取app退款描述：当值为"-"时，用替代列拼接返回
            function getAppRefundDesc(row) {
                const desc = String(getColValue(row, 'app退款描述') || getColValue(row, 'APP退款描述') || '').trim();
                if (desc === '-') {
                    const parts = [
                        getColValue(row, 'xspace退款原因') || '',
                        getColValue(row, 'xspace退款工单备注') || '',
                        getColValue(row, 'XSpace工单备注') || '',
                        getColValue(row, 'sr评价内容') || ''
                    ].map(v => String(v).trim()).filter(v => v && v !== '-');
                    return parts.join('，');
                }
                return desc;
            }

            function toast(msg) {
                const t = $('#toast');
                clearTimeout(toastTimer);
                t.textContent = msg; t.style.display = 'block'; t.style.animation = 'none';
                void t.offsetWidth;
                t.style.animation = 'toastIn 0.4s ease, toastOut 0.4s ease 1.8s forwards';
                toastTimer = setTimeout(() => t.style.display = 'none', 2300);
            }

            function escapeHTML(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

            // 判断门店类型
            function getStoreType(storeName) {
                if (!storeName) return 'shengxian';
                return storeName.includes('前置仓') ? 'qianzhicang' : 'shengxian';
            }

            function getStoreTypeLabel(storeType) {
                return storeType === 'qianzhicang' ? '前置仓' : '生鲜店';
            }

            function getStoreTypeClass(storeType) {
                return storeType === 'qianzhicang' ? 'qianzhicang' : 'shengxian';
            }

            // 解析数据展示工作簿
            // accumulate=true时保留已有类目和上限，仅追加新门店数据
            function parseDataDisplaySheet(wb, accumulate) {
                const sheetName = findSheet(wb.SheetNames, DATA_DISPLAY_KEYWORDS);
                if (!sheetName) {
                    console.log('未找到数据展示工作簿');
                    return false;
                }

                const sheet = wb.Sheets[sheetName];
                const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: true });
                
                if (!jsonData || jsonData.length < 4) {
                    console.log('数据展示工作簿数据不足');
                    return false;
                }

                // 动态检测上限行：扫描A列，第一个"目标"行=生鲜店上限，第二个"目标"行=前置仓上限
                // 类目名行 = 第一个"目标"行的上一行
                let sxLimitRowIdx = -1;
                let qzcLimitRowIdx = -1;
                for (let r = 0; r < jsonData.length; r++) {
                    const cellA = String((jsonData[r] || [])[0] || '').trim();
                    if (cellA === '目标') {
                        if (sxLimitRowIdx === -1) {
                            sxLimitRowIdx = r;
                        } else if (qzcLimitRowIdx === -1) {
                            qzcLimitRowIdx = r;
                            break;
                        }
                    }
                }
                if (sxLimitRowIdx === -1) {
                    console.log('未找到"目标"上限行，无法解析上限');
                    return false;
                }
                const categoryRowIdx = sxLimitRowIdx - 1; // 类目名行在第一个"目标"行的上一行
                const rowCat = jsonData[categoryRowIdx] || []; // 类目名行
                const rowSxLimit = jsonData[sxLimitRowIdx] || []; // 生鲜店上限行
                const rowQzcLimit = qzcLimitRowIdx >= 0 ? (jsonData[qzcLimitRowIdx] || []) : []; // 前置仓上限行（未找到则为空数组）

                if (!accumulate) {
                    achievementCategories = [];
                    shengxianLimits = {};
                    qianzhicangLimits = {};
                }
                // 每个文件均重置：确保快照仅含当前文件数据，避免多文件合并时早期文件数据污染快照导致重复累加
                storeAchievements = {};

                // 片区映射：从数据展示A列读取，非累积时重置
                if (!accumulate) {
                    areaStoreMap = {};
                    areaNames = [];
                }

                const row4 = rowCat; // 类目名行（动态检测）
                const row5 = rowSxLimit; // 生鲜店上限行（第一个"目标"行）
                const row44 = rowQzcLimit; // 前置仓上限行（第二个"目标"行）

                // ==========================================
                // 读取所有非空类目列
                // ==========================================
                if (!accumulate) {
                    achievementCategories = []; // 存储唯一key（格式：类目名@索引）
                    categoryKeyToDisplay = new Map(); // key → displayName
                }
                const categoryKeyToColIdx = {}; // key → 列索引
                const seenNames = new Set(); // 用于检测重复的类目名

                for (let colIdx = 1; colIdx < row4.length; colIdx++) {
                    const rawVal = row4[colIdx];
                    const valStr = String(rawVal || '').trim();
                    if (!valStr) continue;
                    // 跳过纯数字列（如"100"）
                    if ((valStr.split('.').length - 1 === 0) && /^\d+$/.test(valStr)) continue;
                    
                    // 生成唯一key：如果类目名重复，添加@索引后缀
                    let key = valStr;
                    if (seenNames.has(valStr)) {
                        key = valStr + '@' + colIdx;
                    } else {
                        seenNames.add(valStr);
                    }
                    
                    if (!accumulate) {
                        achievementCategories.push(key);
                        categoryKeyToDisplay.set(key, valStr);
                    }
                    categoryKeyToColIdx[key] = colIdx;
                    // 上限取当前列的值（仅首次设置）；无数据时parseFloat返回NaN，||0后为0，lim=0时不渲染红色背景
                    if (!accumulate) {
                        shengxianLimits[key] = parseFloat(row5[colIdx]) || 0;
                        qianzhicangLimits[key] = parseFloat(row44[colIdx]) || 0;
                    }
                }

                // DEBUG
                console.log('【DEBUG】最终类目:', achievementCategories);

                // ==========================================
                // 读取门店数据 & 片区映射（A列=片区，B列=门店）
                // 从第一个"目标"行+2开始（跳过上限行和表头行）
                // ==========================================
                const storeDataStartIdx = sxLimitRowIdx + 2;
                for (let rowIdx = storeDataStartIdx; rowIdx < jsonData.length; rowIdx++) {
                    const row = jsonData[rowIdx];
                    if (!row || row.length < 2) continue;

                    const areaNameRaw = String(row[0] || '').trim();
                    const storeName = String(row[1] || '').trim();
                    if (!areaNameRaw || !storeName) continue;

                    // 片区过滤规则：A列="片区"是标题=不合格，000=不合格，不含"苏南"的=不合格
                    if (areaNameRaw === '片区') continue;
                    if (areaNameRaw === '000') continue;
                    if (!areaNameRaw.includes('苏南')) continue;

                    // 构建片区→门店映射
                    if (!areaStoreMap[areaNameRaw]) areaStoreMap[areaNameRaw] = [];
                    if (!areaStoreMap[areaNameRaw].includes(storeName)) {
                        areaStoreMap[areaNameRaw].push(storeName);
                    }

                    const storeType = getStoreType(storeName);
                    const achievements = {};

                    achievementCategories.forEach((catKey, idx) => {
                        const colIdx = categoryKeyToColIdx[catKey];
                        const rawVal = row[colIdx];
                        // 前12个类目（索引0-11）：直接返回表格数值（百分比）
                        // 第13个及之后（索引12+）：数值格式（用于多文件求和后重算，需保留精度）
                        const val = parseFloat(rawVal) || 0;
                        achievements[catKey] = val;
                    });

                    // 用原始数据列重算前12列（单文件也适用）
                    recalcTop12(achievements);

                    storeAchievements[storeName] = {
                        type: storeType,
                        achievements: achievements
                    };
                }

                areaNames = Object.keys(areaStoreMap).sort();
                console.log('数据展示工作簿解析完成:', {
                    categories: achievementCategories,
                    storeCount: Object.keys(storeAchievements).length,
                    areas: areaNames,
                    areaStoreCount: Object.values(areaStoreMap).flat().length
                });

                return true;
            }

            // 用原始数据列（索引12+）重算前12列
            // 公式（列号从1开始，对应类目索引从0开始）：
            // 第1列(索引0) = 第14列(索引13) / 第13列(索引12)
            // 第2列(索引1) = 第25列(索引24) / 第24列(索引23) * 10000
            // 第3列(索引2) = 第26列(索引25) / 第24列(索引23) * 10000
            // 第4列(索引3) = 第15列(索引14) / 第13列(索引12)
            // 第5列(索引4) = 第16列(索引15) / 第13列(索引12)
            // 第6列(索引5) = 第17列(索引16) / 第13列(索引12)
            // 第7列(索引6) = 第19列(索引18) / 第13列(索引12)
            // 第8列(索引7) = 第18列(索引17) / 第13列(索引12) * 10000
            // 第9列(索引8) = 第20列(索引19) / 第13列(索引12)
            // 第10列(索引9) = 第21列(索引20) / 第13列(索引12)
            // 第11列(索引10) = 第22列(索引21) / 第13列(索引12)
            // 第12列(索引11) = 第23列(索引22) / 第13列(索引12)
            function recalcTop12(achievements) {
                if (!achievements || achievementCategories.length === 0) return;
                const getVal = (idx) => {
                    if (idx < achievementCategories.length) {
                        return achievements[achievementCategories[idx]] || 0;
                    }
                    return 0;
                };
                const col12 = getVal(12); // 第13列（索引12）
                const col23 = getVal(23); // 第24列（索引23）

                if (achievementCategories.length > 0) {
                    // 第1列 = 第14列 / 第13列
                    achievements[achievementCategories[0]] = col12 !== 0 ? getVal(13) / col12 : 0;
                }
                if (achievementCategories.length > 1) {
                    // 第2列 = 第25列 / 第24列 * 10000
                    achievements[achievementCategories[1]] = col23 !== 0 ? getVal(24) / col23 * 10000 : 0;
                }
                if (achievementCategories.length > 2) {
                    // 第3列 = 第26列 / 第24列 * 10000
                    achievements[achievementCategories[2]] = col23 !== 0 ? getVal(25) / col23 * 10000 : 0;
                }
                if (achievementCategories.length > 3) {
                    // 第4列 = 第15列 / 第13列
                    achievements[achievementCategories[3]] = col12 !== 0 ? getVal(14) / col12 : 0;
                }
                if (achievementCategories.length > 4) {
                    // 第5列 = 第16列 / 第13列
                    achievements[achievementCategories[4]] = col12 !== 0 ? getVal(15) / col12 : 0;
                }
                if (achievementCategories.length > 5) {
                    // 第6列 = 第17列 / 第13列
                    achievements[achievementCategories[5]] = col12 !== 0 ? getVal(16) / col12 : 0;
                }
                if (achievementCategories.length > 6) {
                    // 第7列 = 第19列 / 第13列
                    achievements[achievementCategories[6]] = col12 !== 0 ? getVal(18) / col12 : 0;
                }
                if (achievementCategories.length > 7) {
                    // 第8列 = 第18列 / 第13列 * 10000
                    achievements[achievementCategories[7]] = col12 !== 0 ? getVal(17) / col12 * 10000 : 0;
                }
                if (achievementCategories.length > 8) {
                    // 第9列 = 第20列 / 第13列
                    achievements[achievementCategories[8]] = col12 !== 0 ? getVal(19) / col12 : 0;
                }
                if (achievementCategories.length > 9) {
                    // 第10列 = 第21列 / 第13列
                    achievements[achievementCategories[9]] = col12 !== 0 ? getVal(20) / col12 : 0;
                }
                if (achievementCategories.length > 10) {
                    // 第11列 = 第22列 / 第13列
                    achievements[achievementCategories[10]] = col12 !== 0 ? getVal(21) / col12 : 0;
                }
                if (achievementCategories.length > 11) {
                    // 第12列 = 第23列 / 第13列
                    achievements[achievementCategories[11]] = col12 !== 0 ? getVal(22) / col12 : 0;
                }
            }

            // ==========================================
            // 汇总达成计算：对指定门店列表进行二次计算
            // 原始数据列（索引12+）求和 → 用求和后的数据重算前12列
            // ==========================================
            function computeSummaryAchievements(storeNames) {
                if (!achievementCategories.length || !storeNames.length) return null;
                const currentAchData = getCurrentAchievements();
                const validStores = storeNames.filter(sn => currentAchData[sn]);
                if (!validStores.length) return null;

                const summed = {};
                achievementCategories.forEach((catKey) => {
                    let total = 0;
                    validStores.forEach(sn => {
                        total += (currentAchData[sn].achievements[catKey] || 0);
                    });
                    summed[catKey] = total;
                });

                // 用求和后的原始数据列重算前12列
                recalcTop12(summed);
                return summed;
            }

            // 多文件合并达成数据：原始数据列（索引12+）求和，然后用求和后的数据重算前12列
            function mergeAllAchievements() {
                if (dailyAchievementSnapshots.length === 0) {
                    mergedStoreAchievements = {};
                    return;
                }

                // 收集所有出现过的门店
                const allStoreNames = new Set();
                dailyAchievementSnapshots.forEach(snap => {
                    Object.keys(snap.storeAchievements).forEach(sn => allStoreNames.add(sn));
                });

                mergedStoreAchievements = {};
                allStoreNames.forEach(storeName => {
                    // 收集该门店在所有快照中的数据
                    const validSnapshots = dailyAchievementSnapshots.filter(snap => snap.storeAchievements[storeName]);
                    if (validSnapshots.length === 0) return;

                    const firstSnap = validSnapshots[0];
                    const storeType = firstSnap.storeAchievements[storeName].type;
                    const mergedAch = {};

                    // 第一步：对所有类目的原始数据求和（索引12+为原始数据列）
                    achievementCategories.forEach((catKey, idx) => {
                        const values = validSnapshots.map(snap => snap.storeAchievements[storeName].achievements[catKey] || 0);
                        mergedAch[catKey] = values.reduce((sum, v) => sum + v, 0);
                    });

                    // 第二步：用求和后的原始数据列重算前12列
                    recalcTop12(mergedAch);

                    mergedStoreAchievements[storeName] = {
                        type: storeType,
                        achievements: mergedAch
                    };
                });

                console.log('多文件合并完成（求和后重算前12列）:', {
                    fileCount: dailyAchievementSnapshots.length,
                    storeCount: Object.keys(mergedStoreAchievements).length
                });
            }

            // 获取当前使用的达成数据（多文件时用合并数据，单文件用原始数据）
            function getCurrentAchievements() {
                return isMultiFile ? mergedStoreAchievements : storeAchievements;
            }

            // 获取当前片区对应的门店列表
            function getAreaStores(areaName) {
                if (!areaName) return [];
                return areaStoreMap[areaName] || [];
            }

            // 获取所有片区内的门店合集（去重）
            function getAllAreaStores() {
                const allStores = new Set();
                for (const stores of Object.values(areaStoreMap)) {
                    stores.forEach(s => allStores.add(s));
                }
                return [...allStores];
            }

            // 格式化达成值：根据类目索引决定格式
            // 前12个类目（索引0-11）：百分比格式（Excel存储为小数，需要乘以100）
            // 第13个及之后（索引12+）：整数格式
            // 类目上限：从数据展示工作簿动态定位"目标"行提取（第一个目标行=生鲜店上限、第二个目标行=前置仓上限，类目名行位于其上一行），无数据则上限=0不渲染红色背景
            function formatAchievementValue(value, category, achievements, catIndex) {
                // 第13个及之后：整数格式
                if (catIndex >= 12) {
                    return String(Math.round(value));
                }
                // 类目2、3、8（索引1、2、7）：原始数值（含*10000乘法），保留3位小数
                if (catIndex === 1 || catIndex === 2 || catIndex === 7) {
                    return value.toFixed(3);
                }
                // 索引0,3,4,5,6,8,9,10,11（第1,4,5,6,7,9,10,11,12列）：百分比格式，统一乘以100，保留3位小数
                if ([0,3,4,5,6,8,9,10,11].includes(catIndex)) {
                    return (value * 100).toFixed(3) + '%';
                }
                // 前12个：百分比格式
                // Excel存储的是小数（如0.00041表示0.041%），需要乘以100
                let percentValue = value;
                if (value < 1) {
                    percentValue = value * 100;
                }
                // 差评率/差评数用2位小数
                if (category && (category.includes('差评率') || category.includes('差评数'))) {
                    return percentValue.toFixed(2) + '%';
                }
                // 默认百分比格式
                return percentValue.toFixed(3) + '%';
            }
            // 格式化上限值：与formatAchievementValue格式规则一致
            // catIndex：类目索引，决定格式化方式
            function formatLimitValue(value, category, catIndex) {
                if (catIndex === undefined) catIndex = -1;
                // 第13个及之后（索引12+）：整数格式
                if (catIndex >= 12) {
                    return String(Math.round(value));
                }
                // 类目2、3、8（索引1、2、7）：原始数值，保留3位小数
                if (catIndex === 1 || catIndex === 2 || catIndex === 7) {
                    return value.toFixed(3);
                }
                // 索引0,3,4,5,6,8,9,10,11：百分比格式，乘以100
                if ([0,3,4,5,6,8,9,10,11].includes(catIndex)) {
                    return (value * 100).toFixed(3) + '%';
                }
                // 差评率/差评数：2位小数
                if (category && (category.includes('差评率') || category.includes('差评数'))) {
                    let pv = value < 1 ? value * 100 : value;
                    return pv.toFixed(2) + '%';
                }
                // 默认百分比格式
                let pv = value < 1 ? value * 100 : value;
                return pv.toFixed(3) + '%';
            }

            // 渲染问单达成展示区 - 表格模式
            function renderAchievementPanel() {
                const panel = $('#achievementPanel');

                if (!achievementCategories.length) {
                    panel.style.display = 'none';
                    return;
                }

                // 获取当前使用的达成数据源
                const currentAchData = getCurrentAchievements();

                // 获取门店第一个类目数据用于排序（降序）
                const getFirstCategoryValue = (storeName) => {
                    const sd = currentAchData[storeName];
                    if (!sd || !achievementCategories.length) return 0;
                    const firstCatKey = achievementCategories[0];
                    return sd.achievements[firstCatKey] || 0;
                };

                // 仅前12个百分比类目渲染热力图，生鲜店/前置仓分别独立计算热力范围
                const heatmapCount = 12;
                const allStoresList = selectedArea ? getAreaStores(selectedArea) : (selectedStore ? [selectedStore] : getAllAreaStores());
                const sxStoresList = allStoresList.filter(s => !s.includes('前置仓'));
                const qzcStoresList = allStoresList.filter(s => s.includes('前置仓'));

                // 生鲜店独立热力范围
                const catRangeSx = {};
                achievementCategories.forEach((ck, idx) => {
                    if (idx >= heatmapCount) return;
                    let vals = [];
                    sxStoresList.forEach(sn => {
                        const sd = currentAchData[sn];
                        if (!sd) return;
                        const v = sd.achievements[ck] || 0;
                        if (v > 0) vals.push(v);
                    });
                    catRangeSx[ck] = vals.length > 0 ? { min: Math.min(...vals), max: Math.max(...vals) } : { min: 0, max: 1 };
                });

                // 前置仓独立热力范围
                const catRangeQzc = {};
                achievementCategories.forEach((ck, idx) => {
                    if (idx >= heatmapCount) return;
                    let vals = [];
                    qzcStoresList.forEach(sn => {
                        const sd = currentAchData[sn];
                        if (!sd) return;
                        const v = sd.achievements[ck] || 0;
                        if (v > 0) vals.push(v);
                    });
                    catRangeQzc[ck] = vals.length > 0 ? { min: Math.min(...vals), max: Math.max(...vals) } : { min: 0, max: 1 };
                });

                // 字体颜色+背景热力图辅助函数（工具展示页面用）
                // 热力图：仅超标红色，不超标列：最低点绿 -> 最高点黄
                // 绿(#1DB954=29,185,84) -> 黄(#FFD700=255,215,0)，超标红(#FF4500=255,69,0)
                // customRange: 传入对象则使用该范围，否则根据 isQzc 自动选择
                const getValueStyle = (val, lim, ck, idx, isQzcOrRange) => {
                    if (val === 0) return 'color:#999;'; // 0值忽略，灰色
                    if (lim > 0 && val > lim) return 'background:#FF4500;color:#fff;'; // 超标红
                    if (idx < heatmapCount) {
                        let range;
                        if (isQzcOrRange && typeof isQzcOrRange === 'object' && isQzcOrRange.min !== undefined) {
                            range = isQzcOrRange;
                        } else if (isQzcOrRange === true) {
                            range = catRangeQzc[ck];
                        } else {
                            range = catRangeSx[ck];
                        }
                        if (!range || range.max <= range.min) return '';
                        const ratio = (val - range.min) / (range.max - range.min);
                        // 绿(29,185,84) -> 黄(255,215,0)
                        const r = Math.round(255 * ratio + 29 * (1 - ratio));
                        const g = Math.round(215 * ratio + 185 * (1 - ratio));
                        const b = Math.round(0 * ratio + 84 * (1 - ratio));
                        return 'background:rgb(' + r + ',' + g + ',' + b + ');';
                    }
                    return '';
                };

                // 生成类目表头行的HTML（共享函数）
                const buildCategoryHeaderRow = (extraCol) => {
                    let h = '<tr style="background:#f0f2fc;">';
                    if (extraCol) h += '<th style="padding:8px 6px;border:1px solid #dde3f0;text-align:center;font-weight:700;white-space:nowrap;width:225px;">门店 <span class="limits-trigger" style="display:inline-block;width:12px;height:12px;line-height:12px;border-radius:50%;background:#e0e0e0;color:#888;font-size:0.5rem;font-weight:700;cursor:pointer;margin-left:3px;vertical-align:middle;text-align:center;pointer-events:auto;" title="查看类目上限值">!</span></th>';
                    achievementCategories.forEach(catKey => {
                        const displayName = categoryKeyToDisplay.get(catKey) || catKey;
                        const catShort = displayName.includes('｜') ? displayName.split('｜')[0] : displayName;
                        // 表头可以换行，列宽自适应
                        h += '<th style="padding:8px 4px;border:1px solid #dde3f0;text-align:center;font-weight:700;white-space:normal;word-break:break-all;line-height:1.2;" title="' + escapeHTML(displayName) + '">' + escapeHTML(catShort) + '</th>';
                    });
                    h += '</tr>';
                    return h;
                };

                // ==========================================
                // 渲染汇总达成行HTML
                // label: 显示名称
                // achievements: 计算后的达成数据
                // rowClass: CSS行类名
                // limitsMap: 上限映射
                // heatmapRange: {min, max} 热力图范围（仅用于非totalRow的片区行）
                // isTotalRow: true=总达成行（仅超标红，不参与热力）；false=片区达成行（超标红+热力图）
                // ==========================================
                const buildSummaryRowHTML = (label, achievements, rowClass, limitsMap, heatmapRange, isTotalRow) => {
                    if (!achievements) return '';
                    let h = '<tr class="summary-row ' + rowClass + '">';
                    // 第一列：样式由CSS class控制，内联仅设padding/border/font
                    h += '<td style="padding:6px;border:1px solid #eef0f6;font-weight:600;white-space:nowrap;">' + escapeHTML(label) + '</td>';
                    achievementCategories.forEach((catKey, idx) => {
                        const val = achievements[catKey] || 0;
                        const lim = limitsMap ? (limitsMap[catKey] || 0) : 0;
                        const dv = formatAchievementValue(val, catKey, achievements, idx);
                        // 汇总行：根据数据长度自适应字体大小
                        const len = String(dv).length;
                        let fs = 0.62;
                        if (len > 5) fs = Math.max(0.38, 0.62 - (len - 5) * 0.035);
                        const fontSize = 'font-size:' + fs.toFixed(3) + 'rem;';
                        // 片区汇总行特殊：数据较长时同时缩小 padding
                        const cellPadding = (!isTotalRow && len > 8) ? 'padding:4px 2px;' : 'padding:6px 4px;';
                        let cellStyle = cellPadding + 'border:1px solid #eef0f6;text-align:center;white-space:nowrap;' + fontSize;
                        if (val === 0) {
                            cellStyle += 'color:#999 !important;'; // 仅文字灰色，不改变背景
                        } else if (lim > 0 && val > lim) {
                            if (isTotalRow) {
                                cellStyle += 'color:#FF4500 !important;font-weight:700 !important;'; // 顶级汇总行：超标红字
                            } else {
                                cellStyle += 'background:#FF4500 !important;color:#fff !important;'; // 片区汇总行：超标红底白字
                            }
                        } else if (!isTotalRow && heatmapRange) {
                            const range = heatmapRange[catKey];
                            if (range && range.max > range.min) {
                                const ratio = (val - range.min) / (range.max - range.min);
                                if (val === range.max && lim === 0) {
                                    cellStyle += 'background:#FFD700 !important;';
                                } else {
                                    const r = Math.round(255 * ratio + 29 * (1 - ratio));
                                    const g = Math.round(215 * ratio + 185 * (1 - ratio));
                                    const b = Math.round(0 * ratio + 84 * (1 - ratio));
                                    cellStyle += 'background:rgb(' + r + ',' + g + ',' + b + ') !important;';
                                }
                            }
                            // else: 无热力范围时由CSS class控制斑马纹背景
                        }
                        // else: isTotalRow由CSS class控制深灰背景，非totalRow无特殊条件时由CSS控制斑马纹
                        h += '<td style="' + cellStyle + '">' + dv + '</td>';
                    });
                    h += '</tr>';
                    return h;
                };

                // 表格模式HTML
                const multiFileLabel = isMultiFile ? ' <span style="font-size:0.7rem;color:#e67e22;font-weight:600;">（多文件合并汇总）</span>' : '';
                let html = '<div style="display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:12px;"><button id="btnCopyBadReview" style="font-size:0.7rem;padding:4px 12px;border:1.5px solid #fde2e4;border-radius:12px;background:#fff5f5;color:#e74c3c;font-weight:600;cursor:pointer;">差评</button><button id="btnCopyColdChain" style="font-size:0.7rem;padding:4px 12px;border:1.5px solid #cce5ff;border-radius:12px;background:#f0f7ff;color:#007bff;font-weight:600;cursor:pointer;">冷链</button><button id="btnCopyCake" style="font-size:0.7rem;padding:4px 12px;border:1.5px solid #e8d5f5;border-radius:12px;background:#faf5ff;color:#7c3aed;font-weight:600;cursor:pointer;">蛋糕</button><button id="btnCopyEgg" style="font-size:0.7rem;padding:4px 12px;border:1.5px solid #fde9c7;border-radius:12px;background:#fffaf0;color:#d97706;font-weight:600;cursor:pointer;">鸡蛋</button><span style="font-size:0.85rem;font-weight:700;color:#2d3a8c;flex:1;text-align:center;">📊 问单达成情况' + multiFileLabel + '</span><button id="btnShowCompliance" style="font-size:0.7rem;padding:4px 12px;border:1.5px solid #d5dcff;border-radius:12px;background:#f0f3ff;color:#4f6ef7;font-weight:600;cursor:pointer;">达标</button><button id="btnCopyStatistics" style="font-size:0.7rem;padding:4px 12px;border:1.5px solid #d4edda;border-radius:12px;background:#f0fff4;color:#28a745;font-weight:600;cursor:pointer;">统计</button></div>';

                // 片区模式或全部片区模式：展示所有片区门店
                if (selectedArea || (!selectedStore && allStores.length > 0)) {
                    const displayStores = selectedArea ? getAreaStores(selectedArea) : allStores;
                    if (!displayStores.length) {
                        panel.style.display = 'none';
                        return;
                    }

                    // ==========================================
                    // 汇总达成面板（紫色边框，最顶部）
                    // ==========================================

                    if (selectedArea) {
                        // ==========================================
                        // 单片区模式：仅显示生鲜店达成 + 前置仓达成
                        // ==========================================
                        const summarySx = computeSummaryAchievements(displayStores.filter(s => !s.includes('前置仓')));
                        const summaryQzc = computeSummaryAchievements(displayStores.filter(s => s.includes('前置仓')));

                        html += '<div style="background:#fff;border:3px solid #7c3aed;border-radius:14px;padding:12px 14px;margin-bottom:15px;">';
                        html += '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:0.78rem;table-layout:fixed;">';
                        html += '<thead>';
                        html += buildCategoryHeaderRow(true);
                        html += '</thead><tbody>';
                        html += buildSummaryRowHTML(selectedArea + '生鲜店', summarySx, 'summary-row-type', shengxianLimits, null, true);
                        html += buildSummaryRowHTML(selectedArea + '前置仓', summaryQzc, 'summary-row-type', qianzhicangLimits, null, true);
                        html += '</tbody></table></div></div>';
                    } else {
                        // ==========================================
                        // 全部片区模式
                        // 显示顺序：生鲜店总达成 → 各片区生鲜店达成 → 前置仓总达成 → 各片区前置仓达成
                        // 各片区行参与热力图渲染，总达成仅参与超标红
                        // ==========================================
                        const allAreaStores = getAllAreaStores();
                        const allAreaSummarySx = computeSummaryAchievements(allAreaStores.filter(s => !s.includes('前置仓')));
                        const allAreaSummaryQzc = computeSummaryAchievements(allAreaStores.filter(s => s.includes('前置仓')));

                        // ==========================================
                        // 热力图范围计算：每个数据块（生鲜店/前置仓）独立计算
                        // 先一次性收集各片区数据，再统一计算每个 catKey 的 min/max
                        // 热力图仅针对前12个百分比类目
                        // ==========================================
                        const heatmapCount = 12;

                        // ---- 生鲜店数据块 ----
                        const sxDataMap = new Map();
                        areaNames.forEach(an => {
                            const aStores = getAreaStores(an).filter(s => !s.includes('前置仓'));
                            const ach = computeSummaryAchievements(aStores);
                            if (ach) sxDataMap.set(an, ach);
                        });

                        const sxHeatmapRange = {};
                        achievementCategories.forEach((catKey, idx) => {
                            if (idx >= heatmapCount) return;
                            let vals = [];
                            sxDataMap.forEach(ach => {
                                const v = ach[catKey] || 0;
                                if (v > 0) vals.push(v);
                            });
                            if (vals.length > 0) {
                                const minVal = Math.min(...vals);
                                const maxVal = Math.max(...vals);
                                if (maxVal > minVal) {
                                    sxHeatmapRange[catKey] = { min: minVal, max: maxVal };
                                } else {
                                    // 所有非0值相同，以0为min，确保最高值ratio=1
                                    sxHeatmapRange[catKey] = { min: 0, max: maxVal };
                                }
                            } else {
                                sxHeatmapRange[catKey] = { min: 0, max: 1 };
                            }
                        });

                        // ---- 前置仓数据块 ----
                        const qzcDataMap = new Map();
                        areaNames.forEach(an => {
                            const aStores = getAreaStores(an).filter(s => s.includes('前置仓'));
                            const ach = computeSummaryAchievements(aStores);
                            if (ach) qzcDataMap.set(an, ach);
                        });

                        const qzcHeatmapRange = {};
                        achievementCategories.forEach((catKey, idx) => {
                            if (idx >= heatmapCount) return;
                            let vals = [];
                            qzcDataMap.forEach(ach => {
                                const v = ach[catKey] || 0;
                                if (v > 0) vals.push(v);
                            });
                            if (vals.length > 0) {
                                const minVal = Math.min(...vals);
                                const maxVal = Math.max(...vals);
                                if (maxVal > minVal) {
                                    qzcHeatmapRange[catKey] = { min: minVal, max: maxVal };
                                } else {
                                    qzcHeatmapRange[catKey] = { min: 0, max: maxVal };
                                }
                            } else {
                                qzcHeatmapRange[catKey] = { min: 0, max: 1 };
                            }
                        });

                        html += '<div style="background:#fff;border:3px solid #7c3aed;border-radius:14px;padding:12px 14px;margin-bottom:15px;">';
                        html += '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:0.78rem;table-layout:fixed;">';
                        html += '<thead>';
                        html += buildCategoryHeaderRow(true);
                        html += '</thead><tbody>';

                        // --- 生鲜店部分 ---
                        // 生鲜店总达成（仅超标红，不参与热力图）
                        html += buildSummaryRowHTML('生鲜店', allAreaSummarySx, 'summary-row-area', shengxianLimits, null, true);
                        // 各片区生鲜店（热力图+超标红）
                        areaNames.forEach(an => {
                            const ach = sxDataMap.get(an);
                            if (!ach) return;
                            html += buildSummaryRowHTML(an + '生鲜店', ach, 'summary-row-type', shengxianLimits, sxHeatmapRange, false);
                        });

                        // --- 分隔 ---
                        html += '<tr class="summary-divider-row"><td colspan="' + (achievementCategories.length + 1) + '"></td></tr>';

                        // --- 前置仓部分 ---
                        // 前置仓总达成（仅超标红，不参与热力图）
                        html += buildSummaryRowHTML('前置仓', allAreaSummaryQzc, 'summary-row-area', qianzhicangLimits, null, true);
                        // 各片区前置仓（热力图+超标红）
                        areaNames.forEach(an => {
                            const ach = qzcDataMap.get(an);
                            if (!ach) return;
                            html += buildSummaryRowHTML(an + '前置仓', ach, 'summary-row-type', qianzhicangLimits, qzcHeatmapRange, false);
                        });

                        html += '</tbody></table></div></div>';
                    }
                    
                    // ==========================================
                    // 门店明细表格（生鲜店蓝色边框 + 前置仓橙色边框）
                    // 每个分组表格内首行为子类型汇总
                    // ==========================================
                    
                    // 按第一个类目数据降序排序
                    const sortedStores = [...displayStores].sort((a, b) => {
                        const valA = getFirstCategoryValue(a);
                        const valB = getFirstCategoryValue(b);
                        return valB - valA;
                    });

                    // 分离生鲜店和前置仓
                    const sxStores = sortedStores.filter(s => !s.includes('前置仓'));
                    const qzcStores = sortedStores.filter(s => s.includes('前置仓'));

                    // 生鲜店分组（蓝色边框）
                    if (sxStores.length) {
                        html += '<div style="background:#fff;border:3px solid #3b82f6;border-radius:14px;padding:12px 14px;margin-bottom:15px;">';
                        html += '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:0.78rem;table-layout:fixed;">';
                        html += '<thead>';
                        html += buildCategoryHeaderRow(true);
                        html += '</thead><tbody>';
                        sxStores.forEach(storeName => {
                            const sd = currentAchData[storeName];
                            if (!sd) return;
                            const st = sd.type;
                            const limits = st === 'qianzhicang' ? qianzhicangLimits : shengxianLimits;
                            const ach = sd.achievements;
                            html += '<tr><td style="padding:6px;border:1px solid #eef0f6;font-weight:600;white-space:nowrap;background:#f8f9fd;">' + escapeHTML(storeName) + '</td>';
                            achievementCategories.forEach((catKey, idx) => {
                                const val = ach[catKey] || 0;
                                const lim = limits[catKey] || 0;
                                const dv = formatAchievementValue(val, catKey, ach, idx);
                                const fontStyle = getValueStyle(val, lim, catKey, idx, false); // 生鲜店
                                html += '<td style="padding:6px 4px;border:1px solid #eef0f6;text-align:center;white-space:nowrap;' + fontStyle + '">' + dv + '</td>';
                            });
                            html += '</tr>';
                        });
                        html += '</tbody></table></div></div>';
                    }
                    // 前置仓分组（橙色边框）
                    if (qzcStores.length) {
                        html += '<div style="background:#fff;border:3px solid #f59e0b;border-radius:14px;padding:12px 14px;">';
                        html += '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:0.78rem;table-layout:fixed;">';
                        html += '<thead>';
                        html += buildCategoryHeaderRow(true);
                        html += '</thead><tbody>';
                        qzcStores.forEach(storeName => {
                            const sd = currentAchData[storeName];
                            if (!sd) return;
                            const st = sd.type;
                            const limits = st === 'qianzhicang' ? qianzhicangLimits : shengxianLimits;
                            const ach = sd.achievements;
                            html += '<tr><td style="padding:6px;border:1px solid #eef0f6;font-weight:600;white-space:nowrap;background:#f8f9fd;">' + escapeHTML(storeName) + '</td>';
                            achievementCategories.forEach((catKey, idx) => {
                                const val = ach[catKey] || 0;
                                const lim = limits[catKey] || 0;
                                const dv = formatAchievementValue(val, catKey, ach, idx);
                                const fontStyle = getValueStyle(val, lim, catKey, idx, true); // 前置仓
                                html += '<td style="padding:6px 4px;border:1px solid #eef0f6;text-align:center;white-space:nowrap;' + fontStyle + '">' + dv + '</td>';
                            });
                            html += '</tr>';
                        });
                        html += '</tbody></table></div></div>';
                    }
                } else if (selectedStore) {
                    // 单门店模式
                    const storeData = currentAchData[selectedStore];
                    if (!storeData) {
                        panel.style.display = 'none';
                        return;
                    }
                    const storeType = storeData.type;
                    const storeTypeLabel = storeType === 'qianzhicang' ? '前置仓' : '生鲜店';
                    const storeTypeClass = storeType === 'qianzhicang' ? 'qianzhicang' : 'shengxian';
                    const limits = storeType === 'qianzhicang' ? qianzhicangLimits : shengxianLimits;
                    const achievements = storeData.achievements;
                    html += '<thead>';
                    html += '<tr style="background:#eef1fd;"><th colspan="' + achievementCategories.length + '" style="padding:6px 12px;font-size:0.75rem;font-weight:700;color:#2d3a8c;text-align:center;"><span class="store-type-tag ' + storeTypeClass + '">' + storeTypeLabel + '</span></th></tr>';
                    html += buildCategoryHeaderRow(false);
                    html += '</thead><tbody><tr>';
                    achievementCategories.forEach((catKey, idx) => {
                        const actualValue = achievements[catKey] || 0;
                        const limitValue = limits[catKey] || 0;
                        const displayValue = formatAchievementValue(actualValue, catKey, achievements, idx);
                        const fontStyle = getValueStyle(actualValue, limitValue, catKey, idx, storeType === 'qianzhicang');
                        html += '<td style="padding:6px 4px;border:1px solid #eef0f6;text-align:center;white-space:nowrap;' + fontStyle + '">' + displayValue + '</td>';
                    });
                    html += '</tr></tbody>';
                } else {
                    // 无数据
                    panel.style.display = 'none';
                    return;
                }

                html += '</table></div></div>';
                panel.innerHTML = html;
                panel.style.display = 'block';
                
                // 绑定一键复制全部按钮事件
                const complianceBtn = document.getElementById('btnShowCompliance');
                if (complianceBtn) {
                    complianceBtn.addEventListener('click', copyComplianceAll);
                }
                // 绑定一键差评按钮事件
                const badReviewBtn = document.getElementById('btnCopyBadReview');
                if (badReviewBtn) {
                    badReviewBtn.addEventListener('click', () => copyBadReviewAll(badReviewBtn));
                }
                // 绑定一键统计按钮事件
                const statBtn = document.getElementById('btnCopyStatistics');
                if (statBtn) {
                    statBtn.addEventListener('click', () => copyStatisticsAll(statBtn));
                }
                // 绑定冷链按钮事件
                const coldBtn = document.getElementById('btnCopyColdChain');
                if (coldBtn) {
                    coldBtn.addEventListener('click', () => copyColdChainAll(coldBtn));
                }
                // 绑定蛋糕按钮事件
                const cakeBtn = document.getElementById('btnCopyCake');
                if (cakeBtn) {
                    cakeBtn.addEventListener('click', () => copyCakeAll(cakeBtn));
                }
                // 绑定鸡蛋按钮事件
                const eggBtn = document.getElementById('btnCopyEgg');
                if (eggBtn) {
                    eggBtn.addEventListener('click', () => copyEggAll(eggBtn));
                }
            }

            // 一键差评：复制当前片区/门店筛选下的差评数据（剔除片区列、剔除表头，排序不变）
            function copyBadReviewAll(btn) {
                if (!badReviewData.length) { toast('暂无差评数据'); return; }
                // 受片区/门店筛选限制：直接使用当前 selectedArea/selectedStore
                const rows = buildBadReviewSheetData();
                if (!rows.length || rows.length <= 1) { toast('暂无差评数据'); return; }
                // rows[0] 是表头，跳过；全部片区时第0列是"归属片区"，需剔除
                const hasAreaCol = rows[0][0] === '归属片区';
                let plain = '';
                for (let i = 1; i < rows.length; i++) {
                    const row = hasAreaCol ? rows[i].slice(1) : rows[i];
                    plain += row.join('\t') + '\n';
                }
                if (!plain.trim()) { toast('暂无差评数据'); return; }
                // 直接写入剪贴板，仅toast提示，不改变按钮文字
                navigator.clipboard.writeText(plain.trimEnd()).then(() => {
                    toast('✅ 已复制差评数据');
                }).catch(() => {
                    const ta = document.createElement('textarea');
                    ta.value = plain.trimEnd();
                    ta.style.cssText = 'position:fixed;left:-9999px;';
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    document.body.removeChild(ta);
                    toast('✅ 已复制差评数据');
                });
            }

            // 冷链：复制当前片区/门店筛选下的冷链化冻数据（日期	sku名称	门店名称	配送单号	配送员名，不含表头）
            function copyColdChainAll(btn) {
                if (!coldThawData.length) { toast('暂无冷链化冻数据'); return; }
                // 受片区/门店筛选限制：直接使用当前 selectedArea/selectedStore
                const rows = buildColdThawSheetData();
                if (!rows.length || rows.length <= 1) { toast('暂无冷链化冻数据'); return; }
                // rows[0]是表头，跳过；全部门店时第0列是"归属片区"，需剔除
                const hasAreaCol = rows[0][0] === '归属片区';
                let plain = '';
                for (let i = 1; i < rows.length; i++) {
                    const row = hasAreaCol ? rows[i].slice(1) : rows[i];
                    // 只取前5列：日期、sku名称、门店名称、配送单号、配送员名
                    plain += row.slice(0, 5).join('\t') + '\n';
                }
                if (!plain.trim()) { toast('暂无冷链化冻数据'); return; }
                navigator.clipboard.writeText(plain.trimEnd()).then(() => {
                    toast('✅ 已复制冷链化冻数据');
                }).catch(() => {
                    const ta = document.createElement('textarea');
                    ta.value = plain.trimEnd();
                    ta.style.cssText = 'position:fixed;left:-9999px;';
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    document.body.removeChild(ta);
                    toast('✅ 已复制冷链化冻数据');
                });
            }

            // 物流损+SKU关键词复制（输出列：日期	片区	门店名称	sku名称	配送单号	配送员，不含表头）
            // keywords: 关键词组。支持两种形式：
            //   1) ['关键词A','关键词B']         → 单一组，需同时包含（AND）
            //   2) [['A','B'], ['C','D']]        → 多组，任一组全部满足即可（组间 OR、组内 AND）
            // label: 按钮提示用名称
            function copyLogisticsBySku(keywords, label) {
                if (!logisticsData.length) { toast('暂无物流损数据'); return; }

                // 构建门店→片区映射
                const storeAreaMap = {};
                for (const [area, stores] of Object.entries(areaStoreMap)) {
                    stores.forEach(s => { storeAreaMap[s] = area; });
                }

                // 归一化为「关键词组」数组
                const groups = (Array.isArray(keywords) && Array.isArray(keywords[0]))
                    ? keywords
                    : [Array.isArray(keywords) ? keywords : [keywords]];
                // 先按 sku 关键词过滤物流损（组内全部命中、组间任一命中）
                const skuMatched = logisticsData.filter(r => {
                    const sku = String(getColValue(r,'sku名称')||getColValue(r,'SKU名称')||'').trim();
                    return groups.some(g => g.every(kw => sku.includes(kw)));
                });
                if (!skuMatched.length) { toast(`暂无${label}相关物流损数据`); return; }

                // 再按当前片区/门店筛选
                let filtered;
                if (selectedStore) {
                    filtered = skuMatched.filter(r => String(getColValue(r,'门店名称')||'').trim() === selectedStore);
                } else if (selectedArea) {
                    const stores = getAreaStores(selectedArea);
                    filtered = skuMatched.filter(r => stores.includes(String(getColValue(r,'门店名称')||'').trim()));
                } else {
                    const allStores = getAllAreaStores();
                    filtered = skuMatched.filter(r => allStores.includes(String(getColValue(r,'门店名称')||'').trim()));
                }
                if (!filtered.length) { toast(`暂无${label}相关物流损数据`); return; }

                // 按片区+门店名称排序
                filtered.sort((a, b) => {
                    const sa = String(getColValue(a,'门店名称')||'').trim();
                    const sb = String(getColValue(b,'门店名称')||'').trim();
                    const areaA = storeAreaMap[sa] || '';
                    const areaB = storeAreaMap[sb] || '';
                    const cmp = areaA.localeCompare(areaB, 'zh-CN');
                    if (cmp !== 0) return cmp;
                    return sa.localeCompare(sb, 'zh-CN');
                });

                let plain = '';
                filtered.forEach(row => {
                    const sn = String(getColValue(row,'门店名称')||'').trim();
                    const line = [
                        getColValue(row,'日期')||'',
                        storeAreaMap[sn] || '',
                        sn,
                        getColValue(row,'sku名称')||getColValue(row,'SKU名称')||'',
                        getColValue(row,'配送单号')||getColValue(row,'淘系主订单id')||'',
                        getColValue(row,'配送员名')||getColValue(row,'配送员名称')||''
                    ].join('\t');
                    plain += line + '\n';
                });
                if (!plain.trim()) { toast(`暂无${label}相关物流损数据`); return; }
                navigator.clipboard.writeText(plain.trimEnd()).then(() => {
                    toast(`✅ 已复制${label}数据`);
                }).catch(() => {
                    const ta = document.createElement('textarea');
                    ta.value = plain.trimEnd();
                    ta.style.cssText = 'position:fixed;left:-9999px;';
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    document.body.removeChild(ta);
                    toast(`✅ 已复制${label}数据`);
                });
            }

            // 蛋糕：物流损 + sku名称含"草莓盒子"
            function copyCakeAll(btn) { copyLogisticsBySku('草莓盒子', '蛋糕'); }

            // 鸡蛋：物流损 + (sku名称同时含"鸡蛋"和"枚") 或 (同时含"谷物蛋"和"枚")
            function copyEggAll(btn) { copyLogisticsBySku([['鸡蛋', '枚'], ['谷物蛋', '枚']], '鸡蛋'); }

            // 一键统计：输出当前片区/门店筛选下冷链化冻和差评的门店明细与数量到剪贴板
            function copyStatisticsAll(btn) {
                if (!coldThawData.length && !badReviewData.length) {
                    toast('暂无冷链化冻和差评数据');
                    return;
                }

                // 受片区/门店筛选限制：确定统计范围
                let targetStores;       // Set：纳入统计的门店集合
                let scopeName;          // 表头显示名（片区名/门店名/苏南片区）
                let isSingleStore = false;
                let isSingleArea = false;
                if (selectedStore) {
                    targetStores = new Set([selectedStore]);
                    scopeName = selectedStore;
                    isSingleStore = true;
                } else if (selectedArea) {
                    targetStores = new Set(getAreaStores(selectedArea));
                    scopeName = selectedArea;
                    isSingleArea = true;
                } else {
                    targetStores = new Set(getAllAreaStores());
                    scopeName = '苏南片区';
                }

                // 获取统计日期
                const info = getDateRangeInfo();
                const rawDate = info.range || getYesterdayDateStr();
                const fmtDate = (s) => {
                    const d = String(s).replace(/[-\\/]/g, '');
                    if (d.length >= 8) {
                        const y = d.substring(0, 4);
                        const m = parseInt(d.substring(4, 6), 10);
                        const day = parseInt(d.substring(6, 8), 10);
                        return y + '-' + m + '-' + day;
                    }
                    return s;
                };
                let dateStr;
                if (rawDate.includes('-')) {
                    const parts = rawDate.split('-');
                    dateStr = fmtDate(parts[0]) + '-' + fmtDate(parts[1]);
                } else {
                    dateStr = fmtDate(rawDate);
                }

                let plain = '';

                // 冷链化冻统计（门店名称列）
                if (coldThawData.length) {
                    const storeCountMap = {};
                    coldThawData.forEach(row => {
                        const sn = String(getColValue(row, '门店名称') || '').trim();
                        if (!sn || !targetStores.has(sn)) return;
                        storeCountMap[sn] = (storeCountMap[sn] || 0) + 1;
                    });
                    const total = Object.values(storeCountMap).reduce((a, b) => a + b, 0);
                    if (total > 0) {
                        plain += '\n' + dateStr + ' ' + scopeName + ' 冷链化冻：' + total + ' 条\n';

                        if (isSingleStore || isSingleArea) {
                            // 单门店/单片区：直接列出门店明细（不区分片区）
                            const sortedStores = Object.keys(storeCountMap).sort((a, b) =>
                                storeCountMap[b] - storeCountMap[a] || a.localeCompare(b, 'zh-CN'));
                            sortedStores.forEach(sn => {
                                plain += '       ' + sn + '，' + storeCountMap[sn] + ' 条\n';
                            });
                        } else {
                            // 全部片区：按片区汇总数量，然后降序排序
                            const areaTotals = [];
                            areaNames.forEach(an => {
                                const areaStores = getAreaStores(an);
                                let areaTotal = 0;
                                const areaStoreCounts = {};
                                areaStores.forEach(sn => {
                                    if (storeCountMap[sn]) {
                                        areaStoreCounts[sn] = storeCountMap[sn];
                                        areaTotal += storeCountMap[sn];
                                    }
                                });
                                if (areaTotal > 0) {
                                    areaTotals.push({ name: an, total: areaTotal, storeCounts: areaStoreCounts });
                                }
                            });
                            areaTotals.sort((a, b) => b.total - a.total);
                            areaTotals.forEach(at => {
                                plain += at.name + '，' + at.total + ' 条\n';
                                const sortedStores = Object.keys(at.storeCounts).sort((a, b) =>
                                    at.storeCounts[b] - at.storeCounts[a] || a.localeCompare(b, 'zh-CN'));
                                sortedStores.forEach(sn => {
                                    plain += '       ' + sn + '，' + at.storeCounts[sn] + ' 条\n';
                                });
                            });

                            const allAreaStoreSet = new Set(getAllAreaStores());
                            const orphanCounts = {};
                            Object.keys(storeCountMap).forEach(sn => {
                                if (!allAreaStoreSet.has(sn)) {
                                    orphanCounts[sn] = storeCountMap[sn];
                                }
                            });
                            const orphanTotal = Object.values(orphanCounts).reduce((a, b) => a + b, 0);
                            if (orphanTotal > 0) {
                                plain += '其他，' + orphanTotal + ' 条\n';
                                const sortedOrphans = Object.keys(orphanCounts).sort((a, b) =>
                                    orphanCounts[b] - orphanCounts[a] || a.localeCompare(b, 'zh-CN'));
                                sortedOrphans.forEach(sn => {
                                    plain += '       ' + sn + '，' + orphanCounts[sn] + ' 条\n';
                                });
                            }
                        }
                        plain += '\n';
                    }
                }

                // 差评统计（门店列）+ 服务态度差评计数
                if (badReviewData.length) {
                    const storeCountMap = {};
                    const storeServiceMap = {}; // 门店→服务态度差评数
                    let totalService = 0;
                    badReviewData.forEach(row => {
                        const sn = String(getColValue(row, '门店') || '').trim();
                        if (!sn || !targetStores.has(sn)) return;
                        storeCountMap[sn] = (storeCountMap[sn] || 0) + 1;
                        storeServiceMap[sn] = storeServiceMap[sn] || 0;
                        // 检查评价标签是否包含"9:服务态度不好"
                        const tags = String(getColValue(row, '评价标签') || '').trim();
                        if (tags && tags.includes('9:服务态度不好')) {
                            storeServiceMap[sn]++;
                            totalService++;
                        }
                    });
                    const total = Object.values(storeCountMap).reduce((a, b) => a + b, 0);
                    if (total > 0) {
                        const totalSvcStr = totalService > 0 ? '，服务态度 ' + totalService + ' 条' : '';
                        plain += '\n' + dateStr + ' ' + scopeName + ' 差评：' + total + ' 条' + totalSvcStr + '\n';

                        if (isSingleStore || isSingleArea) {
                            // 单门店/单片区：直接列出门店明细（不区分片区）
                            const sortedStores = Object.keys(storeCountMap).sort((a, b) =>
                                storeCountMap[b] - storeCountMap[a] || a.localeCompare(b, 'zh-CN'));
                            sortedStores.forEach(sn => {
                                const svc = storeServiceMap[sn] || 0;
                                const storeSvcStr = svc > 0 ? '，服务态度 ' + svc + ' 条' : '';
                                plain += '       ' + sn + '，' + storeCountMap[sn] + ' 条' + storeSvcStr + '\n';
                            });
                        } else {
                            // 全部片区：按片区汇总数量，然后降序排序
                            const areaTotals = [];
                            areaNames.forEach(an => {
                                const areaStores = getAreaStores(an);
                                let areaTotal = 0;
                                let areaService = 0;
                                const areaStoreCounts = {};
                                const areaServiceCounts = {};
                                areaStores.forEach(sn => {
                                    if (storeCountMap[sn]) {
                                        areaStoreCounts[sn] = storeCountMap[sn];
                                        areaServiceCounts[sn] = storeServiceMap[sn] || 0;
                                        areaTotal += storeCountMap[sn];
                                        areaService += storeServiceMap[sn] || 0;
                                    }
                                });
                                if (areaTotal > 0) {
                                    areaTotals.push({ name: an, total: areaTotal, service: areaService, storeCounts: areaStoreCounts, serviceCounts: areaServiceCounts });
                                }
                            });
                            areaTotals.sort((a, b) => b.total - a.total);
                            areaTotals.forEach(at => {
                                const areaSvcStr = at.service > 0 ? '，服务态度 ' + at.service + ' 条' : '';
                                plain += at.name + '，' + at.total + ' 条' + areaSvcStr + '\n';
                                const sortedStores = Object.keys(at.storeCounts).sort((a, b) =>
                                    at.storeCounts[b] - at.storeCounts[a] || a.localeCompare(b, 'zh-CN'));
                                sortedStores.forEach(sn => {
                                    const svc = at.serviceCounts[sn] || 0;
                                    const storeSvcStr = svc > 0 ? '，服务态度 ' + svc + ' 条' : '';
                                    plain += '       ' + sn + '，' + at.storeCounts[sn] + ' 条' + storeSvcStr + '\n';
                                });
                            });

                            const allAreaStoreSet = new Set(getAllAreaStores());
                            const orphanCounts = {};
                            const orphanService = {};
                            Object.keys(storeCountMap).forEach(sn => {
                                if (!allAreaStoreSet.has(sn)) {
                                    orphanCounts[sn] = storeCountMap[sn];
                                    orphanService[sn] = storeServiceMap[sn] || 0;
                                }
                            });
                            const orphanTotal = Object.values(orphanCounts).reduce((a, b) => a + b, 0);
                            const orphanSvcTotal = Object.values(orphanService).reduce((a, b) => a + b, 0);
                            if (orphanTotal > 0) {
                                const orphanSvcStr = orphanSvcTotal > 0 ? '，服务态度 ' + orphanSvcTotal + ' 条' : '';
                                plain += '其他，' + orphanTotal + ' 条' + orphanSvcStr + '\n';
                                const sortedOrphans = Object.keys(orphanCounts).sort((a, b) =>
                                    orphanCounts[b] - orphanCounts[a] || a.localeCompare(b, 'zh-CN'));
                                sortedOrphans.forEach(sn => {
                                    const svc = orphanService[sn] || 0;
                                    const oStoreSvcStr = svc > 0 ? '，服务态度 ' + svc + ' 条' : '';
                                    plain += '       ' + sn + '，' + orphanCounts[sn] + ' 条' + oStoreSvcStr + '\n';
                                });
                            }
                        }
                    }
                }

                if (!plain.trim()) {
                    toast('暂无冷链化冻和差评数据');
                    return;
                }

                navigator.clipboard.writeText(plain.trimEnd()).then(() => {
                    toast('✅ 已复制统计明细');
                }).catch(() => {
                    const ta = document.createElement('textarea');
                    ta.value = plain.trimEnd();
                    ta.style.cssText = 'position:fixed;left:-9999px;';
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    document.body.removeChild(ta);
                    toast('✅ 已复制统计明细');
                });
            }

            function copyComplianceAll() {
                if (!achievementCategories.length) { toast('暂无达标数据'); return; }
                const currentAchData = getCurrentAchievements();
                let stores = [];
                if (selectedArea) stores = getAreaStores(selectedArea);
                else if (selectedStore) stores = [selectedStore];
                else stores = getAllAreaStores();
                if (!stores.length) { toast('暂无门店数据'); return; }
                const ck = achievementCategories[0];
                const sx = stores.filter(s => !s.includes('前置仓'));
                const qzc = stores.filter(s => s.includes('前置仓'));
                const classify = (list, limits) => {
                    const compliant = [], nonCompliant = [];
                    list.forEach(sn => {
                        const sd = currentAchData[sn]; if (!sd) return;
                        const val = sd.achievements[ck] || 0;
                        const lim = limits[ck] || 0;
                        (lim > 0 && val > lim ? nonCompliant : compliant).push(sn);
                    });
                    return { compliant, nonCompliant };
                };
                const sxResult = classify(sx, shengxianLimits);
                const qzcResult = classify(qzc, qianzhicangLimits);
                // 获取统计日期，格式化为 2026/7/24
                const getStatDateStr = () => {
                    const info = getDateRangeInfo();
                    const raw = info.range || getYesterdayDateStr();
                    const fmt = (s) => {
                        const d = String(s).replace(/[-\/]/g, '');
                        if (d.length >= 8) {
                            const y = d.substring(0, 4);
                            const m = parseInt(d.substring(4, 6), 10);
                            const day = parseInt(d.substring(6, 8), 10);
                            return y + '/' + m + '/' + day;
                        }
                        return s;
                    };
                    if (raw.includes('-')) {
                        const parts = raw.split('-');
                        return fmt(parts[0]) + '-' + fmt(parts[1]);
                    }
                    return fmt(raw);
                };
                const dateStr = getStatDateStr();
                let plain = '';
                const addSection = (tag, list) => { list.forEach(sn => plain += dateStr + '\t' + sn + '\t' + tag + '\n'); };
                addSection('达标', sxResult.compliant);
                addSection('达标', qzcResult.compliant);
                addSection('不达标', sxResult.nonCompliant);
                addSection('不达标', qzcResult.nonCompliant);
                if (!plain) { toast('暂无达标数据'); return; }
                navigator.clipboard.writeText(plain.trimEnd()).then(() => toast('✅ 已复制达标数据')).catch(() => toast('❌ 复制失败'));
            }

            function showCompliancePopup() {
                if (!achievementCategories.length) return;
                
                const currentAchData = getCurrentAchievements();

                // 获取当前筛选的门店列表
                let stores = [];
                if (selectedArea) {
                    stores = getAreaStores(selectedArea);
                } else if (selectedStore) {
                    stores = [selectedStore];
                } else {
                    stores = getAllAreaStores();
                }
                if (!stores.length) return;

                // 按第一个类目数据降序排序
                const getFirstCategoryValue = (storeName) => {
                    const sd = currentAchData[storeName];
                    if (!sd || !achievementCategories.length) return 0;
                    return sd.achievements[achievementCategories[0]] || 0;
                };
                
                const sortedStores = [...stores].sort((a, b) => getFirstCategoryValue(b) - getFirstCategoryValue(a));
                
                // 分离生鲜店和前置仓
                const sxStores = sortedStores.filter(s => !s.includes('前置仓'));
                const qzcStores = sortedStores.filter(s => s.includes('前置仓'));
                
                // 收集不达标门店
                const nonCompliantStores = [];
                
                // 构建达标数据
                let tableHtml = '<table style="width:auto;min-width:100%;border-collapse:collapse;font-size:0.75rem;margin-top:10px;table-layout:fixed;">';
                tableHtml += '<thead><tr style="background:#f0f2fc;"><th style="padding:6px 8px;border:1px solid #dde3f0;font-weight:700;white-space:nowrap;width:70%;">门店</th><th style="padding:6px 8px;border:1px solid #dde3f0;font-weight:700;white-space:nowrap;width:30%;">是否达标</th></tr></thead><tbody>';
                
                const buildRows = (storeList, limitsMap) => {
                    storeList.forEach(storeName => {
                        const sd = currentAchData[storeName];
                        if (!sd) return;
                        const limits = limitsMap;
                        const ach = sd.achievements;
                        const firstCatKey = achievementCategories[0];
                        const val = ach[firstCatKey] || 0;
                        const lim = limits[firstCatKey] || 0;
                        const isOver = lim > 0 && val > lim;
                        if (isOver) nonCompliantStores.push(storeName);
                        const statusHtml = isOver 
                            ? '<span style="color:#c0392b;font-weight:700;">❌ 不达标</span>' 
                            : '<span style="color:#27ae60;font-weight:700;">✅ 达标</span>';
                        tableHtml += `<tr><td style="padding:6px 8px;border:1px solid #eef0f6;font-weight:600;background:#f8f9fd;">${escapeHTML(storeName)}</td><td style="padding:6px 8px;border:1px solid #eef0f6;text-align:center;">${statusHtml}</td></tr>`;
                    });
                };
                
                buildRows(sxStores, shengxianLimits);
                buildRows(qzcStores, qianzhicangLimits);
                
                tableHtml += '</tbody></table>';
                
                // 构建纯文本用于复制（全部）- 日期列+门店名+达标情况，不包含表头
                let plainTextAll = '';
                const getStatDateStr = () => {
                    const info = getDateRangeInfo();
                    const raw = info.range || getYesterdayDateStr();
                    const fmt = (s) => {
                        const d = String(s).replace(/[-\/]/g, '');
                        if (d.length >= 8) {
                            const y = d.substring(0, 4);
                            const m = parseInt(d.substring(4, 6), 10);
                            const day = parseInt(d.substring(6, 8), 10);
                            return y + '/' + m + '/' + day;
                        }
                        return s;
                    };
                    if (raw.includes('-')) {
                        const parts = raw.split('-');
                        return fmt(parts[0]) + '-' + fmt(parts[1]);
                    }
                    return fmt(raw);
                };
                const dateStr = getStatDateStr();
                const buildPlainRows = (storeList, limitsMap) => {
                    storeList.forEach(storeName => {
                        const sd = currentAchData[storeName];
                        if (!sd) return;
                        const limits = limitsMap;
                        const ach = sd.achievements;
                        const firstCatKey = achievementCategories[0];
                        const val = ach[firstCatKey] || 0;
                        const lim = limits[firstCatKey] || 0;
                        const isOver = lim > 0 && val > lim;
                        plainTextAll += `${dateStr}\t${storeName}\t${isOver ? '不达标' : '达标'}\n`;
                    });
                };
                
                buildPlainRows(sxStores, shengxianLimits);
                buildPlainRows(qzcStores, qianzhicangLimits);
                
                // 构建不达标门店纯文本
                const plainTextNonCompliant = '不达标门店\n' + nonCompliantStores.join('\n');
                
                const bodyHTML = `
                    <div>
                        ${tableHtml}
                    </div>
                    <div style="margin-top:12px;display:flex;gap:8px;justify-content:flex-end;">
                        <button id="btnCopyCompliance" style="font-size:0.75rem;padding:6px 16px;border:none;border-radius:10px;background:#4f6ef7;color:white;font-weight:600;cursor:pointer;">📋 一键复制全部</button>
                    </div>
                `;
                
                openGuideView('📋 达标情况查看', '第一个类目标红=不达标，其他达标', bodyHTML, '<button class="guide-btn secondary" data-close-guide>关闭</button>');
                
                // 弹窗设置最小宽度为屏幕1/4，获取后锁定不再根据内容调整
                setTimeout(() => {
                    const guideCard = document.querySelector('.guide-card');
                    if (guideCard) {
                        const minW = Math.floor(window.innerWidth / 4);
                        guideCard.style.minWidth = minW + 'px';
                        guideCard.style.maxWidth = '95vw';
                        guideCard.style.maxHeight = '95vh';
                        // 锁定宽度：获取当前实际宽度后固定，不再自适应
                        const currentW = guideCard.offsetWidth;
                        guideCard.style.width = currentW + 'px';
                        guideCard.style.overflow = 'auto';
                    }
                }, 50);
                
                // 绑定复制全部按钮
                setTimeout(() => {
                    const copyBtn = document.getElementById('btnCopyCompliance');
                    if (copyBtn) {
                        copyBtn.addEventListener('click', () => {
                            doCopy(plainTextAll, copyBtn, '📋 一键复制全部');
                        });
                    }
                }, 100);
            }

            function doCopy(text, btn, originalText) {
                navigator.clipboard.writeText(text).then(() => {
                    toast('✅ 已复制到剪贴板');
                    btn.textContent = '✅ 已复制';
                    btn.style.background = '#27ae60';
                    setTimeout(() => {
                        btn.textContent = originalText;
                        btn.style.background = '';
                    }, 2000);
                }).catch(() => {
                    const ta = document.createElement('textarea');
                    ta.value = text;
                    ta.style.cssText = 'position:fixed;left:-9999px;';
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    document.body.removeChild(ta);
                    toast('✅ 已复制到剪贴板');
                    btn.textContent = '✅ 已复制';
                    btn.style.background = '#27ae60';
                    setTimeout(() => {
                        btn.textContent = originalText;
                        btn.style.background = '';
                    }, 2000);
                });
            }

            // 查看类目上限值弹窗
            function showLimitsPopup() {
                if (!achievementCategories.length) {
                    toast('⚠️ 暂无类目数据');
                    return;
                }
                let html = '<div style="display:flex;gap:20px;flex-wrap:wrap;">';
                // 生鲜店上限
                html += '<div style="flex:1;min-width:200px;"><div style="font-size:0.9rem;font-weight:700;color:#2d3a8c;margin-bottom:8px;padding-bottom:6px;border-bottom:2px solid #4f6ef7;">生鲜店</div>';
                achievementCategories.slice(0, 12).forEach((ck, idx) => {
                    const dn = categoryKeyToDisplay.get(ck) || ck;
                    const short = dn.includes('｜') ? dn.split('｜')[0] : dn;
                    const lim = shengxianLimits[ck] || 0;
                    const limStr = lim > 0 ? formatLimitValue(lim, dn, idx) : '无上限';
                    const limColor = lim > 0 ? '#333' : '#aaa';
                    html += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #f0f0f0;"><span style="color:#555;font-size:0.8rem;">' + escapeHTML(short) + '</span><span style="color:' + limColor + ';font-size:0.8rem;font-weight:600;">' + limStr + '</span></div>';
                });
                html += '</div>';
                // 前置仓上限
                html += '<div style="flex:1;min-width:200px;"><div style="font-size:0.9rem;font-weight:700;color:#2d3a8c;margin-bottom:8px;padding-bottom:6px;border-bottom:2px solid #e67e22;">前置仓</div>';
                achievementCategories.slice(0, 12).forEach((ck, idx) => {
                    const dn = categoryKeyToDisplay.get(ck) || ck;
                    const short = dn.includes('｜') ? dn.split('｜')[0] : dn;
                    const lim = qianzhicangLimits[ck] || 0;
                    const limStr = lim > 0 ? formatLimitValue(lim, dn, idx) : '无上限';
                    const limColor = lim > 0 ? '#333' : '#aaa';
                    html += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #f0f0f0;"><span style="color:#555;font-size:0.8rem;">' + escapeHTML(short) + '</span><span style="color:' + limColor + ';font-size:0.8rem;font-weight:600;">' + limStr + '</span></div>';
                });
                html += '</div>';
                html += '</div>';
                openGuideView('📋 类目上限值', '', html, '');
            }
            window.showLimitsPopup = showLimitsPopup;

            function openGuideView(title, subtitle, bodyHTML, footerHTML) {
                guideCard.innerHTML = `
                    <button class="guide-close-btn" id="guideCloseBtn">✕</button>
                    <div class="guide-title">${title}</div>
                    <div class="guide-subtitle">${subtitle}</div>
                    <div class="guide-body">${bodyHTML}</div>
                    <div class="guide-footer">${footerHTML}</div>
                `;
                guideOverlay.style.display = 'flex';
                document.getElementById('guideCloseBtn').onclick = () => guideOverlay.style.display = 'none';
                guideOverlay.onclick = function(e) {
                    if (e.target === guideOverlay) guideOverlay.style.display = 'none';
                };
            }

            // 片区筛选弹窗
            function showAreaSelection() {
                if (!areaNames.length) {
                    toast('⚠️ 未找到片区数据，请确认Excel中包含「数据展示」工作簿，且A列包含有效的片区名称');
                    return;
                }
                let html = `<div id="areaList" style="max-height:350px;overflow-y:auto;display:flex;flex-direction:column;">`;
                html += `<label style="display:flex;align-items:center;gap:8px;padding:9px 12px;cursor:pointer;border-radius:8px;background:#f5f7ff;border:1.5px solid var(--primary);" id="areaOptionAll"><input type="radio" name="areaRadio" value="__ALL__" ${selectedArea===null?'checked':''}> 🌐 全部片区</label>`;
                areaNames.forEach(a => {
                    const storeCount = (areaStoreMap[a] || []).length;
                    html += `<label style="display:flex;align-items:center;gap:8px;padding:9px 12px;cursor:pointer;border-radius:8px;"><input type="radio" name="areaRadio" value="${escapeHTML(a)}" ${selectedArea===a?'checked':''}> ${escapeHTML(a)} <span style="font-size:0.65rem;color:#8b8ba8;margin-left:auto;">${storeCount}家门店</span></label>`;
                });
                html += `</div>`;
                openGuideView('🗺️ 片区筛选', '选择片区后等同于选择该片区全部门店', html, '<button class="guide-btn primary" id="confirmArea">✓ 确认</button>');
                document.getElementById('confirmArea').addEventListener('click', () => {
                    const radio = document.querySelector('input[name="areaRadio"]:checked');
                    selectedArea = radio && radio.value !== '__ALL__' ? radio.value : null;
                    // 选择片区时，清空单门店选择
                    selectedStore = null;
                    guideOverlay.style.display = 'none';
                    initializeMainUI();
                });
            }

            // 片区快速选择弹窗（文件导入后调用，仅显示片区按钮点选）
            function showAreaQuickSelect() {
                if (!areaNames.length) {
                    // 无片区数据时直接显示全部
                    selectedArea = null;
                    selectedStore = null;
                    initializeMainUI();
                    return;
                }
                let html = `<div style="background:#f5f7ff;border:1.5px solid #dde3f8;border-radius:10px;padding:12px;"><div style="font-size:0.75rem;color:#6b6b88;margin-bottom:10px;font-weight:600;">📍 选择片区（点击直接筛选）</div><div style="display:flex;flex-wrap:wrap;gap:8px;">`;
                areaNames.forEach(area => {
                    const count = (areaStoreMap[area] || []).length;
                    html += `<span class="area-quick-btn" data-area="${escapeHTML(area)}" style="background:#fff;border:1.5px solid #c5cbe0;padding:8px 14px;border-radius:16px;font-size:0.78rem;color:#4a4a6a;cursor:pointer;font-weight:550;">${escapeHTML(area)} <span style="color:#8b8ba8;font-size:0.68rem;">(${count}家)</span></span>`;
                });
                html += `</div></div>`;
                html += `<div style="margin-top:12px;text-align:center;"><span class="area-quick-btn" data-area="__ALL__" style="display:inline-block;background:#e8e8f0;border:1.5px solid #b0b0b0;padding:8px 20px;border-radius:16px;font-size:0.78rem;color:#5c5c78;cursor:pointer;font-weight:550;">🌐 全部片区</span></div>`;
                openGuideView('🗺️ 片区快速选择', '请选择要分析的片区', html, '');
                // 固定弹窗大小：统一为固定宽度，避免内容多少导致大小不一致
                setTimeout(() => {
                    const card = document.querySelector('.guide-card');
                    if (card) {
                        card.style.width = '560px';
                        card.style.minWidth = '560px';
                        card.style.maxWidth = '640px';
                    }
                    // 左上角导出按钮（与关闭按钮齐平）
                    const existBtn = document.getElementById('areaQuickExportBtn');
                    if (existBtn) existBtn.remove();
                    const exportBtn = document.createElement('button');
                    exportBtn.id = 'areaQuickExportBtn';
                    exportBtn.title = '导出片区门店表';
                    exportBtn.style.cssText = 'position:absolute;top:10px;left:14px;width:30px;height:30px;border-radius:50%;background:transparent;font-size:1.05rem;cursor:pointer;color:#999;border:none;display:flex;align-items:center;justify-content:center;';
                    exportBtn.textContent = '📥';
                    exportBtn.addEventListener('mouseenter', () => { exportBtn.style.background = '#f0f0f5'; exportBtn.style.color = '#555'; });
                    exportBtn.addEventListener('mouseleave', () => { exportBtn.style.background = 'transparent'; exportBtn.style.color = '#999'; });
                    exportBtn.addEventListener('click', exportAreaStoreMap);
                    const card2 = document.querySelector('.guide-card');
                    if (card2) card2.appendChild(exportBtn);
                }, 0);
                // 绑定点击事件
                document.querySelectorAll('.area-quick-btn').forEach(el => {
                    el.addEventListener('click', function() {
                        const area = this.dataset.area;
                        if (area === '__ALL__') {
                            selectedArea = null;
                        } else {
                            selectedArea = area;
                        }
                        selectedStore = null;
                        guideOverlay.style.display = 'none';
                        initializeMainUI();
                        if (area === '__ALL__') {
                            toast('🌐 已选择：全部片区');
                        } else {
                            toast(`🗺️ 已选择片区：${area}`);
                        }
                    });
                });
            }

            // 处理单个文件的解析逻辑
            async function parseSingleFile(file, fileIndex, totalFiles, progressWrap, progressFill, progressText) {
                const basePct = Math.round((fileIndex / totalFiles) * 90);
                const rangePct = Math.round(90 / totalFiles);

                if (progressText) progressText.textContent = '正在解析第' + (fileIndex + 1) + '/' + totalFiles + '个文件: ' + file.name + '...';
                if (progressFill) progressFill.style.width = (basePct + 5) + '%';

                return new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = async function(e) {
                        try {
                            if (progressFill) progressFill.style.width = (basePct + rangePct * 0.2) + '%';

                            const wb = XLSX.read(new Uint8Array(e.target.result), { type:'array' });
                            const targetSheets = wb.SheetNames.filter(s => !shouldIgnore(s));
                            const mainSheetName = findSheet(targetSheets, TARGET_SHEET_KEYWORDS);
                            const badReviewSheetName = findSheet(targetSheets, BAD_REVIEW_KEYWORDS);
                            if (!mainSheetName) {
                                toast('❌ 未在「' + file.name + '」中找到「问单明细」工作簿，已跳过');
                                resolve(null);
                                return;
                            }

                            if (progressFill) progressFill.style.width = (basePct + rangePct * 0.4) + '%';

                            // 解析数据展示工作簿（多文件时累积类目，不重置）
                            const isAccumulate = totalFiles > 1 && fileIndex > 0;
                            parseDataDisplaySheet(wb, isAccumulate);

                            // 保存当前文件的达成数据快照（用于多文件合并）
                            const snapshotDate = getExportDateStrFromWb(wb);
                            dailyAchievementSnapshots.push({
                                date: snapshotDate,
                                fileName: file.name,
                                storeAchievements: JSON.parse(JSON.stringify(storeAchievements))
                            });

                            if (progressFill) progressFill.style.width = (basePct + rangePct * 0.5) + '%';

                            const rows = XLSX.utils.sheet_to_json(wb.Sheets[mainSheetName], { defval:'', raw:false });
                            if (!rows.length) {
                                toast('⚠️ 「' + file.name + '」工作簿为空，已跳过');
                                resolve(null);
                                return;
                            }

                            // 处理问单明细数据
                            const fileAllData = [];
                            const batchSize = 5000;
                            for (let i = 0; i < rows.length; i += batchSize) {
                                const batch = rows.slice(i, i + batchSize);
                                batch.forEach(r => {
                                    const nr = {};
                                    for (let k in r) nr[k.trim()] = r[k];
                                    nr._rowId = rowIdCounter++;
                                    nr._sourceFile = file.name;
                                    fileAllData.push(nr);
                                    manualDataMap.set(nr._rowId, { responsible:'仓责', reason:'' });
                                });
                                const pct = basePct + rangePct * 0.5 + Math.round(((i + batch.length) / rows.length) * rangePct * 0.3);
                                if (progressFill) progressFill.style.width = pct + '%';
                                await new Promise(r => setTimeout(r, 0));
                            }

                            // 处理冷链数据
                            const fileColdThaw = fileAllData.filter(r => (getColValue(r,'问题原因名称')||'').trim() === '冷链商品化冻');
                            fileColdThaw.forEach(r => coldThawManualMap.set(r._rowId, { isThawIssue:'是', deliveryStandard:'规范', verifyReason:'' }));

                            // 处理物流损数据
                            const fileLogistics = fileAllData.filter(r => (getColValue(r,'问题原因名称')||'').trim() === '物流损');

                            // 处理差评数据
                            let fileBadReview = [];
                            if (badReviewSheetName) {
                                const brRows = XLSX.utils.sheet_to_json(wb.Sheets[badReviewSheetName], { defval:'', raw:false });
                                brRows.forEach(r => {
                                    const nr = {};
                                    for (let k in r) nr[k.trim()] = r[k];
                                    nr._rowId = rowIdCounter++;
                                    nr._sourceFile = file.name;
                                    fileBadReview.push(nr);
                                    badReviewManualMap.set(nr._rowId, { responsible:'无责', verify:'' });
                                });
                            }

                            if (progressFill) progressFill.style.width = (basePct + rangePct * 0.95) + '%';

                            resolve({
                                allData: fileAllData,
                                coldThawData: fileColdThaw,
                                logisticsData: fileLogistics,
                                badReviewData: fileBadReview,
                                fileName: file.name
                            });
                        } catch(err) {
                            console.error('解析文件失败:', file.name, err);
                            toast('❌ 解析「' + file.name + '」失败，已跳过');
                            resolve(null);
                        }
                    };
                    reader.onerror = () => { toast('❌ 读取「' + file.name + '」失败'); resolve(null); };
                    reader.readAsArrayBuffer(file);
                });
            }

            // 从工作簿中提取日期
            function getExportDateStrFromWb(wb) {
                const targetSheets = wb.SheetNames.filter(s => !shouldIgnore(s));
                const mainSheetName = findSheet(targetSheets, TARGET_SHEET_KEYWORDS);
                if (!mainSheetName) return '--';
                const rows = XLSX.utils.sheet_to_json(wb.Sheets[mainSheetName], { defval:'', raw:false });
                if (rows.length) {
                    for (const row of rows) {
                        const d = getColValue(row, '日期');
                        if (d) return String(d).trim();
                    }
                }
                return '--';
            }

            async function handleFileUpload(fileOrFiles) {
                // 支持单文件或多文件
                let files = [];
                if (fileOrFiles instanceof FileList || Array.isArray(fileOrFiles)) {
                    files = Array.from(fileOrFiles);
                } else if (fileOrFiles instanceof File) {
                    files = [fileOrFiles];
                }
                if (!files.length) return;

                const totalFiles = files.length;
                isMultiFile = totalFiles > 1;
                uploadedFileCount = totalFiles;

                // 重置状态
                allData = []; manualDataMap.clear();
                coldThawData = []; coldThawManualMap.clear();
                logisticsData = [];
                badReviewData = []; badReviewManualMap.clear();
                dailyAchievementSnapshots = [];
                mergedStoreAchievements = {};
                rowIdCounter = 0;

                // 显示进度条
                const progressWrap = document.getElementById('guideProgressWrap') || document.getElementById('initProgressWrap');
                const progressFill = document.getElementById('guideProgressFill') || document.getElementById('initProgressFill');
                const progressText = document.getElementById('guideProgressText') || document.getElementById('initProgressText');
                if (progressWrap) { progressWrap.style.display = 'block'; }
                if (progressFill) { progressFill.style.width = '2%'; }
                if (progressText) progressText.textContent = '正在读取' + (totalFiles > 1 ? totalFiles + '个' : '') + '文件...';

                toast('⏳ 正在解析' + (totalFiles > 1 ? totalFiles + '个文件...' : '文件...'));

                let successCount = 0;
                for (let i = 0; i < files.length; i++) {
                    const result = await parseSingleFile(files[i], i, totalFiles, progressWrap, progressFill, progressText);
                    if (result) {
                        allData = allData.concat(result.allData);
                        coldThawData = coldThawData.concat(result.coldThawData);
                        logisticsData = logisticsData.concat(result.logisticsData);
                        badReviewData = badReviewData.concat(result.badReviewData);
                        successCount++;
                    }
                }

                if (progressFill) progressFill.style.width = '92%';
                if (progressText) progressText.textContent = '正在合并数据...';

                // 多文件时合并达成数据
                if (isMultiFile && dailyAchievementSnapshots.length > 0) {
                    mergeAllAchievements();
                }

                if (progressFill) progressFill.style.width = '95%';
                if (progressText) progressText.textContent = '正在初始化界面...';

                allStores = [...new Set(allData.map(r => String(getColValue(r,'门店名称')).trim()).filter(Boolean))].sort();
                selectedReasons.clear();

                if (progressFill) progressFill.style.width = '100%';
                if (progressText) progressText.textContent = '加载完成！';

                if (successCount === 0) {
                    toast('❌ 所有文件解析失败');
                    if (progressWrap) progressWrap.style.display = 'none';
                    return;
                }

                const fileLabel = totalFiles > 1 ? successCount + '个文件' : '文件';
                toast('✅ 成功加载 ' + allData.length + ' 条记录（' + fileLabel + '）');

                // 短暂延迟后隐藏进度条并弹出门店选择
                setTimeout(() => {
                    if (progressWrap) progressWrap.style.display = 'none';
                    showAreaQuickSelect();
                }, 400);
            }

            function initializeMainUI() {
                currentView = 'default';
                viewCurrentPages = { default:1, badReview:1, coldThaw:1, logistics:1 };
                duplicateBatchSet.clear();
                // 确保分析页面隐藏，主页面显示
                isAnalysisPageVisible = false;
                $('#mainPage').classList.remove('hidden');
                $('#analysisPage').classList.remove('show');
                updateBubbles();
                applyFilters();
                ['filterBar','tableWrapper','statsPanel'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.style.display = 'flex';
                });
                // 片区模式下达成面板依旧显示（多门店紧凑布局由renderAchievementPanel处理）
                const achPanel = document.getElementById('achievementPanel');
                if (achPanel) achPanel.style.display = 'block';
                updateViewBubblesVisibility();
                updateViewBubbleActiveState();
                updateCurrentStoreLabel();
                updateDataSourceText();
                renderAchievementPanel();
            }

            // 获取日期范围字符串（YYYYMMDD格式），返回 {range: '20260601-20260611', single: false}
            function getDateRangeInfo() {
                if (!allData.length) return { range: '', single: true };
                const dateSet = new Set();
                for (const row of allData) {
                    const d = getColValue(row,'日期');
                    if (d) {
                        const trimmed = String(d).trim().replace(/-/g, '').replace(/\//g, '');
                        if (trimmed) dateSet.add(trimmed);
                    }
                }
                if (dateSet.size === 0) return { range: '', single: true };
                const sortedDates = [...dateSet].sort();
                if (sortedDates.length === 1) {
                    return { range: sortedDates[0], single: true };
                }
                return { range: sortedDates[0] + '-' + sortedDates[sortedDates.length - 1], single: false };
            }

            function updateDataSourceText() {
                const el = $('#dataSourceText');
                const info = getDateRangeInfo();
                if (!info.range) { el.textContent = '统计时间：--'; el.onclick = null; return; }
                const fileLabel = isMultiFile ? '（' + uploadedFileCount + '个文件合并）' : '';
                el.textContent = '统计时间：' + info.range + fileLabel;
                // 多文件模式下点击显示文件列表（隐性功能，无UI提示）
                if (isMultiFile && dailyAchievementSnapshots.length > 0) {
                    el.onclick = function(e) {
                        e.stopPropagation();
                        // 按文件名中的日期排序升序（如"物流问单6月4号"提取6月4日）
                        const sorted = [...dailyAchievementSnapshots].sort((a, b) => {
                            const getDate = (name) => {
                                const m = String(name).match(/(\d{1,2})月(\d{1,2})[号日]/);
                                if (!m) return Infinity;
                                return parseInt(m[1]) * 100 + parseInt(m[2]);
                            };
                            return getDate(a.fileName) - getDate(b.fileName);
                        });
                        const list = sorted.map((s, i) => (i + 1) + '. ' + (s.fileName || '未知文件')).join('\n');
                        showDetailPopup(el, '<div style="white-space:pre-wrap;font-size:0.78rem;line-height:1.6;">' + escapeHTML(list) + '</div>');
                    };
                } else {
                    el.onclick = null;
                }
            }

            // ==========================================
            // 可搜索下拉组件辅助函数
            // ==========================================
            function buildFilterPanel(panelId, items, currentValue, allLabel) {
                const panel = $('#' + panelId);
                let html = '<div class="filter-option all-option' + (currentValue === '__all__' ? ' active' : '') + '" data-value="__all__">' + escapeHTML(allLabel) + '</div>';
                items.forEach(item => {
                    const activeClass = item.value === currentValue ? ' active' : '';
                    html += '<div class="filter-option' + activeClass + '" data-value="' + escapeAttr(item.value) + '">' + escapeHTML(item.text) + '</div>';
                });
                panel.innerHTML = html;
                return panel;
            }

            function filterPanelOptions(panelId, keyword) {
                const panel = $('#' + panelId);
                if (!panel) return;
                const kw = keyword.trim().toLowerCase();
                panel.querySelectorAll('.filter-option').forEach(opt => {
                    // "全部"选项与当前选中项始终可见
                    if (opt.dataset.value === '__all__' || opt.classList.contains('active')) { opt.style.display = ''; return; }
                    opt.style.display = (!kw || opt.textContent.toLowerCase().includes(kw)) ? '' : 'none';
                });
            }

            // 全局：点击外部关闭所有下拉面板
            document.addEventListener('click', function(e) {
                document.querySelectorAll('.filter-options-panel').forEach(p => {
                    if (!p.contains(e.target) && !e.target.closest('.filter-searchable')) {
                        p.style.display = 'none';
                    }
                });
            });

            // ==========================================
            // 更新筛选下拉选项
            // ==========================================
            function updateFilterDropdowns() {
                const reasonGroup = $('#reasonFilterGroup');
                const storeGroup = $('#storeFilterGroup');
                const tagGroup = $('#reviewTagFilterGroup');

                // 根据视图控制筛选组显示
                if (currentView === 'default') {
                    reasonGroup.style.display = '';
                    storeGroup.style.display = '';
                    tagGroup.style.display = 'none';
                } else if (currentView === 'logistics' || currentView === 'coldThaw') {
                    reasonGroup.style.display = '';
                    storeGroup.style.display = '';
                    tagGroup.style.display = 'none';
                } else if (currentView === 'badReview') {
                    reasonGroup.style.display = 'none';
                    storeGroup.style.display = '';
                    tagGroup.style.display = '';
                } else {
                    reasonGroup.style.display = 'none';
                    storeGroup.style.display = 'none';
                    tagGroup.style.display = 'none';
                }

                // 准备数据源（门店下拉用统一数据源allData，冷链/物流损是问单的一部分）
                let dataSource;
                if (currentView === 'default' || currentView === 'coldThaw' || currentView === 'logistics') {
                    // 三视图统一用allData统计门店数量（含冷链商品化冻和物流损）
                    dataSource = allData;
                } else if (currentView === 'badReview') {
                    dataSource = badReviewData;
                } else {
                    dataSource = [];
                }
                const storeCol = currentView === 'badReview' ? '门店' : '门店名称';
                let displayStores = selectedStore ? [selectedStore] : (selectedArea ? getAreaStores(selectedArea) : getAllAreaStores());
                const storeSet = new Set(displayStores);

                // ---- 更新门店可搜索下拉 ----
                const storeInput = $('#storeFilterInput');
                let storeCounts = new Map();
                dataSource.forEach(r => {
                    const sn = String(getColValue(r, storeCol) || '').trim();
                    if (storeSet.has(sn)) storeCounts.set(sn, (storeCounts.get(sn) || 0) + 1);
                });
                const totalItems = [...storeCounts.values()].reduce((a,b) => a+b, 0);

                // 红绿灯：不达标🔴、达标有差评🟡、达标🟢
                const currentAchData = getCurrentAchievements();
                const firstCatKey = achievementCategories[0];
                // 统计各门店差评条数
                const storeBadReviewCount = new Map();
                badReviewData.forEach(r => {
                    const sn = String(getColValue(r, '门店') || '').trim();
                    if (sn) storeBadReviewCount.set(sn, (storeBadReviewCount.get(sn) || 0) + 1);
                });
                const getStoreLight = (sn) => {
                    if (!firstCatKey || !currentAchData[sn]) return '🟢';
                    const sd = currentAchData[sn];
                    const val = sd.achievements[firstCatKey] || 0;
                    const isQzc = sn.includes('前置仓');
                    const lim = isQzc ? (qianzhicangLimits[firstCatKey] || 0) : (shengxianLimits[firstCatKey] || 0);
                    if (lim > 0 && val > lim) return '🔴'; // 不达标
                    if ((storeBadReviewCount.get(sn) || 0) > 0) return '🟡'; // 达标有差评
                    return '🟢'; // 达标
                };

                // 排序规则：1.生鲜店不达标 2.前置仓不达标 3.生鲜店差评 4.前置仓差评 5.生鲜店达标 6.前置仓达标 → 问单数量降序
                const lightOrder = { '🔴': 0, '🟡': 1, '🟢': 2 };
                const sortedStores = [...storeCounts.keys()].sort((a, b) => {
                    const la = lightOrder[getStoreLight(a)];
                    const lb = lightOrder[getStoreLight(b)];
                    if (la !== lb) return la - lb;
                    const ta = a.includes('前置仓') ? 1 : 0;
                    const tb = b.includes('前置仓') ? 1 : 0;
                    if (ta !== tb) return ta - tb;
                    return (storeCounts.get(b)||0) - (storeCounts.get(a)||0);
                });

                const storeItems = sortedStores.map(sn => {
                    const cnt = storeCounts.get(sn);
                    const pct = totalItems > 0 ? ((cnt / totalItems) * 100).toFixed(1) : '0.0';
                    const light = getStoreLight(sn);
                    return { value: sn, text: light + ' ' + sn + ' (' + cnt + '条｜' + pct + '%)' };
                });
                // 如果当前选中的门店不在列表中，重置
                if (filterStoreName !== '__all__' && !storeCounts.has(filterStoreName)) {
                    filterStoreName = '__all__';
                }
                storeInput.value = '';
                storeInput.placeholder = filterStoreName === '__all__' ? '🏪 门店筛选' : (getStoreLight(filterStoreName) + ' ' + filterStoreName);
                buildFilterPanel('storeFilterOptions', storeItems, filterStoreName, '全部门店');

                // ---- 更新问题原因可搜索下拉（问单/冷链/物流损视图统一） ----
                const reasonInput = $('#reasonFilterInput');
                if (currentView === 'default' || currentView === 'coldThaw' || currentView === 'logistics') {
                    let reasonCounts = new Map();
                    // 统一用allData统计原因（含冷链商品化冻和物流损），过片区/门店筛选
                    let filtered = allData;
                    // 过片区筛选（与门店下拉逻辑一致）
                    if (selectedStore) {
                        filtered = filtered.filter(r => String(getColValue(r, '门店名称')).trim() === selectedStore);
                    } else if (selectedArea) {
                        const areaStoreSet = new Set(getAreaStores(selectedArea));
                        filtered = filtered.filter(r => areaStoreSet.has(String(getColValue(r, '门店名称')).trim()));
                    }
                    // 过下拉门店筛选
                    if (filterStoreName !== '__all__') filtered = filtered.filter(r => String(getColValue(r, '门店名称')).trim() === filterStoreName);
                    filtered.forEach(r => {
                        const k = (getColValue(r,'问题原因名称')||'').trim();
                        if (k) reasonCounts.set(k, (reasonCounts.get(k)||0)+1);
                    });
                    const sortedReasons = [...reasonCounts.keys()].sort((a,b) => (reasonCounts.get(b)||0) - (reasonCounts.get(a)||0));
                    const totalReasons = [...reasonCounts.values()].reduce((a,b) => a+b, 0);
                    const reasonItems = sortedReasons.map(r => {
                        const cnt = reasonCounts.get(r);
                        const pct = totalReasons > 0 ? ((cnt / totalReasons) * 100).toFixed(1) : '0.0';
                        return { value: r, text: r + ' (' + cnt + '条｜' + pct + '%)' };
                    });
                    if (filterReasonName !== '__all__' && filterReasonName !== '冷链商品化冻' && filterReasonName !== '物流损' && !reasonCounts.has(filterReasonName)) {
                        filterReasonName = '__all__';
                    }
                    reasonInput.value = '';
                    reasonInput.placeholder = filterReasonName === '__all__' ? '🔍 问题原因' : filterReasonName;
                    buildFilterPanel('reasonFilterOptions', reasonItems, filterReasonName, '全部原因');
                }

                // ---- 更新评价标签可搜索下拉（仅差评视图） ----
                const tagInput = $('#reviewTagFilterInput');
                if (currentView === 'badReview') {
                    let tagCounts = new Map();
                    let filtered = dataSource;
                    if (filterStoreName !== '__all__') filtered = filtered.filter(r => String(getColValue(r, storeCol)).trim() === filterStoreName);
                    filtered.forEach(r => {
                        const tags = String(getColValue(r, '评价标签') || '').trim();
                        if (tags && tags !== '-') {
                            tags.split(/[,，、]/).map(t => t.trim()).filter(Boolean).forEach(t => {
                                tagCounts.set(t, (tagCounts.get(t)||0)+1);
                            });
                        }
                    });
                    const sortedTags = [...tagCounts.keys()].sort((a,b) => (tagCounts.get(b)||0) - (tagCounts.get(a)||0));
                    const tagItems = sortedTags.map(t => {
                        return { value: t, text: t + ' (' + tagCounts.get(t) + '条)' };
                    });
                    if (filterReviewTag !== '__all__' && !tagCounts.has(filterReviewTag)) {
                        filterReviewTag = '__all__';
                    }
                    tagInput.value = '';
                    tagInput.placeholder = filterReviewTag === '__all__' ? '🏷️ 评价标签' : filterReviewTag;
                    buildFilterPanel('reviewTagFilterOptions', tagItems, filterReviewTag, '全部标签');
                }

                // 清空筛选按钮：任意下拉有选中时显示
                const clearBtn = $('#filterClearBtn');
                if (clearBtn) {
                    const hasFilter = filterStoreName !== '__all__' || filterReasonName !== '__all__' || filterReviewTag !== '__all__';
                    clearBtn.style.display = hasFilter ? '' : 'none';
                }
            }

            // HTML属性转义
            function escapeAttr(s) {
                return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            }

            // 辅助：更新清空筛选按钮显示状态
            function updateClearBtn() {
                const clearBtn = $('#filterClearBtn');
                if (clearBtn) {
                    const hasFilter = filterStoreName !== '__all__' || filterReasonName !== '__all__' || filterReviewTag !== '__all__';
                    clearBtn.style.display = hasFilter ? '' : 'none';
                }
            }

            // 下拉筛选事件绑定
            function bindFilterDropdownEvents() {
                let searchTimer = null;
                function debouncedFilter(panelId, keyword) {
                    if (searchTimer) clearTimeout(searchTimer);
                    searchTimer = setTimeout(() => filterPanelOptions(panelId, keyword), 120);
                }

                // 门店可搜索下拉
                const storeInput = $('#storeFilterInput');
                const storePanel = $('#storeFilterOptions');
                storeInput.addEventListener('focus', function() { storePanel.style.display = 'block'; });
                storeInput.addEventListener('input', function() { debouncedFilter('storeFilterOptions', this.value); });
                storePanel.addEventListener('click', function(e) {
                    const opt = e.target.closest('.filter-option');
                    if (!opt) return;
                    const val = opt.dataset.value;
                    filterStoreName = val;
                    storeInput.value = '';
                    storeInput.placeholder = val === '__all__' ? '🏪 门店筛选' : val;
                    storePanel.style.display = 'none';
                    setCurrentPage(1);
                    // 轻量切换 active 高亮
                    storePanel.querySelectorAll('.filter-option').forEach(o => o.classList.remove('active'));
                    opt.classList.add('active');
                    updateFilterDropdowns();
                    updateViewBubblesVisibility();
                    applyFilters();
                });

                // 问题原因可搜索下拉
                const reasonInput = $('#reasonFilterInput');
                const reasonPanel = $('#reasonFilterOptions');
                reasonInput.addEventListener('focus', function() { reasonPanel.style.display = 'block'; });
                reasonInput.addEventListener('input', function() { debouncedFilter('reasonFilterOptions', this.value); });
                reasonPanel.addEventListener('click', function(e) {
                    const opt = e.target.closest('.filter-option');
                    if (!opt) return;
                    const val = opt.dataset.value;
                    filterReasonName = val;
                    reasonInput.value = '';
                    reasonInput.placeholder = val === '__all__' ? '🔍 问题原因' : val;
                    reasonPanel.style.display = 'none';
                    setCurrentPage(1);
                    // 轻量切换 active 高亮
                    reasonPanel.querySelectorAll('.filter-option').forEach(o => o.classList.remove('active'));
                    opt.classList.add('active');
                    updateClearBtn();
                    // 冷链商品化冻 → 自动跳转冷链化冻视图
                    if (val === '冷链商品化冻') { switchView('coldThaw'); return; }
                    // 物流损 → 自动跳转物流损视图
                    if (val === '物流损') { switchView('logistics'); return; }
                    // 全部原因或普通原因：若在冷链/物流损视图，跳回问单视图
                    if (currentView === 'coldThaw' || currentView === 'logistics') { switchView('default'); return; }
                    applyFilters();
                });

                // 评价标签可搜索下拉
                const tagInput = $('#reviewTagFilterInput');
                const tagPanel = $('#reviewTagFilterOptions');
                tagInput.addEventListener('focus', function() { tagPanel.style.display = 'block'; });
                tagInput.addEventListener('input', function() { debouncedFilter('reviewTagFilterOptions', this.value); });
                tagPanel.addEventListener('click', function(e) {
                    const opt = e.target.closest('.filter-option');
                    if (!opt) return;
                    const val = opt.dataset.value;
                    filterReviewTag = val;
                    tagInput.value = '';
                    tagInput.placeholder = val === '__all__' ? '🏷️ 评价标签' : val;
                    tagPanel.style.display = 'none';
                    // 轻量切换 active 高亮
                    tagPanel.querySelectorAll('.filter-option').forEach(o => o.classList.remove('active'));
                    opt.classList.add('active');
                    setCurrentPage(1);
                    updateClearBtn();
                    applyFilters();
                });

                // 清空筛选按钮：清空所有下拉并返回问单视图
                $('#filterClearBtn').addEventListener('click', function() {
                    filterStoreName = '__all__';
                    filterReasonName = '__all__';
                    filterReviewTag = '__all__';
                    setCurrentPage(1);
                    if (currentView !== 'default') { switchView('default'); return; }
                    updateFilterDropdowns();
                    updateViewBubblesVisibility();
                    applyFilters();
                });
            }

            function updateBubbles() {
                // v18: 改为下拉菜单，保留函数兼容
                updateFilterDropdowns();
            }

            function applyFilters() {
                let data;
                if (currentView === 'default') {
                    data = [...allData];
                } else if (currentView === 'badReview') {
                    data = [...badReviewData];
                } else if (currentView === 'logistics') {
                    data = [...logisticsData];
                } else {
                    data = [...coldThawData];
                }

                const storeCol = currentView === 'badReview' ? '门店' : '门店名称';

                // 片区筛选：获取当前片区对应的门店集合
                let areaStoreSet = null;
                if (selectedArea) {
                    const areaStores = getAreaStores(selectedArea);
                    areaStoreSet = new Set(areaStores);
                }

                // 门店筛选：优先单门店，其次片区
                if (selectedStore) {
                    data = data.filter(r => String(getColValue(r, storeCol)).trim() === selectedStore);
                } else if (areaStoreSet) {
                    data = data.filter(r => areaStoreSet.has(String(getColValue(r, storeCol)).trim()));
                }

                // 下拉门店二次筛选（凌驾于问题原因之上）
                if (filterStoreName !== '__all__') {
                    data = data.filter(r => String(getColValue(r, storeCol)).trim() === filterStoreName);
                }

                if (currentView === 'default') {
                    // 问单视图：排除冷链商品化冻和物流损
                    data = data.filter(r => {
                        const reason = (getColValue(r,'问题原因名称')||'').trim();
                        return reason !== '冷链商品化冻' && reason !== '物流损';
                    });
                    // 下拉问题原因筛选（冷链商品化冻/物流损触发视图切换，不在问单视图筛选）
                    if (filterReasonName !== '__all__' && filterReasonName !== '冷链商品化冻' && filterReasonName !== '物流损') {
                        data = data.filter(r => (getColValue(r,'问题原因名称')||'').trim() === filterReasonName);
                    }
                }

                // 差评视图：评价标签筛选
                if (currentView === 'badReview' && filterReviewTag !== '__all__') {
                    data = data.filter(r => {
                        const tags = String(getColValue(r, '评价标签') || '').trim();
                        if (!tags || tags === '-') return false;
                        return tags.split(/[,，、]/).map(t => t.trim()).filter(Boolean).includes(filterReviewTag);
                    });
                }

                // ==========================================
                // v18 排序规则
                // ==========================================
                // 预计算各门店/原因条目数，用于排序
                const storeCountMap = new Map();
                data.forEach(r => {
                    const sn = String(getColValue(r, storeCol) || '').trim();
                    storeCountMap.set(sn, (storeCountMap.get(sn)||0)+1);
                });

                if (currentView === 'default' || currentView === 'logistics' || currentView === 'coldThaw') {
                    // 问单排序：1.门店（条目数量降序）→ 2.批次号（条目数量降序）
                    // 预计算各门店下各批次号条目数
                    const storeBatchCountMap = new Map();
                    data.forEach(r => {
                        const sn = String(getColValue(r, storeCol) || '').trim();
                        const batch = (getColValue(r, '批次号') || getColValue(r, '淘系主订单id') || '').trim();
                        const key = sn + '||' + batch;
                        storeBatchCountMap.set(key, (storeBatchCountMap.get(key)||0)+1);
                    });

                    data.sort((a, b) => {
                        // 1. 门店条目数量降序
                        const aSN = String(getColValue(a, storeCol) || '').trim();
                        const bSN = String(getColValue(b, storeCol) || '').trim();
                        const aSC = storeCountMap.get(aSN) || 0;
                        const bSC = storeCountMap.get(bSN) || 0;
                        if (aSC !== bSC) return bSC - aSC;
                        // 同门店数量不同名：按名称稳定排序
                        if (aSN !== bSN) return aSN.localeCompare(bSN, 'zh-CN');

                        // 2. 批次号（条目数量降序）
                        const aBatch = (getColValue(a, '批次号') || getColValue(a, '淘系主订单id') || '').trim();
                        const bBatch = (getColValue(b, '批次号') || getColValue(b, '淘系主订单id') || '').trim();
                        const aBC = storeBatchCountMap.get(aSN + '||' + aBatch) || 0;
                        const bBC = storeBatchCountMap.get(bSN + '||' + bBatch) || 0;
                        if (aBC !== bBC) return bBC - aBC;
                        if (aBatch !== bBatch) return aBatch.localeCompare(bBatch, 'zh-CN');

                        return 0;
                    });
                } else if (currentView === 'badReview') {
                    // 差评排序：1.门店（条目数量降序）→ 2.评价日期（升序）
                    data.sort((a, b) => {
                        const aSN = String(getColValue(a, '门店') || '').trim();
                        const bSN = String(getColValue(b, '门店') || '').trim();
                        const aSC = storeCountMap.get(aSN) || 0;
                        const bSC = storeCountMap.get(bSN) || 0;
                        if (aSC !== bSC) return bSC - aSC;
                        if (aSN !== bSN) return aSN.localeCompare(bSN, 'zh-CN');

                        // 评价日期升序
                        const aDate = String(getColValue(a, '评价日期') || getColValue(a, '交易日期') || '').trim();
                        const bDate = String(getColValue(b, '评价日期') || getColValue(b, '交易日期') || '').trim();
                        return aDate.localeCompare(bDate);
                    });
                }

                if (currentView === 'default') filteredData = data;
                else if (currentView === 'badReview') filteredBadReviewData = data;
                else if (currentView === 'logistics') filteredLogisticsData = data;
                else filteredColdThawData = data;

                const cfd = currentView === 'default' ? filteredData : (currentView === 'badReview' ? filteredBadReviewData : (currentView === 'logistics' ? filteredLogisticsData : filteredColdThawData));
                const totalPages = Math.ceil(cfd.length / pageSize) || 1;
                if (getCurrentPage() > totalPages) setCurrentPage(totalPages);
                renderTable();
            }

            function getCurrentPage() { return viewCurrentPages[currentView] || 1; }
            function setCurrentPage(p) { viewCurrentPages[currentView] = p; }

            function updateCurrentStoreLabel() {
                const el = $('#currentStoreName');
                if (selectedArea) {
                    const storeCount = getAreaStores(selectedArea).length;
                    el.innerHTML = `🗺️ 统计片区：${escapeHTML(selectedArea)}<span class="store-type-tag" style="background:#e0f2fe;color:#0369a1;">${storeCount}家门店</span>`;
                    return;
                }
                if (!selectedStore) {
                    el.textContent = '📍 统计片区：全部片区';
                    return;
                }
                
                const storeType = getStoreType(selectedStore);
                const typeLabel = getStoreTypeLabel(storeType);
                const typeClass = getStoreTypeClass(storeType);
                
                // 单行结构：📍 当前门店：店名 [类型标签]
                el.innerHTML = `📍 当前门店：${escapeHTML(selectedStore)}<span class="store-type-tag ${typeClass}">${typeLabel}</span>`;
            }

            function renderTable() {
                const cfd = currentView === 'default' ? filteredData : (currentView === 'badReview' ? filteredBadReviewData : (currentView === 'logistics' ? filteredLogisticsData : filteredColdThawData));
                const start = (getCurrentPage()-1) * pageSize, end = Math.min(start + pageSize, cfd.length);
                const pageData = cfd.slice(start, end);
                const thead = $('#tableHead'), tbody = $('#tableBody');

                if (currentView === 'default' || currentView === 'logistics')
                    thead.innerHTML = '<tr><th style="width:15%">门店</th><th style="width:15%">问题原因名称</th><th style="width:15%">SKU名称</th><th style="width:10%">APP退款原因</th><th style="width:20%">APP退款描述</th><th style="width:15%">退款凭证</th><th style="width:5%">单号</th><th style="width:5%">责任人</th></tr>';
                else if (currentView === 'badReview')
                    thead.innerHTML = '<tr><th style="width:10%">评价日期</th><th style="width:15%">门店</th><th style="width:10%">配送员名称</th><th style="width:5%">单号</th><th style="width:25%">评价文本</th><th style="width:15%">评价标签</th><th style="width:15%">评价星级</th></tr>';
                else
                    thead.innerHTML = '<tr><th style="width:15%">门店</th><th style="width:10%">问题原因名称</th><th style="width:15%">SKU名称</th><th style="width:10%">APP退款原因</th><th style="width:20%">APP退款描述</th><th style="width:5%">时间戳</th><th style="width:15%">退款凭证</th><th style="width:5%">单号</th><th style="width:5%">责任人</th></tr>';

                tbody.innerHTML = '';
                $('#emptyState').style.display = pageData.length ? 'none' : 'block';
                if (!pageData.length) { $('#paginationBar').innerHTML = ''; return; }

                // 批次分组标注：仅当某批次号在当前页重复出现时，显示「第几条/共几条」分数标注
                const hasBatch = (currentView === 'default' || currentView === 'logistics' || currentView === 'coldThaw');
                const batchTotalMap = new Map();  // 批次号 → 总条数
                const batchSeqMap = new Map();    // 批次号 → 当前序号（逐条递增）
                const batchColorMap = new Map();   // 重复批次号 → 颜色索引(0-11)
                if (hasBatch) {
                    pageData.forEach(row => {
                        const batch = (getColValue(row, '批次号') || getColValue(row, '淘系主订单id') || '').trim();
                        if (!batch) return;
                        batchTotalMap.set(batch, (batchTotalMap.get(batch) || 0) + 1);
                    });
                    // 初始化序号 + 分配颜色
                    batchTotalMap.forEach((cnt, batch) => {
                        if (cnt > 1) {
                            batchSeqMap.set(batch, 0);
                            batchColorMap.set(batch, batchColorMap.size % 12);
                        }
                    });
                }
                $('#batchLegend').style.display = 'none';

                const fragment = document.createDocumentFragment();
                pageData.forEach((row, idx) => {
                    const tr = document.createElement('tr');
                    if (idx % 2 === 1) tr.classList.add('zebra-row');
                    let batchFraction = null; // {seq, total, colorIdx} 重复批次时显示分数
                    let batchNo = '';
                    if (hasBatch) {
                        batchNo = (getColValue(row, '批次号') || getColValue(row, '淘系主订单id') || '').trim();
                        if (batchNo && batchSeqMap.has(batchNo)) {
                            batchSeqMap.set(batchNo, (batchSeqMap.get(batchNo) || 0) + 1);
                            batchFraction = { seq: batchSeqMap.get(batchNo), total: batchTotalMap.get(batchNo), colorIdx: batchColorMap.get(batchNo) };
                        }
                    }
                    if (currentView === 'default' || currentView === 'logistics') {
                        tr.appendChild(createCell(getColValue(row,'门店名称')));
                        tr.appendChild(createCell(getColValue(row,'问题原因名称')));
                        tr.appendChild(createCell(getColValue(row,'sku名称')||getColValue(row,'SKU名称')));
                        tr.appendChild(createCell(getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')));
                        tr.appendChild(createCell(getAppRefundDesc(row)));
                        tr.appendChild(createVoucherCell(row));
                        tr.appendChild(createOrderCell(row, ['淘系主订单id','批次号','配送单号'], batchFraction, batchNo));
                        tr.appendChild(createPersonCell(row));
                    } else if (currentView === 'badReview') {
                        tr.appendChild(createCell(getColValue(row,'评价日期')||getColValue(row,'交易日期')||''));
                        tr.appendChild(createCell(getColValue(row,'门店')));
                        tr.appendChild(createCell(getColValue(row,'配送员名称')));
                        tr.appendChild(createOrderCell(row, ['评价父订单','盒马主订单','外部主订单','履约单号']));
                        tr.appendChild(createCell(getColValue(row,'评价文本')));
                        tr.appendChild(createCell(getColValue(row,'评价标签')));
                        tr.appendChild(createStarCell(row));
                    } else {
                        tr.appendChild(createCell(getColValue(row,'门店名称')));
                        tr.appendChild(createCell('冷链商品化冻'));
                        tr.appendChild(createCell(getColValue(row,'sku名称')||getColValue(row,'SKU名称')));
                        tr.appendChild(createCell(getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')));
                        tr.appendChild(createCell(getAppRefundDesc(row)));
                        tr.appendChild(createTimestampCell(row));
                        tr.appendChild(createVoucherCell(row));
                        tr.appendChild(createOrderCell(row, ['淘系主订单id','批次号','配送单号'], batchFraction, batchNo));
                        tr.appendChild(createPersonCell(row));
                    }
                    fragment.appendChild(tr);
                });
                tbody.appendChild(fragment);
                renderPagination(cfd);
            }


            function createCell(text) { const td = document.createElement('td'); td.textContent = text || '-'; return td; }
            function createLimitedWidthCell(fullText) {
                const td = document.createElement('td');
                const span = document.createElement('span');
                span.className = 'cell-clickable';
                span.style.cssText = 'display:inline-block;white-space:normal;word-break:break-word;line-height:1.4;vertical-align:middle;';
                span.textContent = fullText || '-';
                span.addEventListener('click', function(e) { e.stopPropagation(); showDetailPopup(span, fullText || '-', true); });
                td.appendChild(span);
                return td;
            }
            function createClickableCell(fullText) {
                const td = document.createElement('td');
                const span = document.createElement('span'); span.className = 'cell-clickable'; span.textContent = fullText || '-';
                span.addEventListener('click', function(e) { e.stopPropagation(); showDetailPopup(span, fullText || '-', true); });
                td.appendChild(span); return td;
            }
            function createVoucherCell(row) {
                const td = document.createElement('td');
                const urls = parseImageUrls(getColValue(row,'退款凭证')||'');
                if (urls.length) {
                    const img = document.createElement('img');
                    img.src = urls[0];
                    img.style.cssText = 'width:80px;height:80px;object-fit:cover;border-radius:6px;cursor:pointer;border:1px solid #e6e8f0;';
                    img.title = '点击全屏查看' + urls.length + '张图片';
                    img.addEventListener('click', function(e) { e.stopPropagation(); openVoucherFullscreen(urls); });
                    td.appendChild(img);
                } else {
                    const btn = document.createElement('span'); btn.className='cell-view-btn no-image'; btn.textContent='无凭证'; td.appendChild(btn);
                }
                return td;
            }

            // 退款凭证全屏预览（直接全屏，带左右切换）
            function openVoucherFullscreen(urls, startIdx) {
                if (!urls || !urls.length) return;
                startIdx = Math.max(0, Math.min(startIdx || 0, urls.length - 1));
                const overlay = $('#fullscreenOverlay');
                const fsImg = $('#fullscreenImage');
                fsImg.src = urls[startIdx];
                fsImg.dataset.urls = JSON.stringify(urls);
                fsImg.dataset.idx = startIdx;
                overlay.style.display = 'flex';
                overlay.dataset.voucherMode = '1';
            }

            // 全屏图片点击切换（退款凭证模式）
            $('#fullscreenImage').addEventListener('click', function() {
                if (this.dataset.voucherMode !== '1') return;
                const urls = JSON.parse(this.dataset.urls);
                let idx = parseInt(this.dataset.idx) + 1;
                if (idx >= urls.length) idx = 0;
                this.src = urls[idx];
                this.dataset.idx = idx;
            });

            // 关闭全屏时清除退款凭证模式
            const origCloseFs = $('#btnCloseFullscreen');
            origCloseFs.addEventListener('click', () => {
                $('#fullscreenOverlay').style.display = 'none';
                $('#fullscreenOverlay').dataset.voucherMode = '';
            });
            $('#fullscreenOverlay').addEventListener('click', function(e) {
                if (e.target === this) {
                    this.style.display = 'none';
                    this.dataset.voucherMode = '';
                }
            });
            function createOrderCell(row, fields, batchFraction, batchNo) {
                const td = document.createElement('td');
                const values = fields.map(f => getColValue(row,f)||'');
                if (values.some(v => String(v).trim())) {
                    const btn = document.createElement('span'); btn.className='cell-btn';
                    // 重复批次分数标注：上下结构「第几条/共几条」，按钮边框同色
                    if (batchFraction && batchNo) {
                        btn.classList.add('batch-' + batchFraction.colorIdx);
                        const frac = document.createElement('span');
                        frac.className = 'batch-frac batch-' + batchFraction.colorIdx;
                        frac.innerHTML = '<span class="batch-frac-top">' + batchFraction.seq + '</span><span class="batch-frac-line"></span><span class="batch-frac-bot">' + batchFraction.total + '</span>';
                        btn.appendChild(frac);
                    }
                    btn.appendChild(document.createTextNode('查看'));
                    btn.addEventListener('click', e => { e.stopPropagation(); showDetailPopup(btn, fields.map((f,i) => makePopupRow(f, values[i])).join('')); });
                    td.appendChild(btn);
                } else {
                    const btn = document.createElement('span'); btn.className='cell-btn no-data'; btn.textContent='无数据'; td.appendChild(btn);
                }
                return td;
            }
            function createPersonCell(row) {
                const td = document.createElement('td');
                const delivery = String(getColValue(row,'配送员名')||'').trim();
                td.textContent = delivery && delivery !== '-' ? delivery : '-';
                return td;
            }
            function createTimeCell(row) {
                const td = document.createElement('td');
                const fields = ['批次生成时间','拣货完成时间','打包完成时间','揽收时间','最晚送达时间','签收时间'];
                const values = fields.map(f => formatTime(getColValue(row,f)||''));
                if (values.some(v => String(v).trim())) {
                    const btn = document.createElement('span'); btn.className='cell-btn'; btn.textContent='🕐 查看';
                    btn.addEventListener('click', e => { e.stopPropagation(); showDetailPopup(btn, fields.map((f,i) => makePopupRow(f, values[i]||'-')).join('')); });
                    td.appendChild(btn);
                } else {
                    const btn = document.createElement('span'); btn.className='cell-btn no-data'; btn.textContent='无数据'; td.appendChild(btn);
                }
                return td;
            }
            // 冷链视图时间戳单元格（显示6个时间节点+间隔计算）
            function createTimestampCell(row) {
                const td = document.createElement('td');
                const fields = ['批次生成时间','拣货完成时间','打包完成时间','揽收时间','签收时间','最晚送达时间'];
                const rawValues = fields.map(f => getColValue(row,f)||'');
                const formattedValues = rawValues.map(v => formatTime(v));
                if (formattedValues.some(v => String(v).trim())) {
                    const btn = document.createElement('span'); btn.className='cell-btn'; btn.textContent='🕐 查看';
                    // 计算签收时间与揽收时间的间隔，大于18分钟则按钮变红色边框
                    const qianshouTime = formattedValues[4]; // 签收时间
                    const lanshouTime = formattedValues[3]; // 揽收时间
                    if (qianshouTime && lanshouTime && qianshouTime !== '-' && lanshouTime !== '-') {
                        const qianshouDate = new Date(qianshouTime);
                        const lanshouDate = new Date(lanshouTime);
                        if (!isNaN(qianshouDate) && !isNaN(lanshouDate)) {
                            const diffMs = qianshouDate - lanshouDate;
                            const diffMins = Math.round(diffMs / 60000);
                            if (diffMins > 18) {
                                btn.style.border = '2px solid #ef4444';
                                btn.style.color = '#ef4444';
                            }
                        }
                    }
                    btn.addEventListener('click', e => {
                        e.stopPropagation();
                        showTimestampPopup(btn, fields, formattedValues);
                    });
                    td.appendChild(btn);
                } else {
                    const btn = document.createElement('span'); btn.className='cell-btn no-data'; btn.textContent='无数据'; td.appendChild(btn);
                }
                return td;
            }
            // 显示时间戳弹窗（含间隔计算）
            function showTimestampPopup(anchor, fields, values) {
                closeAllPopups();

                // 解析时间字符串为可比较的格式
                function parseTime(str) {
                    if (!str || str === '-') return null;
                    const d = new Date(str);
                    if (isNaN(d)) return null;
                    return d;
                }

                // 计算间隔时间
                // 间隔显示在当前行，表示当前行时间与上一行时间的差值
                const intervals = [];
                for (let i = 0; i < fields.length; i++) {
                    const curr = parseTime(values[i]);
                    if (!curr) {
                        intervals.push('-');
                        continue;
                    }
                    // 找到上一个有效时间
                    let prev = null;
                    for (let j = i - 1; j >= 0; j--) {
                        prev = parseTime(values[j]);
                        if (prev) break;
                    }
                    if (!prev) {
                        intervals.push('-');
                        continue;
                    }
                    const diffMs = curr - prev;
                    const diffMins = Math.round(diffMs / 60000);
                    if (diffMins >= 0) {
                        const hours = Math.floor(diffMins / 60);
                        const mins = diffMins % 60;
                        if (hours > 0) {
                            intervals.push(`${hours}时${mins}分`);
                        } else {
                            intervals.push(`${mins}分钟`);
                        }
                    } else {
                        intervals.push('-');
                    }
                }

                // 构建表格HTML（无表头，三列：时间类型、时间、间隔）
                let tableHtml = '<table class="detail-table" style="width:auto;min-width:200px;"><tbody>';
                for (let i = 0; i < fields.length; i++) {
                    tableHtml += '<tr>';
                    tableHtml += '<td style="text-align:left;font-weight:600;">' + escapeHTML(fields[i]) + '</td>';
                    tableHtml += '<td>' + escapeHTML(values[i]||'-') + '</td>';
                    tableHtml += '<td style="color:#666;">⏱️ ' + escapeHTML(intervals[i]) + '</td>';
                    tableHtml += '</tr>';
                }
                tableHtml += '</tbody></table>';
                const popup = document.createElement('div');
                popup.className = 'detail-popup';
                popup.innerHTML = tableHtml;
                document.body.appendChild(popup);
                positionPopup(anchor, popup);
                currentPopup = popup;
                bindPopupHoverClose(popup, anchor);
            }
            function formatTime(str) {
                if (!str) return '';
                const s = String(str).trim();
                if (!s || s === '-') return '-';

                // Excel序列号格式（整数部分是天数，小数部分是时间）
                // 例如 45123.5 表示 2023/7/1 12:00:00
                if (/^\d+(\.\d+)?$/.test(s)) {
                    const num = parseFloat(s);
                    // Excel日期序列号范围：1900-01-01 = 1，约 40000-60000 对应 2009-2063
                    if (num > 30000 && num < 100000) {
                        const d = new Date((num - 25569) * 86400 * 1000);
                        if (!isNaN(d)) {
                            return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')+':'+String(d.getSeconds()).padStart(2,'0');
                        }
                    }
                }

                // 标准日期时间格式：2023-07-01 12:30:45 或 2023/07/01 12:30:45
                const m = s.match(/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})[\sT](\d{1,2}):(\d{1,2}):(\d{1,2})/);
                if (m) return m[1]+'-'+m[2].padStart(2,'0')+'-'+m[3].padStart(2,'0')+' '+m[4].padStart(2,'0')+':'+m[5].padStart(2,'0')+':'+m[6].padStart(2,'0');

                // 日期+时间无分隔符格式：20230701123045
                const m2 = s.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/);
                if (m2) return m2[1]+'-'+m2[2]+'-'+m2[3]+' '+m2[4]+':'+m2[5]+':'+m2[6];

                // 仅日期格式：2023-07-01
                const m3 = s.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/);
                if (m3) return m3[1]+'-'+m3[2].padStart(2,'0')+'-'+m3[3].padStart(2,'0')+' 00:00:00';

                // 尝试用 Date 解析
                const d = new Date(s);
                if (!isNaN(d)) {
                    return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')+':'+String(d.getSeconds()).padStart(2,'0');
                }

                return s;
            }
            function createStarCell(row) {
                const td = document.createElement('td');
                const v = parseInt(getColValue(row,'评价星级'));
                if (!isNaN(v) && v > 0) td.innerHTML = '<span class="star-rating">'+'★'.repeat(v)+'☆'.repeat(5-v)+'</span>';
                else td.textContent = getColValue(row,'评价星级')||'-';
                return td;
            }
            function createSelectCell(row, key, options, map) {
                const td = document.createElement('td');
                const sel = document.createElement('select'); sel.className='cell-select';
                options.forEach(o => { const opt = document.createElement('option'); opt.value=o; opt.textContent=o; sel.appendChild(opt); });
                const saved = map.get(row._rowId) || {};
                sel.value = saved[key] || options[0];
                sel.addEventListener('change', () => { saved[key] = sel.value; map.set(row._rowId, saved); });
                td.appendChild(sel); return td;
            }
            function createInputCell(row, key, map) {
                const td = document.createElement('td');
                const inp = document.createElement('input'); inp.type='text'; inp.className='cell-input';
                const saved = map.get(row._rowId) || {};
                inp.value = saved[key] || '';
                inp.addEventListener('input', () => { saved[key] = inp.value; map.set(row._rowId, saved); });
                td.appendChild(inp); return td;
            }
            function parseImageUrls(v) {
                if (!v) return [];
                return String(v).trim()
                    .split(/[,，]+/)
                    .map(s => s.trim())
                    .filter(s => s && s.length > 3 && !['无','空','none','null'].includes(s.toLowerCase()))
                    .map(s => {
                        // 移除 ? 及其后的所有内容
                        const qIndex = s.indexOf('?');
                        return qIndex !== -1 ? s.substring(0, qIndex) : s;
                    });
            }

            function openImagePreview(urls, startIdx = 0) {
                if (!urls || !urls.length) return;
                previewUrls = [...urls]; previewIdx = Math.max(0, Math.min(startIdx, urls.length - 1));
                showPreviewImage();
                $('#previewBubble').style.display = 'block';
                setTimeout(() => document.addEventListener('click', closePreviewOnClickOutside), 50);
            }
            function closePreviewOnClickOutside(e) {
                const pb = $('#previewBubble');
                if (pb.style.display === 'none') { document.removeEventListener('click', closePreviewOnClickOutside); return; }
                if (pb.contains(e.target) || e.target.closest('.cell-view-btn')) return;
                closeImagePreview();
            }
            function closeImagePreview() {
                $('#previewBubble').style.display = 'none';
                previewUrls = [];
                document.removeEventListener('click', closePreviewOnClickOutside);
            }
            function showPreviewImage() {
                const pb = $('#previewBubble');
                pb.innerHTML = `
                    <button class="preview-close" id="previewClose">✕</button>
                    <img src="${previewUrls[previewIdx]}" alt="预览" onclick="event.stopPropagation();">
                    <div class="preview-controls">
                        <button id="prevPreview" ${previewIdx===0?'disabled':''}>◀</button>
                        <span class="preview-counter">${previewIdx+1}/${previewUrls.length}</span>
                        <button id="nextPreview" ${previewIdx>=previewUrls.length-1?'disabled':''}>▶</button>
                        <button id="openFullscreen">🖥 全屏</button>
                    </div>
                `;
                pb.style.top = '50%'; pb.style.left = '50%'; pb.style.transform = 'translate(-50%,-50%)';
                document.getElementById('previewClose').addEventListener('click', (e) => { e.stopPropagation(); closeImagePreview(); });
                document.getElementById('prevPreview').addEventListener('click', (e) => { e.stopPropagation(); if (previewIdx > 0) { previewIdx--; showPreviewImage(); } });
                document.getElementById('nextPreview').addEventListener('click', (e) => { e.stopPropagation(); if (previewIdx < previewUrls.length-1) { previewIdx++; showPreviewImage(); } });
                document.getElementById('openFullscreen').addEventListener('click', (e) => { e.stopPropagation(); openFullscreen(previewUrls[previewIdx]); });
            }
            function openFullscreen(url) { $('#fullscreenImage').src = url; $('#fullscreenOverlay').style.display = 'flex'; }
            $('#btnCloseFullscreen').addEventListener('click', () => $('#fullscreenOverlay').style.display = 'none');
            $('#fullscreenOverlay').addEventListener('click', e => { if (e.target === $('#fullscreenOverlay')) $('#fullscreenOverlay').style.display = 'none'; });

            // 分页
            function renderPagination(cfd) {
                const bar = $('#paginationBar');
                bar.innerHTML = '';
                const totalPages = Math.ceil(cfd.length / pageSize) || 1;
                if (totalPages <= 1 && cfd.length <= pageSize) {
                    if (cfd.length) bar.innerHTML = '<span class="page-info">显示全部 ' + cfd.length + ' 条</span>';
                    return;
                }
                const cp = getCurrentPage();

                const btnFirst = document.createElement('button'); btnFirst.textContent = '首页';
                btnFirst.disabled = cp === 1;
                btnFirst.addEventListener('click', () => { setCurrentPage(1); applyFilters(); });
                bar.appendChild(btnFirst);

                const btnPrev = document.createElement('button'); btnPrev.textContent = '上一页';
                btnPrev.disabled = cp === 1;
                btnPrev.addEventListener('click', () => { setCurrentPage(cp - 1); applyFilters(); });
                bar.appendChild(btnPrev);

                let sp = Math.max(1, cp - 3), ep = Math.min(totalPages, cp + 3);
                for (let p = sp; p <= ep; p++) {
                    const bp = document.createElement('button');
                    bp.textContent = p;
                    if (p === cp) bp.classList.add('active-page');
                    bp.addEventListener('click', () => { setCurrentPage(p); applyFilters(); });
                    bar.appendChild(bp);
                }

                const btnNext = document.createElement('button'); btnNext.textContent = '下一页';
                btnNext.disabled = cp >= totalPages;
                btnNext.addEventListener('click', () => { setCurrentPage(cp + 1); applyFilters(); });
                bar.appendChild(btnNext);

                const btnLast = document.createElement('button'); btnLast.textContent = '末页';
                btnLast.disabled = cp >= totalPages;
                btnLast.addEventListener('click', () => { setCurrentPage(totalPages); applyFilters(); });
                bar.appendChild(btnLast);

                const sel = document.createElement('select');
                [10, 20, 30, 50, 100].forEach(n => { const o = document.createElement('option'); o.value = n; o.textContent = '每页' + n + '条'; if (n === pageSize) o.selected = true; sel.appendChild(o); });
                sel.addEventListener('change', () => { pageSize = +sel.value; setCurrentPage(1); applyFilters(); });
                bar.appendChild(sel);

                const info = document.createElement('span'); info.className = 'page-info';
                info.textContent = '共 ' + totalPages + ' 页 / ' + cfd.length + ' 条';
                bar.appendChild(info);
            }

            function updateViewBubblesVisibility() {
                // 构建当前筛选的门店集合（优先下拉筛选，其次单门店/片区）
                let filterStoreSet = null;
                if (filterStoreName !== '__all__') {
                    filterStoreSet = new Set([filterStoreName]);
                } else if (selectedStore) {
                    filterStoreSet = new Set([selectedStore]);
                } else if (selectedArea) {
                    filterStoreSet = new Set(getAreaStores(selectedArea));
                }

                const storeFilter = (r, colName) => {
                    if (!filterStoreSet) return true;
                    return filterStoreSet.has(String(getColValue(r, colName) || '').trim());
                };

                const showBad = badReviewData.length && badReviewData.some(r => storeFilter(r, '门店'));
                $('#viewBubbleBadReview').style.display = showBad ? 'inline-flex' : 'none';
                if (showBad) $('#badReviewBadge').textContent = badReviewData.filter(r => storeFilter(r, '门店')).length;
                const showCold = coldThawData.length && coldThawData.some(r => storeFilter(r, '门店名称'));
                $('#viewBubbleColdThaw').style.display = showCold ? 'inline-flex' : 'none';
                if (showCold) $('#coldThawBadge').textContent = coldThawData.filter(r => storeFilter(r, '门店名称')).length;
                const showLogistics = logisticsData.length && logisticsData.some(r => storeFilter(r, '门店名称'));
                $('#viewBubbleLogistics').style.display = showLogistics ? 'inline-flex' : 'none';
                if (showLogistics) $('#logisticsBadge').textContent = logisticsData.filter(r => storeFilter(r, '门店名称')).length;
                // 问单视图badge：排除冷链商品化冻和物流损
                const defaultData = allData.filter(r => {
                    const reason = (getColValue(r,'问题原因名称')||'').trim();
                    return reason !== '冷链商品化冻' && reason !== '物流损';
                });
                $('#defaultBadge').textContent = defaultData.filter(r => storeFilter(r, '门店名称')).length;

                // 如果当前视图被隐藏，自动切换到有数据的其他视图
                const viewMap = { 'badReview': showBad, 'coldThaw': showCold, 'logistics': showLogistics, 'default': true };
                if (!viewMap[currentView]) {
                    if (showLogistics) switchView('logistics');
                    else if (showCold) switchView('coldThaw');
                    else if (showBad) switchView('badReview');
                    else switchView('default');
                    return; // switchView 内部已调用 updateFilterDropdowns
                }

                updateViewBubbleActiveState();
                if (currentView !== 'default') updateFilterDropdowns();
            }

            function updateViewBubbleActiveState() {
                $('#viewBubbleDefault').className = 'view-switch-bubble' + (currentView==='default'?' active-default':'');
                $('#viewBubbleLogistics').className = 'view-switch-bubble' + (currentView==='logistics'?' active-logistics':'');
                $('#viewBubbleBadReview').className = 'view-switch-bubble' + (currentView==='badReview'?' active-bad':'');
                $('#viewBubbleColdThaw').className = 'view-switch-bubble' + (currentView==='coldThaw'?' active-cold':'');
            }

            $('#viewBubbleDefault').addEventListener('click', () => switchView('default'));
            $('#viewBubbleLogistics').addEventListener('click', () => switchView('logistics'));
            $('#viewBubbleBadReview').addEventListener('click', () => switchView('badReview'));
            $('#viewBubbleColdThaw').addEventListener('click', () => switchView('coldThaw'));

            function switchView(v) {
                if (currentView === v) return;
                currentView = v; setCurrentPage(1);
                // 门店筛选在所有视图通用，始终保留
                // 切换到冷链/物流损视图时，设置对应的原因筛选（统一机制）
                if (v === 'coldThaw') filterReasonName = '冷链商品化冻';
                else if (v === 'logistics') filterReasonName = '物流损';
                else if (v === 'default') {
                    // 从冷链/物流损切回问单：若原因是冷链/物流损则重置为全部
                    if (filterReasonName === '冷链商品化冻' || filterReasonName === '物流损') filterReasonName = '__all__';
                }
                if (v === 'badReview') filterReasonName = '__all__';
                if (v !== 'badReview') filterReviewTag = '__all__';
                updateViewBubblesVisibility();
                updateViewBubbleActiveState(); updateBubbles(); applyFilters();
            }

            // ========== 问单类目分析页面功能 ==========
            function showAnalysisPage() {
                if (!allData.length) {
                    toast('⚠️ 请先导入数据');
                    return;
                }
                isAnalysisPageVisible = true;
                $('#mainPage').classList.add('hidden');
                $('#analysisPage').classList.add('show');
                $('#headerMenuDropdown').classList.remove('show');
                updateAnalysisToggleState(); // 同步面板显示与当前类型
                renderAnalysisPage();
            }

            function hideAnalysisPage() {
                isAnalysisPageVisible = false;
                $('#mainPage').classList.remove('hidden');
                $('#analysisPage').classList.remove('show');
            }

            function switchAnalysisType(type) {
                if (currentAnalysisType === type) return;
                currentAnalysisType = type;
                updateAnalysisToggleState();
                renderAnalysisPage();
            }

            function updateAnalysisToggleState() {
                const coldBtn = $('#analysisToggleCold');
                const logisticsBtn = $('#analysisToggleLogistics');
                const orderBtn = $('#analysisToggleOrder');
                const badReviewBtn = $('#analysisToggleBadReview');
                coldBtn.className = 'analysis-toggle-btn' + (currentAnalysisType === 'coldThaw' ? ' active-cold' : '');
                logisticsBtn.className = 'analysis-toggle-btn' + (currentAnalysisType === 'logistics' ? ' active-logistics' : '');
                orderBtn.className = 'analysis-toggle-btn' + (currentAnalysisType === 'order' ? ' active-order' : '');
                badReviewBtn.className = 'analysis-toggle-btn' + (currentAnalysisType === 'badReview' ? ' active-badreview' : '');
                // 切换面板显示
                const isColdOrLogistics = currentAnalysisType === 'coldThaw' || currentAnalysisType === 'logistics';
                const isOrder = currentAnalysisType === 'order';
                const isBadReview = currentAnalysisType === 'badReview';
                $('#analysisRankRow').style.display = isColdOrLogistics ? '' : 'none';
                $('#analysisOrderRow').style.display = isOrder ? '' : 'none';
                $('#analysisBadReviewRow').style.display = isBadReview ? '' : 'none';
            }

            function getStoreAreaName(storeName) {
                for (const [area, stores] of Object.entries(areaStoreMap)) {
                    if (stores.includes(storeName)) return area;
                }
                return '-';
            }

            // 渲染问单类目分析页面
                        function renderAnalysisPage() {
                // 更新子标题TOP数量
                $('#tailTitle').textContent = '🔴 尾部门店 TOP' + rankTopCount;
                $('#headTitle').textContent = '🟢 头部门店 TOP' + rankTopCount;
                $('#skuTitle').textContent = '📦 商品排行榜（SKU出现次数 TOP' + skuTopCount + '）';
                // 更新统计面板
                updateAnalysisStats();
                if (currentAnalysisType === 'coldThaw' || currentAnalysisType === 'logistics') {
                    renderAchievementRankTail();
                    renderAchievementRankHead();
                    renderSkuRank();
                } else if (currentAnalysisType === 'order') {
                    renderOrderRank();
                    renderDeliveryRank(allData, '门店名称', 'deliveryRankTailPanel');
                } else if (currentAnalysisType === 'badReview') {
                    renderBadReviewRank();
                    renderTagRank();
                }
                // 渲染完成后根据实际可用高度自适应表格字号，确保5行/10行完整填满、无滚动条、不溢出
                requestAnimationFrame(fitAnalysisFontSize);
            }

            // 表格字号自适应：直接测量各表格scrollHeight与可用高度的比例缩放字号
            // 不管行数多少、是否合并，都能正确缩放，确保无滚动条不溢出
            function fitAnalysisFontSize() {
                const page = document.getElementById('analysisPage');
                if (!page || !page.classList.contains('show')) return;
                const rows = ['analysisRankRow', 'analysisOrderRow', 'analysisBadReviewRow'];
                const visibleRow = rows.map(id => document.getElementById(id)).find(r => r && r.style.display !== 'none');
                if (!visibleRow) return;
                const firstTable = visibleRow.querySelector('.analysis-table');
                if (!firstTable) return;
                // 左侧子面板内容区高度（半高）与右侧面板内容区高度（整高）
                const leftSub = visibleRow.querySelector('.analysis-sub-panel');
                const rightPanel = visibleRow.querySelector('.analysis-panel:not(:has(.analysis-sub-panel))');
                let availL = 0, availR = 0;
                if (leftSub) {
                    const cd = leftSub.querySelector('div:not(.analysis-sub-title)');
                    availL = cd ? cd.clientHeight : leftSub.clientHeight;
                }
                if (rightPanel) {
                    const cd = rightPanel.querySelector('div:not(.analysis-panel-title)');
                    availR = cd ? cd.clientHeight : rightPanel.clientHeight;
                }
                if (!availL && !availR) return;
                const safeMargin = 0.97;
                let curFont = parseFloat(getComputedStyle(firstTable).fontSize) || 15;
                for (let i = 0; i < 3; i++) {
                    let scale = 999;
                    // 左侧：每个子面板的表格分别与 availL 比较，取最紧约束
                    if (availL) {
                        visibleRow.querySelectorAll('.analysis-sub-panel table').forEach(t => {
                            if (t.scrollHeight > 0) scale = Math.min(scale, (availL * safeMargin) / t.scrollHeight);
                        });
                    }
                    // 右侧：表格与 availR 比较
                    if (availR && rightPanel) {
                        const t = rightPanel.querySelector('table');
                        if (t && t.scrollHeight > 0) scale = Math.min(scale, (availR * safeMargin) / t.scrollHeight);
                    }
                    if (scale >= 999 || Math.abs(scale - 1) < 0.005) break;
                    curFont = curFont * scale;
                    curFont = Math.max(11, Math.min(curFont, 26));
                    page.style.setProperty('--ar-font', curFont.toFixed(2) + 'px');
                    page.style.setProperty('--ar-head-font', (curFont * 0.72).toFixed(2) + 'px');
                }
            }

            // 更新分析页面统计信息
            function updateAnalysisStats() {
                const statsPanel = $('#analysisStatsPanel');
                if (!statsPanel) return;
                statsPanel.style.display = 'flex';
                const storeNameEl = $('#analysisStoreName');
                const dataSourceEl = $('#analysisDataSourceText');

                // 当前分析类型
                const analysisTypeLabel = currentAnalysisType === 'coldThaw' ? '冷链化冻'
                    : currentAnalysisType === 'logistics' ? '物流损'
                    : currentAnalysisType === 'order' ? '问单'
                    : '差评';
                // 门店类型筛选状态
                let storeTypeLabel = '';
                if (filterStoreTypes.qianzhicang && filterStoreTypes.shengxian) {
                    storeTypeLabel = '所有店';
                } else if (filterStoreTypes.qianzhicang) {
                    storeTypeLabel = '前置仓';
                } else if (filterStoreTypes.shengxian) {
                    storeTypeLabel = '生鲜店';
                } else {
                    storeTypeLabel = '无';
                }

                let baseText = '';
                if (selectedArea) {
                    const storeCount = getAreaStores(selectedArea).length;
                    baseText = `🗺️ 统计片区：${escapeHTML(selectedArea)}<span class="store-type-tag" style="background:#e0f2fe;color:#0369a1;">${storeCount}家门店</span>`;
                } else if (selectedStore) {
                    const storeType = getStoreType(selectedStore);
                    const typeLabel = getStoreTypeLabel(storeType);
                    const typeClass = getStoreTypeClass(storeType);
                    baseText = `📍 当前门店：${escapeHTML(selectedStore)}<span class="store-type-tag ${typeClass}">${typeLabel}</span>`;
                } else {
                    baseText = '📍 统计片区：全部片区';
                }
                // 追加分析类型和门店类型筛选信息
                storeNameEl.innerHTML = baseText + `${analysisTypeLabel}（${storeTypeLabel}）`;

                const info = getDateRangeInfo();
                if (!info.range) { dataSourceEl.textContent = '统计时间：--'; return; }
                const fileLabel = isMultiFile ? '（' + uploadedFileCount + '个文件合并）' : '';
                dataSourceEl.textContent = '统计时间：' + info.range + fileLabel;
            }

            // 构建达成排行榜门店数据（公共逻辑）
            function buildAchievementStoreList() {
                const currentAchData = getCurrentAchievements();
                if (!achievementCategories.length || !Object.keys(currentAchData).length) {
                    return null;
                }

                // 确定当前分析类型对应的类目索引
                // 冷链化冻对应索引7（第8列），物流损对应索引9（第10列）
                const targetCatIndex = currentAnalysisType === 'coldThaw' ? 7 : 9;
                if (targetCatIndex >= achievementCategories.length) {
                    return null;
                }
                const targetCatKey = achievementCategories[targetCatIndex];

                // 获取当前筛选范围内的门店
                let stores = [];
                if (selectedArea) {
                    stores = getAreaStores(selectedArea);
                } else if (selectedStore) {
                    stores = [selectedStore];
                } else {
                    stores = getAllAreaStores();
                }
                if (!stores.length) {
                    return null;
                }

                // 统计每个门店在当前类目数据中的问单数量
                const sourceData = currentAnalysisType === 'coldThaw' ? coldThawData : logisticsData;
                const storeOrderCounts = new Map();
                sourceData.forEach(row => {
                    const storeName = String(getColValue(row, '门店名称') || '').trim();
                    if (!storeName) return;
                    storeOrderCounts.set(storeName, (storeOrderCounts.get(storeName) || 0) + 1);
                });

                // 构建门店达成数据列表（包含达成值为0的门店，按门店类型筛选）
                const storeList = [];
                stores.forEach(storeName => {
                    const sd = currentAchData[storeName];
                    if (!sd || !sd.achievements) return;
                    const storeType = getStoreType(storeName);
                    // 门店类型筛选：未勾选则跳过
                    if (!filterStoreTypes[storeType]) return;
                    const val = sd.achievements[targetCatKey] || 0;
                    const areaName = getStoreAreaName(storeName);
                    const limits = storeType === 'qianzhicang' ? qianzhicangLimits : shengxianLimits;
                    const limit = limits[targetCatKey] || 0;
                    const orderCount = storeOrderCounts.get(storeName) || 0;
                    storeList.push({ storeName, areaName, val, limit, storeType, orderCount });
                });

                if (!storeList.length) {
                    return null;
                }

                // 按达成百分比降序排序
                storeList.sort((a, b) => b.val - a.val);

                return { storeList, targetCatKey, targetCatIndex };
            }

            // ==========================================
            // 统一渲染函数：四视图（冷链/物流损/问单/差评）共用，确保UI与结构完全一致
            // ==========================================
            // 排名样式类（1/2/3 名特殊着色）
            function getRankClass(rank) {
                if (rank === 1) return 'analysis-rank-1';
                if (rank === 2) return 'analysis-rank-2';
                if (rank === 3) return 'analysis-rank-3';
                return 'analysis-rank';
            }
            // 统一：尾部排行行HTML（含并列排名逻辑，片区/门店用标签包裹，与头部风格一致）
            // opts: { getValue, getArea, getStore, getValDisplay, getValStyle, getExtraCols }
            function buildUnifiedTailRows(items, opts) {
                const { getValue, getArea, getStore, getValDisplay, getValStyle, getExtraCols } = opts;
                let html = '';
                let currentRank = 1;
                let prevVal = null;
                items.forEach((item, idx) => {
                    const v = getValue(item);
                    if (idx > 0 && v !== prevVal) currentRank = idx + 1; // 并列排名：数值相同共享排名
                    prevVal = v;
                    const rc = getRankClass(currentRank);
                    const valStyle = getValStyle(item) || '';
                    const extraHtml = (getExtraCols(item) || []).map(c => '<td>' + c + '</td>').join('');
                    html += '<tr><td class="' + rc + '">' + currentRank + '</td>' +
                        '<td><span class="analysis-area-tag">' + escapeHTML(getArea(item)) + '</span></td>' +
                        '<td><span class="analysis-store-tag">' + escapeHTML(getStore(item)) + '</span></td>' +
                        '<td style="' + valStyle + '">' + getValDisplay(item) + '</td>' + extraHtml + '</tr>';
                });
                return html;
            }
            // 统一：渲染尾部排行面板（含表头与空态）
            function renderUnifiedTail(panel, items, headers, opts, emptyMsg) {
                if (!items || !items.length) { panel.innerHTML = '<div class="analysis-empty">' + emptyMsg + '</div>'; return; }
                let html = '<table class="' + ANALYSIS_COMMON.tableClass + '"><thead><tr>';
                headers.forEach(h => { html += '<th>' + h + '</th>'; });
                html += '</tr></thead><tbody>';
                html += buildUnifiedTailRows(items, opts);
                html += '</tbody></table>';
                panel.innerHTML = html;
            }
            // 统一：渲染尾部排行面板（=0门店末尾合并，参照头部机制）
            // 尾部降序排列，=0的门店在末尾；仅完全===0的门店合并为弹窗合并行，非零项正常并列排名
            function renderUnifiedTailWithMerge(panel, items, headers, opts, emptyMsg, detailPrefix) {
                if (!items || !items.length) { panel.innerHTML = '<div class="analysis-empty">' + emptyMsg + '</div>'; return; }
                const { getValue, getArea, getStore, getValDisplay, getValStyle, getExtraCols } = opts;
                const dp = detailPrefix || 'tailMergeDetail_';
                // 精确分离：完全===0的门店合并，非零项正常排名
                const zeroItems = items.filter(item => getValue(item) === 0);
                const nonZeroItems = items.filter(item => getValue(item) !== 0);

                let html = '<table class="' + ANALYSIS_COMMON.tableClass + '"><thead><tr>';
                headers.forEach(h => { html += '<th>' + h + '</th>'; });
                html += '</tr></thead><tbody>';

                // 非零项：正常并列排名（相同值共享排名，不合并弹窗）
                let currentRank = 1;
                let prevVal = null;
                nonZeroItems.forEach((item, idx) => {
                    const v = getValue(item);
                    if (idx > 0 && v !== prevVal) currentRank = idx + 1;
                    prevVal = v;
                    const rc = getRankClass(currentRank);
                    const valStyle = getValStyle(item) || '';
                    const extraHtml = (getExtraCols(item) || []).map(c => '<td>' + c + '</td>').join('');
                    html += '<tr><td class="' + rc + '">' + currentRank + '</td>' +
                        '<td><span class="analysis-area-tag">' + escapeHTML(getArea(item)) + '</span></td>' +
                        '<td><span class="analysis-store-tag">' + escapeHTML(getStore(item)) + '</span></td>' +
                        '<td style="' + valStyle + '">' + getValDisplay(item) + '</td>' + extraHtml + '</tr>';
                });

                // =0项：>1时合并为弹窗合并行（排在末尾），===1时正常显示
                if (zeroItems.length > 1) {
                    const mergeRank = nonZeroItems.length + 1;
                    const rc = getRankClass(mergeRank);
                    const areas = [...new Set(zeroItems.map(getArea))];
                    const areaStr = areas.length > 1 ? '多片区' : escapeHTML(areas[0]);
                    const valStyle = getValStyle(zeroItems[0]) || '';
                    const valDisplay = getValDisplay(zeroItems[0]);
                    // 弹窗表头
                    let detailRows = '<div style="display:flex;gap:12px;padding:6px 0;border-bottom:2px solid #c5cbe0;font-weight:700;font-size:0.82rem;color:#5a5a78;">' +
                        '<span style="width:24px;text-align:center;flex-shrink:0;">#</span>' +
                        '<span style="width:70px;flex-shrink:0;">片区</span>' +
                        '<span style="flex:1;min-width:0;">门店</span>' +
                        '<span style="width:75px;text-align:center;flex-shrink:0;">' + headers[3] + '</span>';
                    const extraHeaders = headers.slice(4);
                    extraHeaders.forEach(eh => { detailRows += '<span style="width:55px;text-align:center;flex-shrink:0;">' + eh + '</span>'; });
                    detailRows += '</div>';
                    // 弹窗各行
                    zeroItems.forEach((item, i) => {
                        const vs = getValStyle(item) || '';
                        const vd = getValDisplay(item);
                        detailRows += '<div style="display:flex;gap:12px;padding:6px 0;border-bottom:1px dashed #dde3f0;align-items:center;font-size:0.82rem;">' +
                            '<span style="width:24px;color:#8b8ba8;text-align:center;flex-shrink:0;">' + (i + 1) + '</span>' +
                            '<span style="width:70px;flex-shrink:0;">' + escapeHTML(getArea(item)) + '</span>' +
                            '<span style="flex:1;min-width:0;">' + escapeHTML(getStore(item)) + '</span>' +
                            '<span style="width:75px;text-align:center;flex-shrink:0;' + vs + '">' + vd + '</span>';
                        const ec = getExtraCols(item) || [];
                        ec.forEach(c => { detailRows += '<span style="width:55px;text-align:center;flex-shrink:0;">' + String(c).replace(/<[^>]*>/g, '') + '</span>'; });
                        detailRows += '</div>';
                    });
                    // 合计行：数值列求和
                    const extraSumCols = (function() {
                        const firstExtra = getExtraCols(zeroItems[0]) || [];
                        return firstExtra.map((_, ci) => {
                            const vals = zeroItems.map(item => {
                                const raw = (getExtraCols(item) || [])[ci] || '';
                                const num = parseFloat(String(raw).replace(/<[^>]*>/g, ''));
                                return isNaN(num) ? null : num;
                            });
                            if (vals.every(v => v !== null)) return '<strong>' + vals.reduce((a, b) => a + b, 0) + '</strong>';
                            return (getExtraCols(zeroItems[0]) || [])[ci] || '';
                        });
                    })();
                    let extraSumHtml = '';
                    extraSumCols.forEach(ec => { extraSumHtml += '<td>' + ec + '</td>'; });
                    const detailId = dp + Date.now();
                    html += '<tr><td class="' + rc + '">' + mergeRank + '</td>' +
                        '<td><span class="analysis-area-tag">' + areaStr + '</span></td>' +
                        '<td><span class="cell-clickable" style="cursor:pointer;color:#4f6ef7;font-weight:600;" data-detail-id="' + detailId + '">' + zeroItems.length + '家门店 ▼</span></td>' +
                        '<td style="' + valStyle + '">' + valDisplay + '</td>' + extraSumHtml + '</tr>';
                    if (!window._headTiedDetails) window._headTiedDetails = {};
                    window._headTiedDetails[detailId] = detailRows;
                } else if (zeroItems.length === 1) {
                    const item = zeroItems[0];
                    const rank = nonZeroItems.length + 1;
                    const rc = getRankClass(rank);
                    const valStyle = getValStyle(item) || '';
                    const extraHtml = (getExtraCols(item) || []).map(c => '<td>' + c + '</td>').join('');
                    html += '<tr><td class="' + rc + '">' + rank + '</td>' +
                        '<td><span class="analysis-area-tag">' + escapeHTML(getArea(item)) + '</span></td>' +
                        '<td><span class="analysis-store-tag">' + escapeHTML(getStore(item)) + '</span></td>' +
                        '<td style="' + valStyle + '">' + getValDisplay(item) + '</td>' + extraHtml + '</tr>';
                }

                html += '</tbody></table>';
                panel.innerHTML = html;
            }
            // 统一：渲染附加排行面板（SKU/配送员/标签，按出现次数降序，简单排名）
            // items: 已排序数组；getCols(item) 返回排名列之后的各列HTML数组
            function renderUnifiedExtra(panel, items, headers, getCols, emptyMsg) {
                if (!items || !items.length) { panel.innerHTML = '<div class="analysis-empty">' + emptyMsg + '</div>'; return; }
                let html = '<table class="' + ANALYSIS_COMMON.tableClass + '"><thead><tr>';
                headers.forEach(h => { html += '<th>' + h + '</th>'; });
                html += '</tr></thead><tbody>';
                items.forEach((item, idx) => {
                    const rank = idx + 1;
                    const rc = getRankClass(rank);
                    const colsHtml = (getCols(item) || []).map(c => '<td>' + c + '</td>').join('');
                    html += '<tr><td class="' + rc + '">' + rank + '</td>' + colsHtml + '</tr>';
                });
                html += '</tbody></table>';
                panel.innerHTML = html;
            }
            // 统一：为头部排行弹窗绑定点击事件
            function bindHeadDetailClick(panels) {
                panels.forEach(panel => {
                    panel.querySelectorAll('.cell-clickable[data-detail-id]').forEach(el => {
                        el.addEventListener('click', function(e) {
                            e.stopPropagation();
                            const did = this.dataset.detailId;
                            const rows = (window._headTiedDetails && window._headTiedDetails[did]) || '';
                            showDetailPopup(this, '<div style="padding:4px 0;">' + rows + '</div>', false);
                        });
                    });
                });
            }

            // ==========================================
            // 公共函数：头部排行（并列第一合并+弹窗）
            // ==========================================
            // opts 参数说明：
            //   topCount      : rankTopCount 排行展示数量
            //   headers       : 表头数组，如 ['排行','片区','门店','达成占比','问单数量']
            //   tiedData      : 并列第一的数组（已按升序排序后提取的并列数据）
            //   restData      : 剩余数据数组（去掉并列第一后按升序排列）
            //   getValFn(item): 从数据项中提取排序用的数值（用于对比并列）
            //   getAreaFn(item): 从数据项中提取片区名称
            //   getStoreFn(item): 从数据项中提取门店名称
            //   getValDisplayFn(item): 从数据项中提取用于展示的达成占比文本
            //   getValStyleFn(item): 从数据项中提取达成占比的样式（超标标红）
            //   getExtraColsFn(item, mode): 返回除片区/门店/达成占比之外的列HTML数组
            //       mode=true:  返回弹窗表头文本数组（item为null）
            //       mode='sum': 返回合并行的合计值HTML数组（item为null）
            //       mode='detail': 返回弹窗内每行明细的HTML数组
            //       其他(mode=false): 返回普通表格行的HTML数组
            //   useTags       : 布尔值，片区/门店是否用 span 标签包裹（如 analysis-area-tag）
            //   detailPrefix  : 弹窗ID前缀，如 'headAchDetail_'
            //   tableClass    : 表格CSS class
            function buildHeadRankHTML(opts) {
                const { topCount, headers, tiedData, restData, getValFn, getAreaFn, getStoreFn,
                        getValDisplayFn, getValStyleFn, getExtraColsFn, useTags, detailPrefix, tableClass } = opts;
                // 有并列项（>=1）时，第一名槽位被 tiedData 占据，其余取 topCount-1 条；
                // 无并列项（tiedData 为空，即最低值非0不合并）时，全部从 restData 取 topCount 条
                const restSliceCount = tiedData.length >= 1 ? Math.max(0, topCount - 1) : topCount;
                const allData = [...tiedData, ...restData.slice(0, restSliceCount)];
                let html = '<table class="' + tableClass + '"><thead><tr>';
                headers.forEach(h => { html += '<th>' + h + '</th>'; });
                html += '</tr></thead><tbody>';

                let skipCount = 0;
                if (allData.length > 0 && tiedData.length > 1) {
                    skipCount = tiedData.length;
                    const areas = [...new Set(tiedData.map(getAreaFn))];
                    const areaStr = areas.length > 1 ? '多片区' : escapeHTML(areas[0]);
                    const valStyle = getValStyleFn(tiedData[0]);
                    const valDisplay = getValDisplayFn(tiedData[0]);
                    // 弹窗表头：片区、门店、达成占比 + 额外列
                    let detailRows = '<div style="display:flex;gap:12px;padding:6px 0;border-bottom:2px solid #c5cbe0;font-weight:700;font-size:0.82rem;color:#5a5a78;">' +
                        '<span style="width:24px;text-align:center;flex-shrink:0;">#</span>' +
                        '<span style="width:70px;flex-shrink:0;">片区</span>' +
                        '<span style="flex:1;min-width:0;">门店</span>' +
                        '<span style="width:75px;text-align:center;flex-shrink:0;">达成占比</span>';
                    // 额外列表头
                    const extraHeaders = getExtraColsFn(null, true);
                    if (extraHeaders) {
                        extraHeaders.forEach(eh => { detailRows += '<span style="width:55px;text-align:center;flex-shrink:0;">' + eh + '</span>'; });
                    }
                    detailRows += '</div>';
                    // 弹窗各行
                    tiedData.forEach((item, i) => {
                        const vs = getValStyleFn(item);
                        const vd = getValDisplayFn(item);
                        detailRows += '<div style="display:flex;gap:12px;padding:6px 0;border-bottom:1px dashed #dde3f0;align-items:center;font-size:0.82rem;">' +
                            '<span style="width:24px;color:#8b8ba8;text-align:center;flex-shrink:0;">' + (i + 1) + '</span>' +
                            '<span style="width:70px;flex-shrink:0;">' + escapeHTML(getAreaFn(item)) + '</span>' +
                            '<span style="flex:1;min-width:0;">' + escapeHTML(getStoreFn(item)) + '</span>' +
                            '<span style="width:75px;text-align:center;flex-shrink:0;' + vs + '">' + vd + '</span>';
                        const extraCols = getExtraColsFn(item, 'detail');
                        if (extraCols) {
                            extraCols.forEach(ec => { detailRows += '<span style="width:55px;text-align:center;flex-shrink:0;">' + ec + '</span>'; });
                        }
                        detailRows += '</div>';
                    });
                    // 合并行：排名1
                    const areaTag = useTags ? '<span class="analysis-area-tag">' + areaStr + '</span>' : areaStr;
                    const extraSumCols = getExtraColsFn(null, 'sum');
                    let extraSumHtml = '';
                    if (extraSumCols) {
                        extraSumCols.forEach(ec => { extraSumHtml += '<td>' + ec + '</td>'; });
                    }
                    const detailId = detailPrefix + Date.now();
                    html += '<tr><td class="analysis-rank-1">1</td><td>' + areaTag + '</td><td><span class="cell-clickable" style="cursor:pointer;color:#4f6ef7;font-weight:600;" data-detail-id="' + detailId + '">' + tiedData.length + '家门店 ▼</span></td><td style="' + valStyle + '">' + valDisplay + '</td>' + extraSumHtml + '</tr>';
                    if (!window._headTiedDetails) window._headTiedDetails = {};
                    window._headTiedDetails[detailId] = detailRows;
                }

                allData.slice(skipCount).forEach((item, idx) => {
                    // skipCount>0 表示已渲染合并行（并列第一占排名1），后续从2开始；否则无合并，从1开始
                    const rank = skipCount > 0 ? idx + 2 : idx + 1;
                    let rc = 'analysis-rank';
                    if (rank === 1) rc = 'analysis-rank-1';
                    else if (rank === 2) rc = 'analysis-rank-2';
                    else if (rank === 3) rc = 'analysis-rank-3';
                    const areaTag = useTags ? '<span class="analysis-area-tag">' + escapeHTML(getAreaFn(item)) + '</span>' : escapeHTML(getAreaFn(item));
                    const storeTag = useTags ? '<span class="analysis-store-tag">' + escapeHTML(getStoreFn(item)) + '</span>' : escapeHTML(getStoreFn(item));
                    const valStyle = getValStyleFn(item);
                    const valDisplay = getValDisplayFn(item);
                    const extraCols = getExtraColsFn(item, false);
                    let extraHtml = '';
                    if (extraCols) {
                        extraCols.forEach(ec => { extraHtml += '<td>' + ec + '</td>'; });
                    }
                    html += '<tr><td class="' + rc + '">' + rank + '</td><td>' + areaTag + '</td><td>' + storeTag + '</td><td style="' + valStyle + '">' + valDisplay + '</td>' + extraHtml + '</tr>';
                });

                html += '</tbody></table>';
                return html;
            }

            // 尾部门店：达成数值最高的N个，降序
            function renderAchievementRankTail() {
                const panel = $('#achievementRankTailPanel');
                const result = buildAchievementStoreList();
                if (!result) {
                    panel.innerHTML = '<div class="analysis-empty">暂无达成数据</div>';
                    return;
                }
                const { storeList, targetCatKey, targetCatIndex } = result;
                // 尾部降序：非零项取前N个；仅当非零项不足N个时，=0项才补充为合并行排在末尾
                const allZeroItems = storeList.filter(item => item.val === 0);
                const nonZeroItems = storeList.filter(item => item.val !== 0).slice(0, rankTopCount);
                const zeroItems = nonZeroItems.length < rankTopCount ? allZeroItems : [];
                const tailList = [...nonZeroItems, ...zeroItems];
                renderUnifiedTailWithMerge(panel, tailList, ANALYSIS_COMMON.headers.achievement, {
                    getValue: item => item.val,
                    getArea: item => item.areaName,
                    getStore: item => item.storeName,
                    getValDisplay: item => formatAchievementValue(item.val, targetCatKey, null, targetCatIndex),
                    getValStyle: item => {
                        const isOver = item.limit > 0 && item.val > item.limit;
                        return isOver ? ('color:' + ANALYSIS_COMMON.overColor + ';font-weight:' + ANALYSIS_COMMON.overWeight + ';') : '';
                    },
                    getExtraCols: item => [item.orderCount]
                }, '暂无达成数据', 'tailAchDetail_');
            }

            // 头部门店：达成数值最低的N个，升序排列
            function renderAchievementRankHead() {
                const panel = $('#achievementRankHeadPanel');
                const result = buildAchievementStoreList();
                if (!result) {
                    panel.innerHTML = '<div class="analysis-empty">暂无达成数据</div>';
                    return;
                }
                const { storeList, targetCatKey, targetCatIndex } = result;
                // 头部：升序排列后，仅当最低值=0时，所有val=0的门店进弹窗合并；最低值非0时不合并，逐条展示
                const sortedAsc = [...storeList].sort((a, b) => a.val - b.val);
                const firstVal = sortedAsc.length > 0 ? sortedAsc[0].val : 0;
                const isZeroFirst = firstVal === 0;
                const tiedAll = isZeroFirst ? sortedAsc.filter(item => item.val === 0) : [];
                const remaining = isZeroFirst ? sortedAsc.filter(item => item.val !== 0) : sortedAsc;

                const html = buildHeadRankHTML({
                    topCount: rankTopCount,
                    headers: ANALYSIS_COMMON.headers.achievement,
                    tiedData: tiedAll,
                    restData: remaining,
                    getValFn: item => item.val,
                    getAreaFn: item => item.areaName,
                    getStoreFn: item => item.storeName,
                    getValDisplayFn: item => formatAchievementValue(item.val, targetCatKey, null, targetCatIndex),
                    getValStyleFn: item => {
                        const isOver = item.limit > 0 && item.val > item.limit;
                        return isOver ? ('color:' + ANALYSIS_COMMON.overColor + ';font-weight:' + ANALYSIS_COMMON.overWeight + ';') : '';
                    },
                    getExtraColsFn: (item, mode) => {
                        if (mode === true) return ['问单数量']; // 弹窗表头
                        if (mode === 'sum') {
                            // 合并行的合计值
                            const totalOrder = tiedAll.reduce((sum, s) => sum + s.orderCount, 0);
                            return [totalOrder];
                        }
                        if (mode === 'detail') {
                            // 弹窗内明细行
                            return ['<strong>' + item.orderCount + '</strong>'];
                        }
                        // 普通行
                        return [item.orderCount];
                    },
                    useTags: true,
                    detailPrefix: 'headAchDetail_',
                    tableClass: ANALYSIS_COMMON.tableClass
                });
                panel.innerHTML = html;
                bindHeadDetailClick([panel, $('#achievementRankTailPanel')]);
            }

            // 商品排行榜：根据SKU名称出现数量排行
            function renderSkuRank() {
                const panel = $('#skuRankPanel');
                const sourceData = currentAnalysisType === 'coldThaw' ? coldThawData : logisticsData;
                if (!sourceData.length) {
                    panel.innerHTML = '<div class="analysis-empty">暂无商品数据</div>';
                    return;
                }

                // 获取当前筛选范围内的门店
                let filterStoreSet = null;
                if (selectedStore) {
                    filterStoreSet = new Set([selectedStore]);
                } else if (selectedArea) {
                    filterStoreSet = new Set(getAreaStores(selectedArea));
                }

                // 统计SKU出现次数（按门店类型筛选）
                const skuCounts = new Map();
                sourceData.forEach(row => {
                    const storeName = String(getColValue(row, '门店名称') || '').trim();
                    if (filterStoreSet && !filterStoreSet.has(storeName)) return;
                    // 门店类型筛选
                    const storeType = getStoreType(storeName);
                    if (!filterStoreTypes[storeType]) return;
                    const skuName = String(getColValue(row, 'sku名称') || getColValue(row, 'SKU名称') || '').trim();
                    if (!skuName || skuName === '-') return;
                    skuCounts.set(skuName, (skuCounts.get(skuName) || 0) + 1);
                });

                if (!skuCounts.size) {
                    panel.innerHTML = '<div class="analysis-empty">暂无商品数据</div>';
                    return;
                }

                // 按出现次数降序排序，仅显示前N名
                const sortedSkus = [...skuCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, skuTopCount);
                const skuItems = sortedSkus.map(e => ({ name: e[0], count: e[1] }));
                renderUnifiedExtra(panel, skuItems, ANALYSIS_COMMON.headers.sku,
                    item => [escapeHTML(item.name), '<strong>' + item.count + '</strong>'],
                    '暂无商品数据');
            }

            // ==========================================
            // 问单排行：全体问单（含冷链+物流损）按问单数量排行，分头尾门店
            // ==========================================
            function renderOrderRank() {
                const tailPanel = $('#orderRankTailPanel');
                const headPanel = $('#orderRankHeadPanel');
                const achData = getCurrentAchievements();
                if (!achievementCategories.length || achievementCategories.length < 14) {
                    tailPanel.innerHTML = '<div class="analysis-empty">暂无问单数据（需至少14列类目数据）</div>';
                    headPanel.innerHTML = '<div class="analysis-empty">暂无问单数据</div>';
                    return;
                }
                const catKey14 = achievementCategories[13];
                const catKey13 = achievementCategories[12];

                let filterStoreSet = null;
                if (selectedStore) filterStoreSet = new Set([selectedStore]);
                else if (selectedArea) filterStoreSet = new Set(getAreaStores(selectedArea));

                const rankData = [];
                const seenStores = new Set();
                allData.forEach(row => {
                    const sn = String(getColValue(row, '门店名称') || '').trim();
                    if (!sn) return;
                    if (filterStoreSet && !filterStoreSet.has(sn)) return;
                    if (seenStores.has(sn)) return;
                    seenStores.add(sn);
                    const storeType = getStoreType(sn);
                    if (!filterStoreTypes[storeType]) return;
                    const area = getStoreAreaName(sn);
                    const sd = achData[sn];
                    const val14 = sd ? (sd.achievements[catKey14] || 0) : 0;
                    const val13 = sd ? (sd.achievements[catKey13] || 0) : 0;
                    const ratio = val13 > 0 ? val14 / val13 * 100 : 0; // 达成占比=列14/列13*100
                    const overLimitThreshold = storeType === 'qianzhicang' ? 0.15 : 0.2; // 生鲜店0.2%，前置仓0.15%
                    const overLimit = ratio > overLimitThreshold;
                    rankData.push({ area, store: sn, ratio, ratioStr: ratio.toFixed(3) + '%', count: val14, overLimit });
                });

                $('#orderTailCount').textContent = rankTopCount;
                $('#orderHeadCount').textContent = rankTopCount;

                if (!rankData.length) {
                    tailPanel.innerHTML = '<div class="analysis-empty">暂无问单数据</div>';
                    headPanel.innerHTML = '<div class="analysis-empty">暂无问单数据</div>';
                    return;
                }

                rankData.sort((a, b) => b.ratio - a.ratio); // 降序：达成占比最高的排前面
                // 尾部降序：非零项取前N个；仅当非零项不足N个时，=0项才补充为合并行排在末尾
                const tailZeroAll = rankData.filter(item => Math.abs(item.ratio) < 0.0001);
                const tailNonZero = rankData.filter(item => Math.abs(item.ratio) >= 0.0001).slice(0, rankTopCount);
                const tailZero = tailNonZero.length < rankTopCount ? tailZeroAll : [];
                const tailData = [...tailNonZero, ...tailZero];

                // 头部：升序排列后，仅当最低值=0时，所有ratio=0的门店进弹窗合并；最低值非0时不合并，逐条展示
                const sortedAsc = [...rankData].sort((a, b) => a.ratio - b.ratio);
                const firstRatio = sortedAsc.length > 0 ? sortedAsc[0].ratio : 0;
                const isZeroFirst = Math.abs(firstRatio) < 0.0001;
                const tiedAll = isZeroFirst ? sortedAsc.filter(item => Math.abs(item.ratio) < 0.0001) : [];
                const remaining = isZeroFirst ? sortedAsc.filter(item => Math.abs(item.ratio) >= 0.0001) : sortedAsc;

                // 尾部渲染：统一函数（含首值并列合并、片区门店标签）
                renderUnifiedTailWithMerge(tailPanel, tailData, ANALYSIS_COMMON.headers.order, {
                    getValue: item => Math.abs(item.ratio) < 0.0001 ? 0 : item.ratio,
                    getArea: item => item.area,
                    getStore: item => item.store,
                    getValDisplay: item => item.ratioStr,
                    getValStyle: item => item.overLimit ? ('color:' + ANALYSIS_COMMON.overColor + ';font-weight:' + ANALYSIS_COMMON.overWeight + ';') : '',
                    getExtraCols: item => ['<strong>' + item.count + '</strong>']
                }, '暂无问单数据', 'tailOrderDetail_');

                // 头部渲染：使用公共函数（并列第一合并+弹窗）
                const headHtml = buildHeadRankHTML({
                    topCount: rankTopCount,
                    headers: ANALYSIS_COMMON.headers.order,
                    tiedData: tiedAll,
                    restData: remaining,
                    getValFn: item => item.ratio,
                    getAreaFn: item => item.area,
                    getStoreFn: item => item.store,
                    getValDisplayFn: item => item.ratioStr,
                    getValStyleFn: item => item.overLimit ? ('color:' + ANALYSIS_COMMON.overColor + ';font-weight:' + ANALYSIS_COMMON.overWeight + ';') : '',
                    getExtraColsFn: (item, mode) => {
                        if (mode === true) return ['问单数量']; // 弹窗表头
                        if (mode === 'sum') {
                            const totalCount = tiedAll.reduce((sum, s) => sum + s.count, 0);
                            return ['<strong>' + totalCount + '</strong>'];
                        }
                        // 普通行
                        return ['<strong>' + item.count + '</strong>'];
                    },
                    useTags: true,
                    detailPrefix: 'headOrderDetail_',
                    tableClass: ANALYSIS_COMMON.tableClass
                });
                headPanel.innerHTML = headHtml;
                bindHeadDetailClick([tailPanel, headPanel]);
            }

            // ==========================================
            // 配送员排行榜：带头尾拆分（问单视图 / 差评视图共用）
            // ==========================================
            function renderDeliveryRank(sourceData, storeColName, panelId) {
                const panel = $('#' + panelId);

                let filterStoreSet = null;
                if (selectedStore) filterStoreSet = new Set([selectedStore]);
                else if (selectedArea) filterStoreSet = new Set(getAreaStores(selectedArea));

                // 配送员 → { name, stores, count }，同一配送员合并计数
                const deliveryMap = new Map();
                sourceData.forEach(row => {
                    const sn = String(getColValue(row, storeColName) || '').trim();
                    if (!sn) return;
                    if (filterStoreSet && !filterStoreSet.has(sn)) return;
                    const storeType = getStoreType(sn);
                    if (!filterStoreTypes[storeType]) return;
                    const delivery = String(getColValue(row, '配送员名') || getColValue(row, '责任人') || '').trim();
                    if (!delivery || delivery === '-') return;
                    if (deliveryMap.has(delivery)) {
                        const entry = deliveryMap.get(delivery);
                        entry.count++;
                        entry.stores.add(sn);
                    } else {
                        deliveryMap.set(delivery, { name: delivery, stores: new Set([sn]), count: 1 });
                    }
                });

                if (!deliveryMap.size) {
                    panel.innerHTML = '<div class="analysis-empty">暂无配送员数据</div>';
                    return;
                }

                const sorted = [...deliveryMap.values()].sort((a, b) => b.count - a.count).slice(0, skuTopCount);
                renderUnifiedExtra(panel, sorted, ANALYSIS_COMMON.headers.delivery,
                    item => [escapeHTML(item.name), escapeHTML([...item.stores].join(', ')), '<strong>' + item.count + '</strong>'],
                    '暂无配送员数据');
            }

            // ==========================================
            // 差评排行：按差评数量排行，分头尾门店
            // ==========================================
            function renderBadReviewRank() {
                const tailPanel = $('#badReviewRankTailPanel');
                const headPanel = $('#badReviewRankHeadPanel');
                const achData = getCurrentAchievements();
                if (!achievementCategories.length || achievementCategories.length < 26) {
                    tailPanel.innerHTML = '<div class="analysis-empty">暂无差评数据（需至少26列类目数据）</div>';
                    headPanel.innerHTML = '<div class="analysis-empty">暂无差评数据</div>';
                    return;
                }
                const catKey25 = achievementCategories[24];
                const catKey24 = achievementCategories[23];
                const catKey26 = achievementCategories[25];

                let filterStoreSet = null;
                if (selectedStore) filterStoreSet = new Set([selectedStore]);
                else if (selectedArea) filterStoreSet = new Set(getAreaStores(selectedArea));

                const rankData = [];
                // 遍历所有门店（含差评为0的门店），确保头部排行包含0值门店
                const allStoresList = selectedStore ? [selectedStore] : (selectedArea ? getAreaStores(selectedArea) : Object.keys(achData));
                const seenInBadReview = new Set();
                badReviewData.forEach((row) => {
                    const sn = String(getColValue(row, '门店') || '').trim();
                    if (sn) seenInBadReview.add(sn);
                });
                allStoresList.forEach(sn => {
                    const storeType = getStoreType(sn);
                    if (!filterStoreTypes[storeType]) return;
                    if (filterStoreSet && !filterStoreSet.has(sn)) return;
                    const area = getStoreAreaName(sn);
                    if (area === '-') return; // 过滤无片区信息的异常门店
                    const sd = achData[sn];
                    const val25 = sd ? (sd.achievements[catKey25] || 0) : 0;
                    const val24 = sd ? (sd.achievements[catKey24] || 0) : 0;
                    const val26 = sd ? (sd.achievements[catKey26] || 0) : 0;
                    const ratio = val24 > 0 ? val25 / val24 * 10000 : 0; // 达成占比=列25/列24*10000
                    const overLimit = ratio > 2.5; // 阈值2.5
                    rankData.push({ area, store: sn, ratio, ratioStr: ratio.toFixed(3), badCount: val25, serviceBadCount: val26, overLimit });
                });

                $('#badTailCount').textContent = rankTopCount;
                $('#badHeadCount').textContent = rankTopCount;

                if (!rankData.length) {
                    tailPanel.innerHTML = '<div class="analysis-empty">暂无差评数据</div>';
                    headPanel.innerHTML = '<div class="analysis-empty">暂无差评数据</div>';
                    return;
                }

                rankData.sort((a, b) => b.ratio - a.ratio); // 降序
                // 尾部降序：非零项取前N个；仅当非零项不足N个时，=0项才补充为合并行排在末尾
                const tailZeroAllBR = rankData.filter(item => Math.abs(item.ratio) < 0.0001);
                const tailNonZeroBR = rankData.filter(item => Math.abs(item.ratio) >= 0.0001).slice(0, rankTopCount);
                const tailZeroBR = tailNonZeroBR.length < rankTopCount ? tailZeroAllBR : [];
                const tailData = [...tailNonZeroBR, ...tailZeroBR];

                // 头部：升序排列后，仅当最低值=0时，所有ratio=0的门店进弹窗合并；最低值非0时不合并，逐条展示
                const sortedAsc = [...rankData].sort((a, b) => a.ratio - b.ratio);
                const firstRatio = sortedAsc.length > 0 ? sortedAsc[0].ratio : 0;
                const isZeroFirst = Math.abs(firstRatio) < 0.0001;
                const tiedAll = isZeroFirst ? sortedAsc.filter(item => Math.abs(item.ratio) < 0.0001) : [];
                const remaining = isZeroFirst ? sortedAsc.filter(item => Math.abs(item.ratio) >= 0.0001) : sortedAsc;

                // 尾部渲染：统一函数（含首值并列合并、片区门店标签）
                renderUnifiedTailWithMerge(tailPanel, tailData, ANALYSIS_COMMON.headers.badReview, {
                    getValue: item => Math.abs(item.ratio) < 0.0001 ? 0 : item.ratio,
                    getArea: item => item.area,
                    getStore: item => item.store,
                    getValDisplay: item => item.ratioStr,
                    getValStyle: item => item.overLimit ? ('color:' + ANALYSIS_COMMON.overColor + ';font-weight:' + ANALYSIS_COMMON.overWeight + ';') : '',
                    getExtraCols: item => ['<strong>' + item.badCount + '</strong>', item.serviceBadCount]
                }, '暂无差评数据', 'tailBadDetail_');

                // 头部渲染：使用公共函数（并列第一合并+弹窗）
                const headHtml = buildHeadRankHTML({
                    topCount: rankTopCount,
                    headers: ANALYSIS_COMMON.headers.badReview,
                    tiedData: tiedAll,
                    restData: remaining,
                    getValFn: item => item.ratio,
                    getAreaFn: item => item.area,
                    getStoreFn: item => item.store,
                    getValDisplayFn: item => item.ratioStr,
                    getValStyleFn: item => item.overLimit ? ('color:' + ANALYSIS_COMMON.overColor + ';font-weight:' + ANALYSIS_COMMON.overWeight + ';') : '',
                    getExtraColsFn: (item, mode) => {
                        if (mode === true) return ['差评数量', '服务差评']; // 弹窗表头
                        if (mode === 'sum') {
                            const totalBad = tiedAll.reduce((sum, s) => sum + s.badCount, 0);
                            const totalSvc = tiedAll.reduce((sum, s) => sum + s.serviceBadCount, 0);
                            return ['<strong>' + totalBad + '</strong>', totalSvc];
                        }
                        // 普通行
                        return ['<strong>' + item.badCount + '</strong>', item.serviceBadCount];
                    },
                    useTags: true,
                    detailPrefix: 'headBadDetail_',
                    tableClass: ANALYSIS_COMMON.tableClass
                });
                headPanel.innerHTML = headHtml;
                bindHeadDetailClick([tailPanel, headPanel]);
            }

            // ==========================================
            // 评价标签排行榜：差评视图中按评价标签数量排行
            // ==========================================
            function renderTagRank() {
                const panel = $('#badTagRankTailPanel');

                let filterStoreSet = null;
                if (selectedStore) filterStoreSet = new Set([selectedStore]);
                else if (selectedArea) filterStoreSet = new Set(getAreaStores(selectedArea));

                const tagCounts = new Map();
                badReviewData.forEach(row => {
                    const sn = String(getColValue(row, '门店') || '').trim();
                    if (!sn) return;
                    if (filterStoreSet && !filterStoreSet.has(sn)) return;
                    const storeType = getStoreType(sn);
                    if (!filterStoreTypes[storeType]) return;
                    const tag = String(getColValue(row, '评价标签') || '').trim();
                    if (!tag || tag === '-') return;
                    tagCounts.set(tag, (tagCounts.get(tag) || 0) + 1);
                });

                if (!tagCounts.size) {
                    panel.innerHTML = '<div class="analysis-empty">暂无评价标签数据</div>';
                    return;
                }

                const sorted = [...tagCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, skuTopCount);
                const tagItems = sorted.map(e => ({ name: e[0], count: e[1] }));
                renderUnifiedExtra(panel, tagItems, ANALYSIS_COMMON.headers.tag,
                    item => [escapeHTML(item.name), '<strong>' + item.count + '</strong>'],
                    '暂无评价标签数据');
            }

            document.getElementById('headerMenuBtn').addEventListener('click', e => { e.stopPropagation(); $('#headerMenuDropdown').classList.toggle('show'); });
            document.addEventListener('click', e => { if (!e.target.closest('.header-menu-btn')) $('#headerMenuDropdown').classList.remove('show'); });
            document.getElementById('menuReupload').addEventListener('click', () => {
                openGuideView('📂 导入文件', '请导入问单明细Excel（支持多文件合并）',
                    '<div class="file-upload-area" id="guideUploadArea"><span class="upload-text-lg">📁 点击选择文件</span></div><div class="upload-hint">💡 导入大文件时页面可能出现短暂卡顿，请耐心等待加载完成。<br>如页面提示"无响应"，请点击<b>「等待」</b>按钮，切勿关闭页面。</div><div class="upload-progress-wrap" id="guideProgressWrap"><div class="upload-progress-bar"><div class="upload-progress-fill" id="guideProgressFill"></div></div><div class="upload-progress-text" id="guideProgressText">准备中...</div></div>',
                    '<button class="guide-btn primary" id="guideConfirmBtn">确认</button>');
                document.getElementById('guideUploadArea').addEventListener('click', () => hiddenFileInput.click());
                hiddenFileInput.onchange = e => { if (e.target.files.length) handleFileUpload(e.target.files); };
            });
            document.getElementById('menuSelectArea').addEventListener('click', showAreaQuickSelect);
            document.getElementById('menuAnalysis').addEventListener('click', showAnalysisPage);
            document.getElementById('analysisExportBtn').addEventListener('click', exportAnalysisImages);
            document.getElementById('menuExportReport').addEventListener('click', showExportDialog);
            document.getElementById('menuAboutDoc').addEventListener('click', showAboutDoc);
            document.getElementById('aboutDocCloseBtn').addEventListener('click', hideAboutDoc);
            aboutDocOverlay.addEventListener('click', e => { if (e.target === aboutDocOverlay) hideAboutDoc(); });

            // 问单类目分析页面事件绑定
            document.getElementById('analysisBackBtn').addEventListener('click', hideAnalysisPage);
            document.getElementById('analysisToggleCold').addEventListener('click', () => switchAnalysisType('coldThaw'));
            document.getElementById('analysisToggleLogistics').addEventListener('click', () => switchAnalysisType('logistics'));
            document.getElementById('analysisToggleOrder').addEventListener('click', () => switchAnalysisType('order'));
            document.getElementById('analysisToggleBadReview').addEventListener('click', () => switchAnalysisType('badReview'));
            // 窗口尺寸变化时重新自适应表格字号
            window.addEventListener('resize', () => { if (isAnalysisPageVisible) requestAnimationFrame(fitAnalysisFontSize); });

            // 设置弹窗事件绑定
            const settingModalOverlay = $('#settingModalOverlay');
            document.getElementById('analysisSettingBtn').addEventListener('click', () => {
                // 同步当前设置到弹窗
                document.getElementById('modalCheckQianzhicang').checked = filterStoreTypes.qianzhicang;
                document.getElementById('modalCheckShengxian').checked = filterStoreTypes.shengxian;
                document.getElementById('rankTopInput').value = rankTopCount;
                document.getElementById('skuTopInput').value = skuTopCount;
                settingModalOverlay.classList.add('show');
            });
            document.getElementById('settingModalCancel').addEventListener('click', () => {
                settingModalOverlay.classList.remove('show');
            });
            document.getElementById('settingModalConfirm').addEventListener('click', () => {
                filterStoreTypes.qianzhicang = document.getElementById('modalCheckQianzhicang').checked;
                filterStoreTypes.shengxian = document.getElementById('modalCheckShengxian').checked;
                const newRankTop = parseInt(document.getElementById('rankTopInput').value, 10);
                const newSkuTop = parseInt(document.getElementById('skuTopInput').value, 10);
                rankTopCount = isNaN(newRankTop) || newRankTop < 1 ? 10 : newRankTop;
                skuTopCount = isNaN(newSkuTop) || newSkuTop < 1 ? 25 : newSkuTop;
                settingModalOverlay.classList.remove('show');
                renderAnalysisPage();
            });
            settingModalOverlay.addEventListener('click', e => {
                if (e.target === settingModalOverlay) settingModalOverlay.classList.remove('show');
            });

            // ==========================================
            // 关于文档：渲染与显隐
            // ==========================================
            function showAboutDoc() {
                renderAboutDocLogic();
                renderAboutDocChangelog();
                // 顶部版本号同步显示最新版本
                const latest = ABOUT_DOC_CHANGELOG[0];
                $('#aboutDocVersion').textContent = '当前版本 ' + (latest ? latest.version : 'V1.1');
                aboutDocOverlay.classList.add('show');
                $('#headerMenuDropdown').classList.remove('show');
            }
            function hideAboutDoc() { aboutDocOverlay.classList.remove('show'); }
            function renderAboutDocLogic() {
                const body = $('#aboutDocLogicBody');
                if (!ABOUT_DOC_LOGIC.length) {
                    body.innerHTML = '<div class="changelog-empty">暂无核心逻辑记录</div>';
                    return;
                }
                let html = '';
                ABOUT_DOC_LOGIC.forEach(group => {
                    html += '<div class="logic-group"><div class="logic-group-title">' + escapeHTML(group.group) + '</div>';
                    group.items.forEach(item => {
                        html += '<div class="logic-item"><span class="logic-name">' + escapeHTML(item.name) + '</span>：<span class="logic-desc">' + escapeHTML(item.desc) + '</span></div>';
                    });
                    html += '</div>';
                });
                body.innerHTML = html;
            }
            function renderAboutDocChangelog() {
                const body = $('#aboutDocChangelogBody');
                if (!ABOUT_DOC_CHANGELOG.length) {
                    body.innerHTML = '<div class="changelog-empty">暂无更新日志</div>';
                    return;
                }
                let html = '';
                ABOUT_DOC_CHANGELOG.forEach((entry, idx) => {
                    const isLatest = idx === 0;
                    html += '<div class="changelog-item' + (isLatest ? ' latest' : '') + '">';
                    html += '<div class="changelog-version">' + escapeHTML(entry.version) + (isLatest ? '<span class="latest-tag">最新</span>' : '') + '</div>';
                    html += '<div class="changelog-date">' + escapeHTML(entry.date) + '</div>';
                    html += '<ul class="changelog-list">';
                    entry.changes.forEach(ch => { html += '<li>' + escapeHTML(ch) + '</li>'; });
                    html += '</ul></div>';
                });
                body.innerHTML = html;
            }

            // 导出报告功能 - 仅导出图片，每个模块分别导出
            function showExportDialog() {
                const html = `
                    <div style="display:flex;flex-direction:column;gap:12px;">
                        <div style="background:#f5f7ff;border:1.5px solid #dde3f8;border-radius:10px;padding:12px;">
                            <div style="font-size:0.75rem;color:#6b6b88;margin-bottom:8px;font-weight:600;">📊 导出说明</div>
                            <div style="font-size:0.7rem;color:#4a4a6a;line-height:1.6;">
                                • 每个模块（达成情况/物流损/冷链/差评）分别导出为独立图片<br>
                                • 紧凑表格样式，适合直接粘贴到文档<br>
                                • 仅导出当前筛选的片区/门店数据
                            </div>
                        </div>
                        <div style="display:flex;gap:10px;justify-content:center;">
                            <button class="guide-btn primary" id="exportImageBtn" style="flex:1;background:#10b981;">🖼️ 导出图片</button>
                            <button class="guide-btn primary" id="exportTableBtn" style="flex:1;background:#3b82f6;">📋 导出表格</button>
                        </div>
                        <div style="display:flex;gap:10px;justify-content:center;">
                            <button class="guide-btn primary" id="exportCopyBtn" style="flex:1;background:#f59e0b;">📋 复制文案</button>
                        </div>
                    </div>
                `;
                openGuideView('📥 导出报告', '选择导出格式', html, '<button class="guide-btn secondary" id="closeExportBtn">取消</button>');
                // 全部片区时禁用导出图片按钮
                const isAllAreas = !selectedArea && !selectedStore;
                const imgBtn = document.getElementById('exportImageBtn');
                if (isAllAreas && imgBtn) {
                    imgBtn.disabled = true;
                    imgBtn.style.opacity = '0.4';
                    imgBtn.style.cursor = 'not-allowed';
                    imgBtn.style.background = '#9ca3af';
                    imgBtn.title = '全部片区时暂不支持导出图片';
                }
                document.getElementById('exportImageBtn').addEventListener('click', () => { exportReport(); });
                document.getElementById('exportTableBtn').addEventListener('click', () => { exportTable(); });
                document.getElementById('exportCopyBtn').addEventListener('click', () => { exportCopyText(); });
                document.getElementById('closeExportBtn').addEventListener('click', () => { guideOverlay.style.display = 'none'; });
            }

            function exportReport() {
                guideOverlay.style.display = 'none';
                toast('⏳ 正在生成报告图片...');
                setTimeout(() => { generateModuleImages(); }, 300);
            }

            // 问单类目分析导出图片（直接截取当前网页DOM，高清输出）
            async function exportAnalysisImages() {
                // 关闭所有可能遮挡的UI层
                $('#headerMenuDropdown').classList.remove('show');
                $('#settingModalOverlay').classList.remove('show');
                $('#toast').classList.remove('show');

                // 确保分析页面可见
                if (!isAnalysisPageVisible) {
                    showAnalysisPage();
                }

                const safeName = getExportStoreName().replace(/[\\/:*?"<>|]/g, '');
                const dateRangeStr = getExportDateRangeStr();
                const timestampStr = getTimestampStr();
                const originalType = currentAnalysisType;
                let exportedCount = 0;

                // 先显示toast，等待UI隐藏后再开始截图
                toast('⏳ 正在生成重点分析图片...');
                await new Promise(r => setTimeout(r, 100));
                // 截图前强制隐藏toast，避免蒙版干扰
                $('#toast').classList.remove('show');
                await new Promise(r => setTimeout(r, 300));

                try {
                    const statsPanel = $('#analysisStatsPanel');
                    const analysisPage = $('#analysisPage');
                    // 裁剪起点：统计面板顶部（去掉标题栏和切换栏）
                    const cropY = statsPanel.offsetTop - 8;

                    // 导出冷链化冻
                    switchAnalysisType('coldThaw');
                    await new Promise(r => setTimeout(r, 600));

                    const coldCanvas = await htmlToImage.toCanvas(analysisPage, {
                        pixelRatio: 2,
                        backgroundColor: '#f3f4f9'
                    });
                    const coldCropped = cropCanvas(coldCanvas, 0, cropY, coldCanvas.width, coldCanvas.height - cropY);
                    downloadCanvas(coldCropped, `${safeName}-冷链化冻类目分析-${dateRangeStr}-${timestampStr}.png`);
                    exportedCount++;

                    // 导出物流损
                    switchAnalysisType('logistics');
                    await new Promise(r => setTimeout(r, 600));

                    const logCanvas = await htmlToImage.toCanvas(analysisPage, {
                        pixelRatio: 2,
                        backgroundColor: '#f3f4f9'
                    });
                    const logCropped = cropCanvas(logCanvas, 0, cropY, logCanvas.width, logCanvas.height - cropY);
                    downloadCanvas(logCropped, `${safeName}-物流损类目分析-${dateRangeStr}-${timestampStr}.png`);
                    exportedCount++;

                    // 导出问单
                    switchAnalysisType('order');
                    await new Promise(r => setTimeout(r, 600));

                    const orderCanvas = await htmlToImage.toCanvas(analysisPage, {
                        pixelRatio: 2,
                        backgroundColor: '#f3f4f9'
                    });
                    const orderCropped = cropCanvas(orderCanvas, 0, cropY, orderCanvas.width, orderCanvas.height - cropY);
                    downloadCanvas(orderCropped, `${safeName}-重点分析-${dateRangeStr}-${timestampStr}.png`);
                    exportedCount++;

                    // 导出差评
                    switchAnalysisType('badReview');
                    await new Promise(r => setTimeout(r, 600));

                    const badCanvas = await htmlToImage.toCanvas(analysisPage, {
                        pixelRatio: 2,
                        backgroundColor: '#f3f4f9'
                    });
                    const badCropped = cropCanvas(badCanvas, 0, cropY, badCanvas.width, badCanvas.height - cropY);
                    downloadCanvas(badCropped, `${safeName}-差评类目分析-${dateRangeStr}-${timestampStr}.png`);
                    exportedCount++;

                    toast('✅ 已导出 ' + exportedCount + ' 张重点分析图片');
                } catch(err) {
                    console.error(err);
                    toast('❌ 导出失败：' + err.message);
                } finally {
                    // 恢复原始视图
                    if (currentAnalysisType !== originalType) {
                        switchAnalysisType(originalType);
                    }
                }
            }

            // canvas裁剪工具
            function cropCanvas(canvas, x, y, width, height) {
                const cropped = document.createElement('canvas');
                cropped.width = width;
                cropped.height = height;
                const ctx = cropped.getContext('2d');
                ctx.drawImage(canvas, x, y, width, height, 0, 0, width, height);
                return cropped;
            }

            // canvas下载工具
            function downloadCanvas(canvas, fileName) {
                const link = document.createElement('a');
                link.download = fileName;
                link.href = canvas.toDataURL('image/png');
                link.click();
            }

            // 复制文案功能
            function exportCopyText() {
                guideOverlay.style.display = 'none';
                const text = buildCopyText();
                navigator.clipboard.writeText(text).then(() => {
                    toast('✅ 文案已复制到剪贴板');
                }).catch(() => {
                    toast('❌ 复制失败，请手动复制');
                });
            }

            // 构建复制文案
            function buildCopyText() {
                const areaName = selectedArea || '全部片区';
                const currentAchData = getCurrentAchievements();

                // 不达标门店列表
                let nonCompliantStores = [];
                let stores = [];
                if (selectedArea) {
                    stores = getAreaStores(selectedArea);
                } else if (selectedStore) {
                    stores = [selectedStore];
                } else {
                    stores = getAllAreaStores();
                }

                if (achievementCategories.length && stores.length) {
                    const firstCatKey = achievementCategories[0];
                    stores.forEach(sn => {
                        const sd = currentAchData[sn];
                        if (!sd) return;
                        const val = sd.achievements[firstCatKey] || 0;
                        const isQzc = sn.includes('前置仓');
                        const lim = isQzc ? (qianzhicangLimits[firstCatKey] || 0) : (shengxianLimits[firstCatKey] || 0);
                        if (lim > 0 && val > lim) {
                            nonCompliantStores.push(sn);
                        }
                    });
                }

                // 各类数据条数
                let filterStoreSet = null;
                if (selectedStore) {
                    filterStoreSet = new Set([selectedStore]);
                } else if (selectedArea) {
                    filterStoreSet = new Set(getAreaStores(selectedArea));
                }

                const storeFilter = (r, colName) => {
                    if (!filterStoreSet) return true;
                    return filterStoreSet.has(String(getColValue(r, colName) || '').trim());
                };

                const logisticsCount = logisticsData.filter(r => storeFilter(r, '门店名称')).length;
                const coldThawCount = coldThawData.filter(r => storeFilter(r, '门店名称')).length;
                const badReviewCount = badReviewData.filter(r => storeFilter(r, '门店')).length;

                // 统计各门店物流损条数
                const logisticsStoreCounts = {};
                logisticsData.filter(r => storeFilter(r, '门店名称')).forEach(r => {
                    const sn = String(getColValue(r, '门店名称') || '').trim();
                    logisticsStoreCounts[sn] = (logisticsStoreCounts[sn] || 0) + 1;
                });
                const logisticsStoreList = Object.entries(logisticsStoreCounts)
                    .sort((a, b) => b[1] - a[1])
                    .map(([sn, cnt]) => `        ${sn}${cnt}条`)
                    .join('\n');

                // 统计各门店冷链条数
                const coldThawStoreCounts = {};
                coldThawData.filter(r => storeFilter(r, '门店名称')).forEach(r => {
                    const sn = String(getColValue(r, '门店名称') || '').trim();
                    coldThawStoreCounts[sn] = (coldThawStoreCounts[sn] || 0) + 1;
                });
                const coldThawStoreList = Object.entries(coldThawStoreCounts)
                    .sort((a, b) => b[1] - a[1])
                    .map(([sn, cnt]) => `        ${sn}${cnt}条`)
                    .join('\n');

                // 统计各门店差评条数
                const badReviewStoreCounts = {};
                badReviewData.filter(r => storeFilter(r, '门店')).forEach(r => {
                    const sn = String(getColValue(r, '门店') || '').trim();
                    badReviewStoreCounts[sn] = (badReviewStoreCounts[sn] || 0) + 1;
                });
                const badReviewStoreList = Object.entries(badReviewStoreCounts)
                    .sort((a, b) => b[1] - a[1])
                    .map(([sn, cnt]) => `        ${sn}${cnt}条`)
                    .join('\n');

                const dateRangeInfo = getDateRangeInfo();
                const dateStr = dateRangeInfo.range || getYesterdayDateStr();
                let text = `${areaName} ${dateStr}问单达成明细\n\n`;
                text += `不达标门店\n`;
                if (nonCompliantStores.length) {
                    text += nonCompliantStores.join('\n') + '\n';
                }
                text += `\n物流损${logisticsCount}条\n\n`;
                text += `冷链商品化冻${coldThawCount}条\n`;
                if (coldThawStoreList) text += coldThawStoreList + '\n';
                text += `\n差评${badReviewCount}条\n`;
                if (badReviewStoreList) text += badReviewStoreList + '\n';

                return text;
            }

            // 导出表格功能（xlsx格式）
            function exportTable() {
                guideOverlay.style.display = 'none';
                toast('⏳ 正在生成Excel表格...');
                setTimeout(() => { generateModuleExcel(); }, 300);
            }

            // 导出片区-门店映射表（所属片区 + 门店名）
            function exportAreaStoreMap() {
                if (!areaNames.length) { toast('暂无片区数据'); return; }
                const aoa = [['所属片区', '门店']];
                areaNames.forEach(area => {
                    (areaStoreMap[area] || []).forEach(store => {
                        aoa.push([area, store]);
                    });
                });
                const wb = XLSX.utils.book_new();
                const ws = XLSX.utils.aoa_to_sheet(aoa);
                ws['!cols'] = [{ wch: 14 }, { wch: 20 }];
                XLSX.utils.book_append_sheet(wb, ws, '片区门店映射');
                const now = new Date();
                const ym = String(now.getFullYear()).slice(-2);
                const d6 = ym + String(now.getMonth() + 1).padStart(2, '0') + String(now.getDate()).padStart(2, '0');
                XLSX.writeFile(wb, `片区明细-${d6}.xlsx`);
                toast(`✅ 已导出 ${aoa.length - 1} 条门店数据`);
            }

            // 生成Excel工作簿
            function generateModuleExcel() {
                const safeName = getExportStoreName().replace(/[\\/:*?"<>|]/g, '');
                const dateRangeStr = getExportDateRangeStr();
                const timestampStr = getTimestampStr();

                try {
                    const wb = XLSX.utils.book_new();

                    // 1. 全部问单数据工作表（排除差评，包含物流损、冷链化冻及其他所有问题原因）
                    const allQData = buildAllQuestionsSheetData();
                    if (allQData.length) {
                        const ws0 = XLSX.utils.aoa_to_sheet(allQData);
                        XLSX.utils.book_append_sheet(wb, ws0, '全部问单数据');
                    }

                    // 2. 差评数据工作表
                    const brData = buildBadReviewSheetData();
                    if (brData.length) {
                        const ws1 = XLSX.utils.aoa_to_sheet(brData);
                        XLSX.utils.book_append_sheet(wb, ws1, '差评数据');
                    }

                    // 3. 冷链化冻工作表
                    const ctData = buildColdThawSheetData();
                    if (ctData.length) {
                        const ws2 = XLSX.utils.aoa_to_sheet(ctData);
                        XLSX.utils.book_append_sheet(wb, ws2, '冷链化冻');
                    }

                    // 4. 物流损工作表
                    const wsData = buildWuliusunSheetData();
                    if (wsData.length) {
                        const ws3 = XLSX.utils.aoa_to_sheet(wsData);
                        XLSX.utils.book_append_sheet(wb, ws3, '物流损');
                    }

                    // 5. 问单达成情况 → 拆分为"日达成数据"和"汇总达成"两个工作表
                    const achDataAll = buildAchievementSheetData();
                    if (achDataAll.length) {
                        // 分离日达成数据和汇总数据
                        const dailyRows = [];
                        const summaryRows = [];
                        const masterHeader = achDataAll[0]; // 全局表头

                        if (isMultiFile) {
                            // 多文件模式：数据格式为 [全局表头, [快照1表头, 数据行...], [快照2表头, 数据行...], ..., [汇总表头, 汇总数据行...]]
                            // 每个块的表头行内容与 masterHeader 完全一致
                            const isHeaderRow = (row) => row.length === masterHeader.length && row.every((v, i) => v === masterHeader[i]);

                            // 将数据按表头分隔成多个块
                            const blocks = [];
                            let currentBlock = [];
                            for (let i = 1; i < achDataAll.length; i++) {
                                const row = achDataAll[i];
                                if (isHeaderRow(row)) {
                                    if (currentBlock.length) blocks.push(currentBlock);
                                    currentBlock = [];
                                } else {
                                    currentBlock.push(row);
                                }
                            }
                            if (currentBlock.length) blocks.push(currentBlock);

                            // 按第一列是否为"汇总"分类
                            blocks.forEach(block => {
                                const firstCol = block[0] ? block[0][0] : '';
                                if (firstCol === '汇总' || firstCol === '生鲜店（总）' || firstCol === '前置仓（总）') {
                                    summaryRows.push(...block);
                                } else {
                                    dailyRows.push(...block);
                                }
                            });
                        } else {
                            // 单文件模式：全部数据都是汇总
                            summaryRows.push(...achDataAll.slice(1));
                        }

                        // 日达成数据工作表
                        if (dailyRows.length) {
                            const wsDaily = XLSX.utils.aoa_to_sheet([masterHeader, ...dailyRows]);
                            XLSX.utils.book_append_sheet(wb, wsDaily, '日达成数据');
                        }

                        // 汇总达成工作表
                        if (summaryRows.length) {
                            const wsSummary = XLSX.utils.aoa_to_sheet([masterHeader, ...summaryRows]);
                            XLSX.utils.book_append_sheet(wb, wsSummary, '汇总达成');
                        }

                        // 兜底：如果没有分拆成功，保留原行为
                        if (!dailyRows.length && !summaryRows.length) {
                            const ws4 = XLSX.utils.aoa_to_sheet(achDataAll);
                            XLSX.utils.book_append_sheet(wb, ws4, '日达成数据');
                        }
                    }

                    // 导出文件：片区-问单数据-统计时间-时间戳.xlsx
                    XLSX.writeFile(wb, `${safeName}-问单数据-${dateRangeStr}-${timestampStr}.xlsx`);
                    toast('✅ 已导出Excel表格');
                } catch(err) {
                    console.error(err);
                    toast('❌ 导出失败：' + err.message);
                }
            }

            // 构建差评数据（按门店名称排序）
            function buildBadReviewSheetData() {
                if (!badReviewData.length) return [];

                // 构建门店→片区映射
                const storeAreaMap = {};
                for (const [area, stores] of Object.entries(areaStoreMap)) {
                    stores.forEach(s => { storeAreaMap[s] = area; });
                }

                const isAllAreas = !selectedArea && !selectedStore;
                let filtered;
                if (selectedStore) {
                    filtered = badReviewData.filter(r => String(getColValue(r,'门店')||'').trim() === selectedStore);
                } else if (selectedArea) {
                    const stores = getAreaStores(selectedArea);
                    filtered = badReviewData.filter(r => stores.includes(String(getColValue(r,'门店')||'').trim()));
                } else {
                    const allStores = getAllAreaStores();
                    filtered = badReviewData.filter(r => allStores.includes(String(getColValue(r,'门店')||'').trim()));
                }
                if (!filtered.length) return [];

                // 按门店名称排序（全部片区时按片区+门店名称排序）
                filtered.sort((a, b) => {
                    const sa = String(getColValue(a,'门店')||'').trim();
                    const sb = String(getColValue(b,'门店')||'').trim();
                    if (isAllAreas) {
                        const areaA = storeAreaMap[sa] || '';
                        const areaB = storeAreaMap[sb] || '';
                        const cmp = areaA.localeCompare(areaB, 'zh-CN');
                        if (cmp !== 0) return cmp;
                    }
                    return sa.localeCompare(sb, 'zh-CN');
                });

                const hasAreaCol = isAllAreas;
                const headerRow = hasAreaCol
                    ? ['归属片区', '评价日期', '门店名称', '配送员id', '配送员名', '履约单号', '评价文本', '评价标签']
                    : ['评价日期', '门店名称', '配送员id', '配送员名', '履约单号', '评价文本', '评价标签'];
                const rows = [headerRow];

                filtered.forEach(row => {
                    const sn = String(getColValue(row,'门店')||'').trim();
                    const rowData = [];
                    if (hasAreaCol) rowData.push(storeAreaMap[sn] || '');
                    rowData.push(
                        getColValue(row,'评价日期')||getColValue(row,'交易日期')||'',
                        sn,
                        getColValue(row,'配送员')||getColValue(row,'配送员id')||'',
                        getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'',
                        getColValue(row,'配送单号')||getColValue(row,'履约单号')||getColValue(row,'评价父订单')||'',
                        getColValue(row,'评价文本')||'',
                        getColValue(row,'评价标签')||''
                    );
                    rows.push(rowData);
                });
                return rows;
            }

            // 构建冷链化冻数据（按门店名称排序）
            function buildColdThawSheetData() {
                if (!coldThawData.length) return [];

                // 构建门店→片区映射
                const storeAreaMap = {};
                for (const [area, stores] of Object.entries(areaStoreMap)) {
                    stores.forEach(s => { storeAreaMap[s] = area; });
                }

                const isAllAreas = !selectedArea && !selectedStore;
                let filtered;
                if (selectedStore) {
                    filtered = coldThawData.filter(r => String(getColValue(r,'门店名称')||'').trim() === selectedStore);
                } else if (selectedArea) {
                    const stores = getAreaStores(selectedArea);
                    filtered = coldThawData.filter(r => stores.includes(String(getColValue(r,'门店名称')||'').trim()));
                } else {
                    const allStores = getAllAreaStores();
                    filtered = coldThawData.filter(r => allStores.includes(String(getColValue(r,'门店名称')||'').trim()));
                }
                if (!filtered.length) return [];

                // 按门店名称排序（全部片区时按片区+门店名称排序）
                filtered.sort((a, b) => {
                    const sa = String(getColValue(a,'门店名称')||'').trim();
                    const sb = String(getColValue(b,'门店名称')||'').trim();
                    if (isAllAreas) {
                        const areaA = storeAreaMap[sa] || '';
                        const areaB = storeAreaMap[sb] || '';
                        const cmp = areaA.localeCompare(areaB, 'zh-CN');
                        if (cmp !== 0) return cmp;
                    }
                    return sa.localeCompare(sb, 'zh-CN');
                });

                const hasAreaCol = isAllAreas;
                const headerRow = hasAreaCol
                    ? ['归属片区', '日期', 'SKU名称', '门店名称', '配送单号', '配送员名', 'APP退款原因', 'APP退款描述']
                    : ['日期', 'SKU名称', '门店名称', '配送单号', '配送员名', 'APP退款原因', 'APP退款描述'];
                const rows = [headerRow];

                filtered.forEach(row => {
                    const sn = String(getColValue(row,'门店名称')||'').trim();
                    const rowData = [];
                    if (hasAreaCol) rowData.push(storeAreaMap[sn] || '');
                    rowData.push(
                        getColValue(row,'日期')||'',
                        getColValue(row,'sku名称')||getColValue(row,'SKU名称')||'',
                        sn,
                        getColValue(row,'配送单号')||getColValue(row,'淘系主订单id')||'',
                        getColValue(row,'配送员名')||getColValue(row,'配送员名称')||'',
                        getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')||'',
                        getAppRefundDesc(row)
                    );
                    rows.push(rowData);
                });
                return rows;
            }

            // 构建物流损数据（按门店名称排序）
            function buildWuliusunSheetData() {
                if (!logisticsData.length) return [];

                // 构建门店→片区映射
                const storeAreaMap = {};
                for (const [area, stores] of Object.entries(areaStoreMap)) {
                    stores.forEach(s => { storeAreaMap[s] = area; });
                }

                const isAllAreas = !selectedArea && !selectedStore;
                let filtered;
                if (selectedStore) {
                    filtered = logisticsData.filter(r => String(getColValue(r,'门店名称')||'').trim() === selectedStore);
                } else if (selectedArea) {
                    const stores = getAreaStores(selectedArea);
                    filtered = logisticsData.filter(r => stores.includes(String(getColValue(r,'门店名称')||'').trim()));
                } else {
                    const allStores = getAllAreaStores();
                    filtered = logisticsData.filter(r => allStores.includes(String(getColValue(r,'门店名称')||'').trim()));
                }
                if (!filtered.length) return [];

                // 按门店名称排序（全部片区时按片区+门店名称排序）
                filtered.sort((a, b) => {
                    const sa = String(getColValue(a,'门店名称')||'').trim();
                    const sb = String(getColValue(b,'门店名称')||'').trim();
                    if (isAllAreas) {
                        const areaA = storeAreaMap[sa] || '';
                        const areaB = storeAreaMap[sb] || '';
                        const cmp = areaA.localeCompare(areaB, 'zh-CN');
                        if (cmp !== 0) return cmp;
                    }
                    return sa.localeCompare(sb, 'zh-CN');
                });

                const hasAreaCol = isAllAreas;
                const headerRow = hasAreaCol
                    ? ['归属片区', '门店', '问题原因名称', 'SKU名称', 'APP退款原因', 'APP退款描述', '单号', '责任人']
                    : ['门店', '问题原因名称', 'SKU名称', 'APP退款原因', 'APP退款描述', '单号', '责任人'];
                const rows = [headerRow];

                filtered.forEach(row => {
                    const sn = String(getColValue(row,'门店名称')||'').trim();
                    const orderFields = ['淘系主订单id'];
                    const orderVals = orderFields.map(f => getColValue(row,f)||'').filter(v=>String(v).trim()).join(' / ');
                    const delivery = String(getColValue(row,'配送员名')||'').trim();
                    const rowData = [];
                    if (hasAreaCol) rowData.push(storeAreaMap[sn] || '');
                    rowData.push(
                        sn,
                        getColValue(row,'问题原因名称')||'',
                        getColValue(row,'sku名称')||getColValue(row,'SKU名称')||'',
                        getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')||'',
                        getAppRefundDesc(row),
                        orderVals || '-',
                        delivery && delivery!=='-' ? delivery : '-'
                    );
                    rows.push(rowData);
                });
                return rows;
            }

            // 构建全部问单数据（排除差评，包含物流损、冷链化冻及其他所有问题原因）
            function buildAllQuestionsSheetData() {
                if (!allData.length) return [];

                // 构建门店→片区映射
                const storeAreaMap = {};
                for (const [area, stores] of Object.entries(areaStoreMap)) {
                    stores.forEach(s => { storeAreaMap[s] = area; });
                }

                // 建立差评数据的配送单号集合（用于排除）
                const badReviewOrderSet = new Set();
                badReviewData.forEach(r => {
                    const orderId = String(getColValue(r,'配送单号')||getColValue(r,'履约单号')||getColValue(r,'评价父订单')||'').trim();
                    if (orderId) badReviewOrderSet.add(orderId);
                });

                const isAllAreas = !selectedArea && !selectedStore;

                // 筛选：片区/门店 + 排除差评
                let filtered = allData.filter(r => {
                    const sn = String(getColValue(r,'门店名称')||'').trim();
                    // 片区/门店筛选
                    if (selectedStore && sn !== selectedStore) return false;
                    if (selectedArea) {
                        const areaStores = getAreaStores(selectedArea);
                        if (!areaStores.includes(sn)) return false;
                    }
                    if (!selectedArea && !selectedStore) {
                        const allStores = getAllAreaStores();
                        if (!allStores.includes(sn)) return false;
                    }
                    // 排除差评：问题原因名称=差评 或 配送单号在差评集合中
                    const reason = String(getColValue(r,'问题原因名称')||'').trim();
                    if (reason === '差评') return false;
                    const orderId = String(getColValue(r,'配送单号')||'').trim();
                    if (orderId && badReviewOrderSet.has(orderId)) return false;
                    return true;
                });

                if (!filtered.length) return [];

                // 按门店名称排序（全部片区时按片区+门店名称排序）
                filtered.sort((a, b) => {
                    const sa = String(getColValue(a,'门店名称')||'').trim();
                    const sb = String(getColValue(b,'门店名称')||'').trim();
                    if (isAllAreas) {
                        const areaA = storeAreaMap[sa] || '';
                        const areaB = storeAreaMap[sb] || '';
                        const cmp = areaA.localeCompare(areaB, 'zh-CN');
                        if (cmp !== 0) return cmp;
                    }
                    return sa.localeCompare(sb, 'zh-CN');
                });

                const hasAreaCol = isAllAreas;
                const headerRow = hasAreaCol
                    ? ['归属片区', '日期', '问题原因名称', 'sku名称', 'app退款原因', '退款/工单/评价备注', '退款凭证', '门店名称', '淘系主订单id', '配送站名称', '批次号', '配送单号', '拣货员名', '配送员名', '打包员名']
                    : ['日期', '问题原因名称', 'sku名称', 'app退款原因', '退款/工单/评价备注', '退款凭证', '门店名称', '淘系主订单id', '配送站名称', '批次号', '配送单号', '拣货员名', '配送员名', '打包员名'];
                const rows = [headerRow];

                filtered.forEach(row => {
                    const sn = String(getColValue(row,'门店名称')||'').trim();

                    const rowData = [];
                    if (hasAreaCol) rowData.push(storeAreaMap[sn] || '');
                    rowData.push(
                        getColValue(row,'日期')||'',
                        getColValue(row,'问题原因名称')||'',
                        getColValue(row,'sku名称')||getColValue(row,'SKU名称')||'',
                        getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')||'',
                        getAppRefundDesc(row),
                        getColValue(row,'退款凭证')||'',
                        sn,
                        getColValue(row,'淘系主订单id')||'',
                        getColValue(row,'配送站名称')||'',
                        getColValue(row,'批次号')||'',
                        getColValue(row,'配送单号')||'',
                        getColValue(row,'拣货员名')||'',
                        getColValue(row,'配送员名')||'',
                        getColValue(row,'打包员名')||''
                    );
                    rows.push(rowData);
                });
                return rows;
            }

            // 构建问单达成情况数据（仅输出指定类目列：1,2,3,13-26，即索引0,1,2,12-25）
            function buildAchievementSheetData() {
                if (!achievementCategories.length) return [];

                // 构建门店→片区映射
                const storeAreaMap = {};
                for (const [area, stores] of Object.entries(areaStoreMap)) {
                    stores.forEach(s => { storeAreaMap[s] = area; });
                }

                const isAllAreas = !selectedArea && !selectedStore;
                const currentAchData = getCurrentAchievements();

                let stores = [];
                if (selectedStore) {
                    stores = [selectedStore];
                } else if (selectedArea) {
                    stores = getAreaStores(selectedArea);
                } else {
                    // 全部片区：仅收集片区映射中的门店
                    stores = getAllAreaStores();
                }
                if (!stores.length) return [];

                // 仅输出指定类目列：1,2,3,13-26（索引0,1,2,12-25）
                const targetIndices = [0, 1, 2, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25];
                const targetCategories = targetIndices.filter(i => i < achievementCategories.length).map(i => achievementCategories[i]);

                // 表头：门店 + 达成情况 + 类目名
                const hasAreaCol = isAllAreas;
                const hasTimeCol = isMultiFile; // 多文件时首列增加时间列
                const headerRow = hasTimeCol
                    ? (hasAreaCol ? ['时间', '归属片区', '门店', '达成情况'] : ['时间', '门店', '达成情况'])
                    : (hasAreaCol ? ['归属片区', '门店', '达成情况'] : ['门店', '达成情况']);
                targetCategories.forEach(ck => {
                    const dn = categoryKeyToDisplay.get(ck) || ck;
                    const short = dn.includes('｜') ? dn.split('｜')[0] : dn;
                    headerRow.push(short);
                });

                const allRows = [];

                // ===== 多文件模式：先输出每个文件（每日）的数据 =====
                if (isMultiFile && dailyAchievementSnapshots.length > 0) {
                    dailyAchievementSnapshots.forEach((snapshot, snapIdx) => {
                        const snapAchData = snapshot.storeAchievements;
                        const dateLabel = snapshot.date || ('文件' + (snapIdx + 1));

                        // 表头行
                        allRows.push([...headerRow]);

                        // 获取该快照中在筛选范围内的门店
                        const snapStores = stores.filter(sn => snapAchData[sn]);
                        const getFirstVal = (sn, achData) => {
                            const sd = achData[sn];
                            if (!sd || !achievementCategories.length) return 0;
                            return sd.achievements[achievementCategories[0]] || 0;
                        };
                        const sorted = [...snapStores].sort((a,b) => getFirstVal(b, snapAchData) - getFirstVal(a, snapAchData));
                        const sx = sorted.filter(s => !s.includes('前置仓'));
                        const qzc = sorted.filter(s => s.includes('前置仓'));

                        const isCompliantSnap = (sn, isQzc, achData) => {
                            const sd = achData[sn];
                            if (!sd || !achievementCategories.length) return '达标';
                            const firstCatKey = achievementCategories[0];
                            const val = sd.achievements[firstCatKey] || 0;
                            const lim = isQzc ? (qianzhicangLimits[firstCatKey] || 0) : (shengxianLimits[firstCatKey] || 0);
                            if (lim > 0 && val > lim) return '不达标';
                            return '达标';
                        };

                        // 生鲜店数据
                        sx.forEach(sn => {
                            const sd = snapAchData[sn];
                            if (!sd) return;
                            const ach = sd.achievements;
                            const dataRow = [dateLabel]; // 时间列
                            if (hasAreaCol) dataRow.push(storeAreaMap[sn] || '');
                            dataRow.push(sn, isCompliantSnap(sn, false, snapAchData));
                            targetCategories.forEach(ck => { dataRow.push(ach[ck] || 0); });
                            allRows.push(dataRow);
                        });

                        // 前置仓数据
                        qzc.forEach(sn => {
                            const sd = snapAchData[sn];
                            if (!sd) return;
                            const ach = sd.achievements;
                            const dataRow = [dateLabel]; // 时间列
                            if (hasAreaCol) dataRow.push(storeAreaMap[sn] || '');
                            dataRow.push(sn, isCompliantSnap(sn, true, snapAchData));
                            targetCategories.forEach(ck => { dataRow.push(ach[ck] || 0); });
                            allRows.push(dataRow);
                        });
                    });
                }

                // ===== 汇总/单文件数据 =====
                allRows.push([...headerRow]);

                const getFirstVal = (sn) => {
                    const sd = currentAchData[sn];
                    if (!sd || !achievementCategories.length) return 0;
                    return sd.achievements[achievementCategories[0]] || 0;
                };

                // 按片区+门店名称排序（全部片区时）
                let sorted;
                if (isAllAreas) {
                    sorted = [...stores].sort((a, b) => {
                        const areaA = storeAreaMap[a] || '';
                        const areaB = storeAreaMap[b] || '';
                        const cmp = areaA.localeCompare(areaB, 'zh-CN');
                        if (cmp !== 0) return cmp;
                        return a.localeCompare(b, 'zh-CN');
                    });
                } else {
                    sorted = [...stores].sort((a,b) => getFirstVal(b) - getFirstVal(a));
                }
                const sx = sorted.filter(s => !s.includes('前置仓'));
                const qzc = sorted.filter(s => s.includes('前置仓'));

                // 判断是否达标
                const isCompliant = (sn, isQzc) => {
                    const sd = currentAchData[sn];
                    if (!sd || !achievementCategories.length) return '达标';
                    const firstCatKey = achievementCategories[0];
                    const val = sd.achievements[firstCatKey] || 0;
                    const lim = isQzc ? (qianzhicangLimits[firstCatKey] || 0) : (shengxianLimits[firstCatKey] || 0);
                    if (lim > 0 && val > lim) return '不达标';
                    return '达标';
                };

                // ---- 汇总行：片区级别的生鲜店/前置仓汇总 ----
                // 汇总行达标判断：生鲜店用shengxianLimits，前置仓用qianzhicangLimits
                const isSummaryCompliant = (summaryAch, isQzc) => {
                    if (!achievementCategories.length) return '';
                    const firstCatKey = achievementCategories[0];
                    const val = summaryAch[firstCatKey] || 0;
                    const lim = isQzc ? (qianzhicangLimits[firstCatKey] || 0) : (shengxianLimits[firstCatKey] || 0);
                    if (lim > 0 && val > lim) return '不达标';
                    return '达标';
                };

                const summaryAreas = isAllAreas ? areaNames : (selectedArea ? [selectedArea] : []);
                summaryAreas.forEach(an => {
                    const areaSxStores = (selectedArea ? getAreaStores(selectedArea) : getAreaStores(an)).filter(s => !s.includes('前置仓'));
                    const areaQzcStores = (selectedArea ? getAreaStores(selectedArea) : getAreaStores(an)).filter(s => s.includes('前置仓'));
                    const sxSummary = computeSummaryAchievements(areaSxStores);
                    const qzcSummary = computeSummaryAchievements(areaQzcStores);
                    if (sxSummary) {
                        const dataRow = [];
                        if (hasTimeCol) dataRow.push('汇总');
                        if (hasAreaCol) dataRow.push(an); // 归属片区 = 片区名
                        dataRow.push(an + '生鲜店', isSummaryCompliant(sxSummary, false));
                        targetCategories.forEach(ck => { dataRow.push(sxSummary[ck] || 0); });
                        allRows.push(dataRow);
                    }
                    if (qzcSummary) {
                        const dataRow = [];
                        if (hasTimeCol) dataRow.push('汇总');
                        if (hasAreaCol) dataRow.push(an); // 归属片区 = 片区名
                        dataRow.push(an + '前置仓', isSummaryCompliant(qzcSummary, true));
                        targetCategories.forEach(ck => { dataRow.push(qzcSummary[ck] || 0); });
                        allRows.push(dataRow);
                    }
                });

                // 全部片区模式下，额外输出"生鲜店""前置仓"总汇总行
                if (isAllAreas) {
                    const allSx = getAllAreaStores().filter(s => !s.includes('前置仓'));
                    const allQzc = getAllAreaStores().filter(s => s.includes('前置仓'));
                    const allSxSummary = computeSummaryAchievements(allSx);
                    const allQzcSummary = computeSummaryAchievements(allQzc);
                    if (allSxSummary) {
                        const dataRow = [];
                        if (hasTimeCol) dataRow.push('生鲜店（总）');
                        if (hasAreaCol) dataRow.push('子公司');
                        dataRow.push('生鲜店', isSummaryCompliant(allSxSummary, false));
                        targetCategories.forEach(ck => { dataRow.push(allSxSummary[ck] || 0); });
                        allRows.push(dataRow);
                    }
                    if (allQzcSummary) {
                        const dataRow = [];
                        if (hasTimeCol) dataRow.push('前置仓（总）');
                        if (hasAreaCol) dataRow.push('子公司');
                        dataRow.push('前置仓', isSummaryCompliant(allQzcSummary, true));
                        targetCategories.forEach(ck => { dataRow.push(allQzcSummary[ck] || 0); });
                        allRows.push(dataRow);
                    }
                }

                // ---- 门店明细数据 ----
                // 生鲜店数据
                sx.forEach(sn => {
                    const sd = currentAchData[sn];
                    if (!sd) return;
                    const ach = sd.achievements;
                    const dataRow = [];
                    if (hasTimeCol) dataRow.push('汇总'); // 汇总行时间列
                    if (hasAreaCol) dataRow.push(storeAreaMap[sn] || '');
                    dataRow.push(sn, isCompliant(sn, false));
                    targetCategories.forEach(ck => { dataRow.push(ach[ck] || 0); });
                    allRows.push(dataRow);
                });

                // 前置仓数据
                qzc.forEach(sn => {
                    const sd = currentAchData[sn];
                    if (!sd) return;
                    const ach = sd.achievements;
                    const dataRow = [];
                    if (hasTimeCol) dataRow.push('汇总'); // 汇总行时间列
                    if (hasAreaCol) dataRow.push(storeAreaMap[sn] || '');
                    dataRow.push(sn, isCompliant(sn, true));
                    targetCategories.forEach(ck => { dataRow.push(ach[ck] || 0); });
                    allRows.push(dataRow);
                });

                return allRows;
            }

            // 获取当前门店/片区名称（用于文件名）
            function getExportStoreName() {
                if (selectedStore) return selectedStore;
                if (selectedArea) return selectedArea;
                return '全部片区';
            }

            // 获取报告日期
            function getExportDateStr() {
                if (allData.length) {
                    for (const row of allData) {
                        const d = getColValue(row,'日期');
                        if (d) return String(d).trim();
                    }
                }
                return '--';
            }

            // 获取昨天的日期字符串（YYYYMMDD格式）
            function getYesterdayDateStr() {
                const yesterday = new Date();
                yesterday.setDate(yesterday.getDate() - 1);
                const y = yesterday.getFullYear();
                const m = String(yesterday.getMonth() + 1).padStart(2, '0');
                const d = String(yesterday.getDate()).padStart(2, '0');
                return `${y}${m}${d}`;
            }

            // 获取当前时间戳字符串（MMddHHMMSS格式）
            function getTimestampStr() {
                const now = new Date();
                const mm = String(now.getMonth() + 1).padStart(2, '0');
                const dd = String(now.getDate()).padStart(2, '0');
                const HH = String(now.getHours()).padStart(2, '0');
                const MM = String(now.getMinutes()).padStart(2, '0');
                const SS = String(now.getSeconds()).padStart(2, '0');
                return `${mm}${dd}${HH}${MM}${SS}`;
            }

            // 获取导出文件名中的统计时间部分
            function getExportDateRangeStr() {
                const info = getDateRangeInfo();
                return info.range || getYesterdayDateStr();
            }

            // 紧凑表格通用样式
            const COMPACT_TABLE_STYLE = `
                * { margin:0; padding:0; box-sizing:border-box; }
                body { font-family: 'Microsoft YaHei','PingFang SC',sans-serif; background:#fff; padding:0; }
                .wrap { padding:8px 10px; }
                table { width:auto; border-collapse:collapse; font-size:12px; }
                th,td { padding:3px 5px; border:1px solid #999; text-align:center; white-space:nowrap; }
                th { background:#e8e8e8; font-weight:700; color:#333; font-size:11px; }
                td { color:#222; font-size:11px; }
                .red { color:#c0392b; font-weight:700; }
                .gray { color:#999; }
                .orange-bg { background:#fff3e0; }
                .red-bg { background:#fde8e8; }
                .tag { display:inline-block; padding:1px 5px; border-radius:3px; font-size:10px; font-weight:600; }
                .tag-sx { background:#e0f2fe; color:#0369a1; }
                .tag-qzc { background:#fef3c7; color:#92400e; }
                .group-label { font-size:12px; font-weight:700; margin:6px 0 3px; color:#333; }
                .group-label:first-child { margin-top:0; }
                .table-container { margin:6px 0; }
                .table-sx { border:3px solid #3b82f6; border-radius:4px; }
                .table-qzc { border:3px solid #f59e0b; border-radius:4px; }
                .table-yellow { border:3px solid #f59e0b; border-radius:4px; }
                .table-blue { border:3px solid #3b82f6; border-radius:4px; }
                .table-red { border:3px solid #ef4444; border-radius:4px; }
                .divider-row td { border:none !important; background:transparent !important; height:6px; padding:0 !important; }
                .ach-table { border-collapse:collapse; }
                .ach-table th, .ach-table td { border:1px solid #999; }
                /* 生鲜店部分：只有外边框蓝色 */
                .ach-table thead th { background:#e8e8e8; }
                .ach-table .sx-first td { border-top:3px solid #3b82f6; }
                .ach-table .sx-last td { border-bottom:3px solid #3b82f6; }
                .ach-table .sx-row td:first-child { border-left:3px solid #3b82f6; }
                .ach-table .sx-row td:last-child { border-right:3px solid #3b82f6; }
                .ach-table thead th:first-child { border-left:3px solid #3b82f6; }
                .ach-table thead th:last-child { border-right:3px solid #3b82f6; }
                .ach-table thead th { border-top:3px solid #3b82f6; border-bottom:1px solid #999; }
                /* 前置仓部分：只有外边框橙色 */
                .ach-table .qzc-first td { border-top:3px solid #f59e0b; }
                .ach-table .qzc-last td { border-bottom:3px solid #f59e0b; }
                .ach-table .qzc-row td:first-child { border-left:3px solid #f59e0b; }
                .ach-table .qzc-row td:last-child { border-right:3px solid #f59e0b; }
                /* 分隔行：隐藏边框 */
                .ach-table .divider-row td { border:none !important; background:transparent !important; height:8px !important; }
                /* 问单类目分析紧凑样式 */
                .analysis-stats { font-size:12px; color:#333; font-weight:600; padding:6px 0; border-bottom:1px solid #ddd; margin-bottom:8px; }
                .analysis-title-bar { font-size:13px; font-weight:700; color:#1a1a2e; margin:8px 0 6px; display:flex; align-items:center; gap:6px; }
                .analysis-sub-title-bar { font-size:11px; font-weight:700; color:#4a4a65; margin:6px 0 4px; }
                .a-table { width:auto; border-collapse:collapse; font-size:11px; margin:4px 0; }
                .a-table th, .a-table td { padding:3px 6px; border:1px solid #999; text-align:center; white-space:nowrap; }
                .a-table th { background:#e8e8e8; font-weight:700; font-size:10px; color:#333; }
                .a-table td { color:#222; font-size:10px; }
                .a-table td.a-store { text-align:left; font-weight:600; }
                .a-table td.a-area { font-weight:600; }
                .a-table td.a-over { color:#c0392b; font-weight:700; }
                .a-rank-1 { color:#e6a23c; font-weight:750; }
                .a-rank-2 { color:#b0b0c0; font-weight:750; }
                .a-rank-3 { color:#cd7f32; font-weight:750; }
                .atag { display:inline-block; padding:1px 5px; border-radius:3px; font-size:9px; font-weight:600; }
                .atag-area { background:#e0f2fe; color:#0369a1; }
                .atag-store { background:#fef3c7; color:#92400e; }
                .section-blue { border-left:3px solid #06b6d4; padding-left:8px; margin:8px 0; }
                .section-red { border-left:3px solid #ef4444; padding-left:8px; margin:8px 0; }
                .section-purple { border-left:3px solid #8b5cf6; padding-left:8px; margin:8px 0; }
            `;

            // 构建紧凑达成情况表格HTML（一个大表格，上面生鲜店蓝色边框，下面前置仓橙色边框）
            function buildCompactAchievementHtml() {
                const currentAchData = getCurrentAchievements();
                let stores = [];
                if (selectedArea) stores = getAreaStores(selectedArea);
                else if (selectedStore) stores = [selectedStore];
                else stores = getAllAreaStores();
                if (!stores.length || !achievementCategories.length) return '';

                const getFirstVal = (sn) => {
                    const sd = currentAchData[sn];
                    if (!sd || !achievementCategories.length) return 0;
                    return sd.achievements[achievementCategories[0]] || 0;
                };
                const sorted = [...stores].sort((a,b) => getFirstVal(b) - getFirstVal(a));
                const sx = sorted.filter(s => !s.includes('前置仓'));
                const qzc = sorted.filter(s => s.includes('前置仓'));

                let html = '<div class="wrap">';

                // 热力图：生鲜店/前置仓分别独立计算范围
                const heatmapCount = 12;
                const catRangeSx = {};
                achievementCategories.forEach((ck, idx) => {
                    if (idx >= heatmapCount) return;
                    let vals = [];
                    sx.forEach(sn => {
                        const sd = currentAchData[sn];
                        if (!sd) return;
                        const v = sd.achievements[ck] || 0;
                        if (v > 0) vals.push(v);
                    });
                    catRangeSx[ck] = vals.length > 0 ? { min: Math.min(...vals), max: Math.max(...vals) } : { min: 0, max: 1 };
                });
                const catRangeQzc = {};
                achievementCategories.forEach((ck, idx) => {
                    if (idx >= heatmapCount) return;
                    let vals = [];
                    qzc.forEach(sn => {
                        const sd = currentAchData[sn];
                        if (!sd) return;
                        const v = sd.achievements[ck] || 0;
                        if (v > 0) vals.push(v);
                    });
                    catRangeQzc[ck] = vals.length > 0 ? { min: Math.min(...vals), max: Math.max(...vals) } : { min: 0, max: 1 };
                });

                // 热力图颜色：超标红、无上限最高黄、最低绿、0白底灰字
                const getHeatmapStyle = (val, lim, ck, idx, isQzc) => {
                    if (val === 0) return 'background:#fff;color:#999;';
                    let style = 'color:#000;font-weight:700;';
                    if (lim > 0 && val > lim) {
                        style = 'background:#FF4500;color:#fff;font-weight:700;';
                    } else if (idx < heatmapCount) {
                        const range = isQzc ? catRangeQzc[ck] : catRangeSx[ck];
                        if (!range || range.max <= range.min) return style;
                        const ratio = (val - range.min) / (range.max - range.min);
                        if (val === range.max && lim === 0) {
                            style += 'background:#FFD700;color:#000;';
                        } else {
                            const r = Math.round(255 * ratio + 29 * (1 - ratio));
                            const g = Math.round(215 * ratio + 185 * (1 - ratio));
                            const b = Math.round(0 * ratio + 84 * (1 - ratio));
                            style += 'background:rgb(' + r + ',' + g + ',' + b + ');';
                        }
                    }
                    return style;
                };

                // ---- 汇总达成行（导出图片专用） ----
                const getSummaryStyle = (val, lim) => {
                    if (val === 0) return 'color:#999;font-weight:700;';
                    if (lim > 0 && val > lim) return 'background:#FF4500;color:#fff;font-weight:700;';
                    return 'font-weight:700;';
                };

                const buildHeader = () => {
                    let h = '<tr style="background:#e8ebff;"><th style="white-space:nowrap;min-width:225px;">门店 <span class="limits-trigger" style="display:inline-block;width:12px;height:12px;line-height:12px;border-radius:50%;background:#e0e0e0;color:#888;font-size:0.5rem;font-weight:700;cursor:pointer;margin-left:3px;vertical-align:middle;text-align:center;pointer-events:auto;" title="查看类目上限值">!</span></th>';
                    achievementCategories.forEach(ck => {
                        const dn = categoryKeyToDisplay.get(ck) || ck;
                        const short = dn.includes('｜') ? dn.split('｜')[0] : dn;
                        h += '<th>' + escapeHTML(short) + '</th>';
                    });
                    h += '</tr>';
                    return h;
                };

                // 汇总达成表格
                if (selectedArea) {
                    const summarySx = computeSummaryAchievements(sx);
                    const summaryQzc = computeSummaryAchievements(qzc);
                    html += '<div class="table-container" style="border:3px solid #7c3aed;margin-bottom:12px;"><table>';
                    html += '<thead>' + buildHeader() + '</thead><tbody>';
                    if (summarySx) {
                        html += '<tr><td style="font-weight:700;text-align:left;background:#e8ebff;white-space:nowrap;min-width:225px;">' + escapeHTML(selectedArea + '生鲜店') + '</td>';
                        achievementCategories.forEach((ck, cidx) => {
                            const val = summarySx[ck] || 0;
                            const lim = shengxianLimits[ck] || 0;
                            html += '<td style="' + getSummaryStyle(val, lim) + '">' + formatAchievementValue(val, ck, summarySx, cidx) + '</td>';
                        });
                        html += '</tr>';
                    }
                    if (summaryQzc) {
                        html += '<tr><td style="font-weight:700;text-align:left;background:#e8ebff;white-space:nowrap;min-width:225px;">' + escapeHTML(selectedArea + '前置仓') + '</td>';
                        achievementCategories.forEach((ck, cidx) => {
                            const val = summaryQzc[ck] || 0;
                            const lim = qianzhicangLimits[ck] || 0;
                            html += '<td style="' + getSummaryStyle(val, lim) + '">' + formatAchievementValue(val, ck, summaryQzc, cidx) + '</td>';
                        });
                        html += '</tr>';
                    }
                    html += '</tbody></table></div>';
                } else if (!selectedStore && areaNames.length > 0) {
                    const allStoresList = getAllAreaStores();
                    const allSummarySx = computeSummaryAchievements(allStoresList.filter(s => !s.includes('前置仓')));
                    const allSummaryQzc = computeSummaryAchievements(allStoresList.filter(s => s.includes('前置仓')));

                    // 生鲜店片区热力范围
                    const sxAreaHeatmap = {};
                    const sxAreaDataMap = new Map();
                    areaNames.forEach(an => {
                        const ach = computeSummaryAchievements(getAreaStores(an).filter(s => !s.includes('前置仓')));
                        if (ach) sxAreaDataMap.set(an, ach);
                    });
                    achievementCategories.forEach((ck, idx) => {
                        if (idx >= heatmapCount) return;
                        let vals = [];
                        sxAreaDataMap.forEach(ach => { const v = ach[ck] || 0; if (v > 0) vals.push(v); });
                        if (vals.length > 0) { const minV = Math.min(...vals), maxV = Math.max(...vals); sxAreaHeatmap[ck] = maxV > minV ? { min: minV, max: maxV } : { min: 0, max: maxV }; }
                        else { sxAreaHeatmap[ck] = { min: 0, max: 1 }; }
                    });

                    // 前置仓片区热力范围
                    const qzcAreaHeatmap = {};
                    const qzcAreaDataMap = new Map();
                    areaNames.forEach(an => {
                        const ach = computeSummaryAchievements(getAreaStores(an).filter(s => s.includes('前置仓')));
                        if (ach) qzcAreaDataMap.set(an, ach);
                    });
                    achievementCategories.forEach((ck, idx) => {
                        if (idx >= heatmapCount) return;
                        let vals = [];
                        qzcAreaDataMap.forEach(ach => { const v = ach[ck] || 0; if (v > 0) vals.push(v); });
                        if (vals.length > 0) { const minV = Math.min(...vals), maxV = Math.max(...vals); qzcAreaHeatmap[ck] = maxV > minV ? { min: minV, max: maxV } : { min: 0, max: maxV }; }
                        else { qzcAreaHeatmap[ck] = { min: 0, max: 1 }; }
                    });

                    const getAreaStyle = (val, lim, ck, idx, hm) => {
                        if (val === 0) return 'background:#fff;color:#999;font-weight:700;';
                        let style = 'font-weight:700;';
                        if (lim > 0 && val > lim) { style = 'background:#FF4500;color:#fff;font-weight:700;'; }
                        else if (hm) {
                            const range = hm[ck];
                            if (range && range.max > range.min) {
                                const ratio = (val - range.min) / (range.max - range.min);
                                if (val === range.max && lim === 0) { style += 'background:#FFD700;color:#000;'; }
                                else { const r = Math.round(255 * ratio + 29 * (1 - ratio)); const g = Math.round(215 * ratio + 185 * (1 - ratio)); const b = Math.round(0 * ratio + 84 * (1 - ratio)); style += 'background:rgb(' + r + ',' + g + ',' + b + ');'; }
                            } else { style += 'background:#f0f2ff;'; }
                        } else { style += 'background:#f0f2ff;'; }
                        return style;
                    };

                    html += '<div class="table-container" style="border:3px solid #7c3aed;margin-bottom:12px;"><table>';
                    html += '<thead>' + buildHeader() + '</thead><tbody>';
                    // 生鲜店总
                    if (allSummarySx) {
                        html += '<tr><td style="font-weight:700;text-align:left;background:#e8ebff;font-size:11px;white-space:nowrap;min-width:225px;">生鲜店</td>';
                        achievementCategories.forEach((ck, cidx) => { const val = allSummarySx[ck] || 0; html += '<td style="' + getSummaryStyle(val, shengxianLimits[ck] || 0) + '">' + formatAchievementValue(val, ck, allSummarySx, cidx) + '</td>'; });
                        html += '</tr>';
                    }
                    areaNames.forEach(an => { const ach = sxAreaDataMap.get(an); if (!ach) return; html += '<tr><td style="font-weight:700;text-align:left;white-space:nowrap;min-width:225px;">' + escapeHTML(an + '生鲜店') + '</td>'; achievementCategories.forEach((ck, cidx) => { const val = ach[ck] || 0; html += '<td style="' + getAreaStyle(val, shengxianLimits[ck] || 0, ck, cidx, sxAreaHeatmap) + '">' + formatAchievementValue(val, ck, ach, cidx) + '</td>'; }); html += '</tr>'; });
                    html += '<tr class="divider-row"><td colspan="' + (achievementCategories.length + 1) + '"></td></tr>';
                    // 前置仓总
                    if (allSummaryQzc) {
                        html += '<tr><td style="font-weight:700;text-align:left;background:#e8ebff;font-size:11px;white-space:nowrap;min-width:225px;">前置仓</td>';
                        achievementCategories.forEach((ck, cidx) => { const val = allSummaryQzc[ck] || 0; html += '<td style="' + getSummaryStyle(val, qianzhicangLimits[ck] || 0) + '">' + formatAchievementValue(val, ck, allSummaryQzc, cidx) + '</td>'; });
                        html += '</tr>';
                    }
                    areaNames.forEach(an => { const ach = qzcAreaDataMap.get(an); if (!ach) return; html += '<tr><td style="font-weight:700;text-align:left;white-space:nowrap;min-width:225px;">' + escapeHTML(an + '前置仓') + '</td>'; achievementCategories.forEach((ck, cidx) => { const val = ach[ck] || 0; html += '<td style="' + getAreaStyle(val, qianzhicangLimits[ck] || 0, ck, cidx, qzcAreaHeatmap) + '">' + formatAchievementValue(val, ck, ach, cidx) + '</td>'; }); html += '</tr>'; });
                    html += '</tbody></table></div>';
                }

                // 门店明细表格
                html += '<table class="ach-table"><thead><tr><th style="white-space:nowrap;min-width:225px;">门店 <span class="limits-trigger" style="display:inline-block;width:12px;height:12px;line-height:12px;border-radius:50%;background:#e0e0e0;color:#888;font-size:0.5rem;font-weight:700;cursor:pointer;margin-left:3px;vertical-align:middle;text-align:center;pointer-events:auto;" title="查看类目上限值">!</span></th>';
                achievementCategories.forEach(ck => {
                    const dn = categoryKeyToDisplay.get(ck) || ck;
                    const short = dn.includes('｜') ? dn.split('｜')[0] : dn;
                    html += '<th>' + escapeHTML(short) + '</th>';
                });
                html += '</tr></thead><tbody>';

                // 生鲜店行
                sx.forEach((sn, idx) => {
                    const sd = currentAchData[sn];
                    if (!sd) return;
                    const ach = sd.achievements;
                    let rowClass = 'sx-row';
                    if (idx === 0) rowClass += ' sx-first';
                    if (idx === sx.length - 1) rowClass += ' sx-last';
                    html += '<tr class="' + rowClass + '"><td style="font-weight:600;text-align:left;">' + escapeHTML(sn) + '</td>';
                    achievementCategories.forEach((ck, cidx) => {
                        const val = ach[ck] || 0;
                        const lim = shengxianLimits[ck] || 0;
                        const dv = formatAchievementValue(val, ck, ach, cidx);
                        const style = getHeatmapStyle(val, lim, ck, cidx, false);
                        html += '<td style="' + style + '">' + dv + '</td>';
                    });
                    html += '</tr>';
                });

                // 分隔行
                if (sx.length && qzc.length) {
                    html += '<tr class="divider-row"><td colspan="' + (achievementCategories.length + 1) + '"></td></tr>';
                }

                // 前置仓行
                qzc.forEach((sn, idx) => {
                    const sd = currentAchData[sn];
                    if (!sd) return;
                    const ach = sd.achievements;
                    let rowClass = 'qzc-row';
                    if (idx === 0) rowClass += ' qzc-first';
                    if (idx === qzc.length - 1) rowClass += ' qzc-last';
                    html += '<tr class="' + rowClass + '"><td style="font-weight:600;text-align:left;">' + escapeHTML(sn) + '</td>';
                    achievementCategories.forEach((ck, cidx) => {
                        const val = ach[ck] || 0;
                        const lim = qianzhicangLimits[ck] || 0;
                        const dv = formatAchievementValue(val, ck, ach, cidx);
                        const style = getHeatmapStyle(val, lim, ck, cidx, true);
                        html += '<td style="' + style + '">' + dv + '</td>';
                    });
                    html += '</tr>';
                });

                html += '</tbody></table></div>';
                return html;
            }

            // 构建紧凑物流损表格HTML
            function buildCompactWuliusunHtml() {
                let stores = [];
                if (selectedArea) stores = getAreaStores(selectedArea);
                else if (selectedStore) stores = [selectedStore];
                else return '';
                if (!stores.length) return '';

                const getCount = (sn) => allData.filter(r => {
                    return String(getColValue(r,'门店名称')||'').trim() === sn && String(getColValue(r,'问题原因名称')||'').trim() === '物流损';
                }).length;

                const sx = stores.filter(s => !s.includes('前置仓')).sort((a,b) => getCount(b) - getCount(a));
                const qzc = stores.filter(s => s.includes('前置仓')).sort((a,b) => getCount(b) - getCount(a));

                let allRows = [];
                [...sx, ...qzc].forEach(sn => {
                    let rows = allData.filter(r => {
                        return String(getColValue(r,'门店名称')||'').trim() === sn && String(getColValue(r,'问题原因名称')||'').trim() === '物流损';
                    });
                    rows.sort((a,b) => {
                        const aR = String(getColValue(a,'app退款原因')||getColValue(a,'APP退款原因')||'').trim();
                        const aD = String(getColValue(a,'app退款描述')||getColValue(a,'APP退款描述')||'').trim();
                        const bR = String(getColValue(b,'app退款原因')||getColValue(b,'APP退款原因')||'').trim();
                        const bD = String(getColValue(b,'app退款描述')||getColValue(b,'APP退款描述')||'').trim();
                        const aDash = aR==='-'&&aD==='-', bDash = bR==='-'&&bD==='-';
                        return (aDash?1:0)-(bDash?1:0);
                    });
                    allRows = allRows.concat(rows);
                });
                if (!allRows.length) return '';

                let html = '<div class="wrap">';

                const headers = ['门店','问题原因名称','SKU名称','APP退款原因','APP退款描述','单号','责任人'];
                html += '<div class="table-container table-yellow"><table><thead><tr>' + headers.map(h => '<th>' + h + '</th>').join('') + '</tr></thead><tbody>';
                allRows.forEach(row => {
                    const sn = String(getColValue(row,'门店名称')||'').trim();
                    const st = getStoreType(sn);
                    const tl = st==='qianzhicang'?'前置仓':'生鲜店';
                    const tc = st==='qianzhicang'?'tag-qzc':'tag-sx';
                    const orderFields = ['淘系主订单id'];
                    const orderVals = orderFields.map(f => getColValue(row,f)||'').filter(v=>String(v).trim()).join(' / ');
                    const delivery = String(getColValue(row,'配送员名')||'').trim();
                    html += '<tr>';
                    html += '<td style="text-align:left;">' + escapeHTML(sn) + ' <span class="tag ' + tc + '">' + tl + '</span></td>';
                    html += '<td>' + escapeHTML(getColValue(row,'问题原因名称')||'') + '</td>';
                    html += '<td>' + escapeHTML(getColValue(row,'sku名称')||getColValue(row,'SKU名称')||'') + '</td>';
                    html += '<td>' + escapeHTML(getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')||'') + '</td>';
                    html += '<td style="max-width:200px;word-break:break-all;white-space:normal;">' + escapeHTML(getAppRefundDesc(row)) + '</td>';
                    html += '<td style="font-size:9px;">' + (orderVals ? escapeHTML(orderVals) : '-') + '</td>';
                    html += '<td>' + (delivery && delivery!=='-' ? escapeHTML(delivery) : '-') + '</td>';
                    html += '</tr>';
                });
                html += '</tbody></table></div></div>';
                return html;
            }

            // 构建紧凑冷链化冻表格HTML（蓝色边框）
            function buildCompactColdThawHtml() {
                let stores = [];
                if (selectedArea) stores = getAreaStores(selectedArea);
                else if (selectedStore) stores = [selectedStore];
                else return '';
                if (!stores.length || !coldThawData.length) return '';

                const filtered = coldThawData.filter(r => stores.includes(String(getColValue(r,'门店名称')||'').trim()));
                if (!filtered.length) return '';

                const getCount = (sn) => filtered.filter(r => String(getColValue(r,'门店名称')||'').trim()===sn).length;
                const sxData = filtered.filter(r => !String(getColValue(r,'门店名称')||'').includes('前置仓'));
                const qzcData = filtered.filter(r => String(getColValue(r,'门店名称')||'').includes('前置仓'));
                const sxS = [...new Set(sxData.map(r=>String(getColValue(r,'门店名称')||'').trim()).filter(Boolean))].sort((a,b)=>getCount(b)-getCount(a));
                const qzcS = [...new Set(qzcData.map(r=>String(getColValue(r,'门店名称')||'').trim()).filter(Boolean))].sort((a,b)=>getCount(b)-getCount(a));

                let allSorted = [];
                sxS.forEach(sn => { allSorted = allSorted.concat(sxData.filter(r=>String(getColValue(r,'门店名称')||'').trim()===sn)); });
                qzcS.forEach(sn => { allSorted = allSorted.concat(qzcData.filter(r=>String(getColValue(r,'门店名称')||'').trim()===sn)); });
                if (!allSorted.length) return '';

                let html = '<div class="wrap">';

                const headers = ['门店','问题原因名称','SKU名称','APP退款原因','APP退款描述','单号','责任人'];
                html += '<div class="table-container table-blue"><table><thead><tr>' + headers.map(h => '<th>' + h + '</th>').join('') + '</tr></thead><tbody>';
                allSorted.forEach(row => {
                    const sn = String(getColValue(row,'门店名称')||'').trim();
                    const st = getStoreType(sn);
                    const tl = st==='qianzhicang'?'前置仓':'生鲜店';
                    const tc = st==='qianzhicang'?'tag-qzc':'tag-sx';
                    const orderFields = ['淘系主订单id'];
                    const orderVals = orderFields.map(f => getColValue(row,f)||'').filter(v=>String(v).trim()).join(' / ');
                    const delivery = String(getColValue(row,'配送员名')||'').trim();
                    html += '<tr>';
                    html += '<td style="text-align:left;">' + escapeHTML(sn) + ' <span class="tag ' + tc + '">' + tl + '</span></td>';
                    html += '<td>' + escapeHTML(getColValue(row,'问题原因名称')||'') + '</td>';
                    html += '<td>' + escapeHTML(getColValue(row,'sku名称')||getColValue(row,'SKU名称')||'') + '</td>';
                    html += '<td>' + escapeHTML(getColValue(row,'app退款原因')||getColValue(row,'APP退款原因')||'') + '</td>';
                    html += '<td style="max-width:200px;word-break:break-all;white-space:normal;">' + escapeHTML(getAppRefundDesc(row)) + '</td>';
                    html += '<td style="font-size:9px;">' + (orderVals ? escapeHTML(orderVals) : '-') + '</td>';
                    html += '<td>' + (delivery && delivery!=='-' ? escapeHTML(delivery) : '-') + '</td>';
                    html += '</tr>';
                });
                html += '</tbody></table></div></div>';
                return html;
            }

            // 构建紧凑差评表格HTML（红色边框）
            function buildCompactBadReviewHtml() {
                let stores = [];
                if (selectedArea) stores = getAreaStores(selectedArea);
                else if (selectedStore) stores = [selectedStore];
                else return '';
                if (!stores.length || !badReviewData.length) return '';

                const filtered = badReviewData.filter(r => stores.includes(String(getColValue(r,'门店')||'').trim()));
                if (!filtered.length) return '';

                const getCount = (sn) => filtered.filter(r => String(getColValue(r,'门店')||'').trim()===sn).length;
                const sxData = filtered.filter(r => !String(getColValue(r,'门店')||'').includes('前置仓'));
                const qzcData = filtered.filter(r => String(getColValue(r,'门店')||'').includes('前置仓'));
                const sxS = [...new Set(sxData.map(r=>String(getColValue(r,'门店')||'').trim()).filter(Boolean))].sort((a,b)=>getCount(b)-getCount(a));
                const qzcS = [...new Set(qzcData.map(r=>String(getColValue(r,'门店')||'').trim()).filter(Boolean))].sort((a,b)=>getCount(b)-getCount(a));

                let allSorted = [];
                sxS.forEach(sn => { allSorted = allSorted.concat(sxData.filter(r=>String(getColValue(r,'门店')||'').trim()===sn)); });
                qzcS.forEach(sn => { allSorted = allSorted.concat(qzcData.filter(r=>String(getColValue(r,'门店')||'').trim()===sn)); });
                if (!allSorted.length) return '';

                let html = '<div class="wrap">';

                const headers = ['评价日期','门店','配送员名称','单号','评价文本','评价标签','评价星级'];
                html += '<div class="table-container table-red"><table><thead><tr>' + headers.map(h => '<th>' + h + '</th>').join('') + '</tr></thead><tbody>';
                allSorted.forEach(row => {
                    const sn = String(getColValue(row,'门店')||'').trim();
                    const st = getStoreType(sn);
                    const tl = st==='qianzhicang'?'前置仓':'生鲜店';
                    const tc = st==='qianzhicang'?'tag-qzc':'tag-sx';
                    const orderFields = ['评价父订单'];
                    const orderVals = orderFields.map(f => getColValue(row,f)||'').filter(v=>String(v).trim()).join(' / ');
                    const starVal = parseInt(getColValue(row,'评价星级'));
                    let starStr = '-';
                    if (!isNaN(starVal) && starVal > 0) starStr = '★'.repeat(starVal) + '☆'.repeat(5-starVal);
                    html += '<tr>';
                    html += '<td>' + escapeHTML(getColValue(row,'评价日期')||getColValue(row,'交易日期')||'') + '</td>';
                    html += '<td style="text-align:left;">' + escapeHTML(sn) + ' <span class="tag ' + tc + '">' + tl + '</span></td>';
                    html += '<td>' + escapeHTML(getColValue(row,'配送员名称')||'') + '</td>';
                    html += '<td style="font-size:9px;">' + (orderVals ? escapeHTML(orderVals) : '-') + '</td>';
                    html += '<td style="max-width:200px;word-break:break-all;white-space:normal;text-align:left;">' + escapeHTML(getColValue(row,'评价文本')||'') + '</td>';
                    html += '<td>' + escapeHTML(getColValue(row,'评价标签')||'') + '</td>';
                    html += '<td style="color:#f59e0b;">' + starStr + '</td>';
                    html += '</tr>';
                });
                html += '</tbody></table></div></div>';
                return html;
            }

            // 构建紧凑问单类目分析HTML（冷链化冻或物流损）
            function buildCompactAnalysisHtml(analysisType) {
                const savedType = currentAnalysisType;
                currentAnalysisType = analysisType;

                const result = buildAchievementStoreList();
                if (!result) {
                    currentAnalysisType = savedType;
                    return '';
                }
                const { storeList, targetCatKey, targetCatIndex } = result;

                // 统计信息
                const analysisTypeLabel = analysisType === 'coldThaw' ? '冷链化冻' : '物流损';
                let storeTypeLabel = '';
                if (filterStoreTypes.qianzhicang && filterStoreTypes.shengxian) storeTypeLabel = '所有店';
                else if (filterStoreTypes.qianzhicang) storeTypeLabel = '前置仓';
                else if (filterStoreTypes.shengxian) storeTypeLabel = '生鲜店';
                else storeTypeLabel = '无';

                let areaStr = '全部片区';
                if (selectedArea) areaStr = selectedArea;
                else if (selectedStore) areaStr = selectedStore;

                const info = getDateRangeInfo();
                const dateStr = info.range || '--';
                const fileLabel = isMultiFile ? '（' + uploadedFileCount + '个文件合并）' : '';

                const borderColor = analysisType === 'coldThaw' ? 'section-blue' : 'section-purple';

                let html = '<div class="wrap">';
                // 统计信息行
                html += '<div class="analysis-stats">📍 统计片区：' + escapeHTML(areaStr) + '-' + analysisTypeLabel + '（' + storeTypeLabel + '） &nbsp;&nbsp; 统计时间：' + dateStr + fileLabel + '</div>';

                // 达成排行榜 - 尾部
                const tailList = storeList.slice(0, rankTopCount);
                html += '<div class="' + borderColor + '">';
                html += '<div class="analysis-title-bar">🏆 达成排行榜</div>';
                html += '<div class="analysis-sub-title-bar">🔴 尾部门店 TOP' + rankTopCount + '（达成数值最高）</div>';
                if (tailList.length) {
                    html += '<table class="a-table"><thead><tr><th>排行</th><th>片区</th><th>门店</th><th>达成占比</th><th>问单数量</th></tr></thead><tbody>';
                    buildCompactRankRowsHtml(tailList, targetCatKey, targetCatIndex, (h) => { html += h; });
                    html += '</tbody></table>';
                }

                // 达成排行榜 - 头部
                const headList = storeList.slice(-rankTopCount).sort((a, b) => a.val - b.val);
                html += '<div class="analysis-sub-title-bar" style="margin-top:10px;">🟢 头部门店 TOP' + rankTopCount + '（达成数值最低）</div>';
                if (headList.length) {
                    html += '<table class="a-table"><thead><tr><th>排行</th><th>片区</th><th>门店</th><th>达成占比</th><th>问单数量</th></tr></thead><tbody>';
                    buildCompactRankRowsHtml(headList, targetCatKey, targetCatIndex, (h) => { html += h; });
                    html += '</tbody></table>';
                }
                html += '</div>';

                // 商品排行榜
                const sourceData = analysisType === 'coldThaw' ? coldThawData : logisticsData;
                let filterStoreSet = null;
                if (selectedStore) filterStoreSet = new Set([selectedStore]);
                else if (selectedArea) filterStoreSet = new Set(getAreaStores(selectedArea));

                const skuCounts = new Map();
                sourceData.forEach(row => {
                    const storeName = String(getColValue(row, '门店名称') || '').trim();
                    if (filterStoreSet && !filterStoreSet.has(storeName)) return;
                    const storeType = getStoreType(storeName);
                    if (!filterStoreTypes[storeType]) return;
                    const skuName = String(getColValue(row, 'sku名称') || getColValue(row, 'SKU名称') || '').trim();
                    if (!skuName || skuName === '-') return;
                    skuCounts.set(skuName, (skuCounts.get(skuName) || 0) + 1);
                });

                const sortedSkus = [...skuCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, skuTopCount);
                html += '<div class="section-red">';
                html += '<div class="analysis-title-bar">📦 商品排行榜（SKU出现次数 TOP' + skuTopCount + '）</div>';
                if (sortedSkus.length) {
                    html += '<table class="a-table"><thead><tr><th>排行</th><th>SKU名称</th><th>出现次数</th></tr></thead><tbody>';
                    sortedSkus.forEach((item, idx) => {
                        const rank = idx + 1;
                        let rc = '';
                        if (rank === 1) rc = 'a-rank-1';
                        else if (rank === 2) rc = 'a-rank-2';
                        else if (rank === 3) rc = 'a-rank-3';
                        html += '<tr><td class="' + rc + '">' + rank + '</td><td style="text-align:left;">' + escapeHTML(item[0]) + '</td><td><strong>' + item[1] + '</strong></td></tr>';
                    });
                    html += '</tbody></table>';
                }
                html += '</div>';

                html += '</div>';
                currentAnalysisType = savedType;
                return html;
            }

            // 构建排行表格行HTML（紧凑版）
            function buildCompactRankRowsHtml(list, targetCatKey, targetCatIndex, appendFn) {
                let currentRank = 1;
                let prevVal = null;
                list.forEach((item, idx) => {
                    if (idx > 0 && item.val !== prevVal) {
                        currentRank = idx + 1;
                    }
                    prevVal = item.val;
                    let rc = '';
                    if (currentRank === 1) rc = 'a-rank-1';
                    else if (currentRank === 2) rc = 'a-rank-2';
                    else if (currentRank === 3) rc = 'a-rank-3';
                    const dv = formatAchievementValue(item.val, targetCatKey, null, targetCatIndex);
                    const isOver = item.limit > 0 && item.val > item.limit;
                    const overClass = isOver ? 'a-over' : '';
                    let row = '<tr><td class="' + rc + '">' + currentRank + '</td>'
                        + '<td class="a-area"><span class="atag atag-area">' + escapeHTML(item.areaName) + '</span></td>'
                        + '<td class="a-store"><span class="atag atag-store">' + escapeHTML(item.storeName) + '</span></td>'
                        + '<td class="' + overClass + '">' + dv + '</td>'
                        + '<td>' + item.orderCount + '</td></tr>';
                    appendFn(row);
                });
            }

            // 将HTML片段渲染为图片并下载
            async function renderHtmlToImage(htmlContent, fileName) {
                const fullHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' + COMPACT_TABLE_STYLE + '</style></head><body>' + htmlContent + '</body></html>';
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = fullHtml;
                tempDiv.style.cssText = 'position:fixed;left:-9999px;top:0;background:#fff;z-index:-1;';
                document.body.appendChild(tempDiv);

                await new Promise(r => setTimeout(r, 200));

                try {
                    const canvas = await html2canvas(tempDiv, {
                        scale: 4,
                        useCORS: true,
                        allowTaint: true,
                        backgroundColor: '#ffffff',
                        logging: false
                    });
                    const dataUrl = canvas.toDataURL('image/png');
                    // 检查图片数据是否有效（base64编码后至少有一定体积）
                    // 空白或过载图片通常 dataUrl 长度极短或 canvas 宽高为0
                    const canvasArea = canvas.width * canvas.height;
                    const dataLength = dataUrl.length;
                    if (canvasArea === 0 || dataLength < 1000) {
                        // 数据过载，弹窗提示
                        showOverloadPopup(fileName);
                        return;
                    }
                    const link = document.createElement('a');
                    link.download = fileName;
                    link.href = dataUrl;
                    link.click();
                } catch(err) {
                    console.error('renderHtmlToImage error:', err);
                    toast('⚠️ 图片导出失败：' + (err.message || String(err)));
                } finally {
                    if (tempDiv.parentNode) {
                        document.body.removeChild(tempDiv);
                    }
                }
            }

            // 数据过载弹窗提示
            function showOverloadPopup(fileName) {
                // 从文件名中提取数据名称（片区-数据名称-统计时间-时间戳格式）
                const parts = fileName.split('-');
                let shortName = fileName;
                if (parts.length >= 2) {
                    shortName = parts[1];
                }
                const bodyHTML = '<div style="text-align:center;padding:20px 10px;"><div style="font-size:2.5rem;margin-bottom:12px;">⚠️</div><div style="font-size:0.9rem;font-weight:600;color:#c0392b;margin-bottom:6px;">' + escapeHTML(shortName) + ' 数据过载无法下载</div><div style="font-size:0.75rem;color:#888;">图片内容过大，请尝试缩小筛选范围后重试</div></div>';
                openGuideView('导出失败', '', bodyHTML, '');
            }

            // 主导出函数：逐模块导出图片
            async function generateModuleImages() {
                const safeName = getExportStoreName().replace(/[\\/:*?"<>|]/g, '');
                const dateRangeStr = getExportDateRangeStr();
                const timestampStr = getTimestampStr();
                let exportedCount = 0;

                try {
                    // 1. 差评
                    const brHtml = buildCompactBadReviewHtml();
                    if (brHtml) {
                        await renderHtmlToImage(brHtml, `${safeName}-差评数据-${dateRangeStr}-${timestampStr}.png`);
                        exportedCount++;
                    }

                    // 2. 冷链化冻
                    const ctHtml = buildCompactColdThawHtml();
                    if (ctHtml) {
                        await renderHtmlToImage(ctHtml, `${safeName}-冷链化冻-${dateRangeStr}-${timestampStr}.png`);
                        exportedCount++;
                    }

                    // 3. 物流损明细
                    const wsHtml = buildCompactWuliusunHtml();
                    if (wsHtml) {
                        await renderHtmlToImage(wsHtml, `${safeName}-物流损明细-${dateRangeStr}-${timestampStr}.png`);
                        exportedCount++;
                    }

                    // 4. 问单达成情况
                    const achHtml = buildCompactAchievementHtml();
                    if (achHtml) {
                        await renderHtmlToImage(achHtml, `${safeName}-达成情况-${dateRangeStr}-${timestampStr}.png`);
                        exportedCount++;
                    }

                    if (exportedCount === 0) {
                        toast('⚠️ 当前无数据可导出，请先选择片区或门店');
                    } else {
                        toast('✅ 已导出 ' + exportedCount + ' 张图片');
                        // 导出图片后自动复制文案
                        const text = buildCopyText();
                        navigator.clipboard.writeText(text).catch(() => {});
                    }
                } catch(err) {
                    console.error(err);
                    toast('❌ 导出失败：' + err.message);
                }
            }

            // 内联弹窗鼠标离开自动关闭：影响范围 / 文件列表 / 单号 / 时间戳 等所有 detail-popup
            let popupHoverTimer = null;
            function clearPopupHoverTimer() { if (popupHoverTimer) { clearTimeout(popupHoverTimer); popupHoverTimer = null; } }
            // 为弹窗及其触发元素绑定 hover 关闭：鼠标离开弹窗/触发元素区域后自动退出弹窗，进入则取消关闭
            // 仅对该弹窗自身生效（currentPopup === popup），避免与其它弹窗相互干扰
            function bindPopupHoverClose(popup, anchor) {
                clearPopupHoverTimer();
                var enter = function () { if (currentPopup !== popup) return; clearPopupHoverTimer(); };
                var leave = function () {
                    if (currentPopup !== popup) return;
                    clearPopupHoverTimer();
                    popupHoverTimer = setTimeout(function () {
                        popupHoverTimer = null;
                        if (currentPopup === popup) closeAllPopups();
                    }, 150);
                };
                popup.addEventListener('mouseenter', enter);
                popup.addEventListener('mouseleave', leave);
                if (anchor) {
                    // 移除上一次绑定的处理器，避免同一触发元素多次绑定造成累积
                    if (anchor._popupHoverEnter) {
                        anchor.removeEventListener('mouseenter', anchor._popupHoverEnter);
                        anchor.removeEventListener('mouseleave', anchor._popupHoverLeave);
                    }
                    anchor._popupHoverEnter = enter;
                    anchor._popupHoverLeave = leave;
                    anchor.addEventListener('mouseenter', enter);
                    anchor.addEventListener('mouseleave', leave);
                }
            }
            function closeAllPopups() { clearPopupHoverTimer(); if (currentPopup) { currentPopup.remove(); currentPopup = null; } }
            document.addEventListener('click', function(e) {
                if (currentPopup && !currentPopup.contains(e.target) && !e.target.closest('.cell-btn') && !e.target.closest('.cell-clickable') && !e.target.closest('.ratio-main-bubble') && !e.target.closest('.cell-view-btn')) {
                    closeAllPopups();
                }
            });

            function showDetailPopup(anchor, contentHTML, isPlainText = false) {
                closeAllPopups();
                const popup = document.createElement('div'); popup.className = 'detail-popup';
                if (isPlainText) popup.innerHTML = `<div style="max-height:42vh;overflow-y:auto;white-space:pre-wrap;">${escapeHTML(contentHTML)}</div>`;
                else popup.innerHTML = contentHTML;
                document.body.appendChild(popup);
                positionPopup(anchor, popup);
                currentPopup = popup;
                bindPopupHoverClose(popup, anchor);
                popup.querySelectorAll('.info-copy-btn').forEach(btn => {
                    btn.addEventListener('click', function(e) {
                        e.stopPropagation();
                        const txt = this.dataset.copy || '';
                        if (navigator.clipboard) { navigator.clipboard.writeText(txt).then(() => { this.classList.add('copied'); setTimeout(() => this.classList.remove('copied'), 1500); }); }
                    });
                });
            }

            function positionPopup(anchor, popup) {
                const rect = anchor.getBoundingClientRect();
                const pw = popup.offsetWidth || 200, ph = popup.offsetHeight || 150;
                let top = rect.bottom + 8, left = rect.left + rect.width/2 - pw/2;
                if (top + ph > window.innerHeight - 10) top = rect.top - ph - 8;
                if (top < 10) top = 10;
                if (left < 10) left = 10;
                else if (left + pw > window.innerWidth - 10) left = window.innerWidth - pw - 10;
                popup.style.top = top + 'px'; popup.style.left = left + 'px';
            }

            function makePopupRow(label, value) {
                return `<div class="info-row"><span class="info-label">${escapeHTML(label)}</span><span class="info-value">${escapeHTML(value||'-')}</span><span class="info-copy-btn" data-copy="${escapeHTML(value||'')}">📋 复制</span></div>`;
            }

            // 初始化
            ['filterBar','tableWrapper','statsPanel','achievementPanel'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.style.display='none';
            });
            // 确保分析页面初始隐藏
            isAnalysisPageVisible = false;
            const mainPageEl = document.getElementById('mainPage');
            const analysisPageEl = document.getElementById('analysisPage');
            if (mainPageEl) mainPageEl.classList.remove('hidden');
            if (analysisPageEl) analysisPageEl.classList.remove('show');
            openGuideView('📂 导入问单明细', '请导入Excel文件以开始分析（支持多文件合并）',
                '<div class="file-upload-area" id="initUploadArea"><span class="upload-text-lg">📁 点击选择文件</span></div><div class="upload-hint">💡 导入大文件时页面可能出现短暂卡顿，请耐心等待加载完成。<br>如页面提示"无响应"，请点击<b>「等待」</b>按钮，切勿关闭页面。</div><div class="upload-progress-wrap" id="initProgressWrap"><div class="upload-progress-bar"><div class="upload-progress-fill" id="initProgressFill"></div></div><div class="upload-progress-text" id="initProgressText">准备中...</div></div>', '');
            document.getElementById('initUploadArea').addEventListener('click', () => hiddenFileInput.click());
            hiddenFileInput.addEventListener('change', e => { if (e.target.files.length) handleFileUpload(e.target.files); });
            // v18: 绑定下拉筛选事件
            bindFilterDropdownEvents();
            // 类目上限 ! 按钮：事件委托（替代内联 onclick）
document.addEventListener('click', function(e) {
    if (e.target.closest('.limits-trigger')) {
        e.stopPropagation();
        showLimitsPopup();
    }
});

// 通用「关闭引导弹窗」按钮：事件委托
document.addEventListener('click', function(e) {
    if (e.target.closest('[data-close-guide]')) {
        e.stopPropagation();
        guideOverlay.style.display = 'none';
    }
});
        })();