#!/bin/bash

# 设置颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   Excel通讯录转换工具 - 依赖安装${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# 检查 Python
echo -e "${YELLOW}[1/3] 检查 Python 环境...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[错误] 未检测到 Python3，请先安装 Python 3.7 或更高版本${NC}"
    echo "macOS: brew install python3"
    echo "Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "CentOS/RHEL: sudo yum install python3 python3-pip"
    exit 1
fi
python3 --version
echo ""

# 升级 pip
echo -e "${YELLOW}[2/3] 升级 pip 到最新版本...${NC}"
python3 -m pip install --upgrade pip
echo ""

# 安装依赖
echo -e "${YELLOW}[3/3] 安装所需依赖包...${NC}"
echo ""
echo -e "${GREEN}正在安装 pandas（Excel文件处理）...${NC}"
pip3 install pandas

echo ""
echo -e "${GREEN}正在安装 openpyxl（Excel文件读写）...${NC}"
pip3 install openpyxl

echo ""
echo -e "${GREEN}正在安装 tkinterdnd2（拖拽功能支持，可选）...${NC}"
pip3 install tkinterdnd2 2>/dev/null || echo -e "${YELLOW}提示: tkinterdnd2 安装失败，拖拽功能将不可用（不影响核心功能）${NC}"

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}   安装完成！${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo "已安装的依赖包："
pip3 list | grep -E "pandas|openpyxl|tkinterdnd2"
echo ""
echo -e "${GREEN}现在可以运行 Excel通讯录转换工具.py 了${NC}"
echo ""