import os
import datetime

class DirectoryTreeGenerator:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.html_content = []
        self.generated_html_name = "目录树.html"
        self.icon_path = os.path.join(folder_path, "./.APP/favicon.ico")
        self.has_icon = os.path.exists(self.icon_path)
        # 获取当前时间并格式化为中文显示
        self.generation_time = datetime.datetime.now().strftime("%Y年%m月%d日 %H:%M:%S")

    def generate_html(self):
        # 获取文件夹名
        folder_name = os.path.basename(self.folder_path)
        
        self.html_content.append('<!DOCTYPE html>')
        self.html_content.append('<html lang="zh-CN">')
        self.html_content.append('<head>')
        self.html_content.append('<meta charset="UTF-8">')
        self.html_content.append('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
        
        # 添加网站图标（如果存在）
        if self.has_icon:
            self.html_content.append(f'<link rel="icon" href="./.APP/favicon.ico" type="image/x-icon">')
            self.html_content.append(f'<link rel="shortcut icon" href="./.APP/favicon.ico" type="image/x-icon">')
        
        self.html_content.append(f'<title>{folder_name} - 目录</title>')
        # 添加Material Icons字体
        self.html_content.append('<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">')
        self.html_content.append('<style>')
        self.html_content.append('''
            :root {
                --light-bg: #f9f9f9;
                --light-container: #ffffff;
                --light-text: #333333;
                --light-border: #eaeaea;
                --light-hover: #f5f5f5;
                --light-icon: #666666;
                --light-highlight: #e8e8e8;
                --light-footer-text: #888888;
                
                --dark-bg: #1a1a1a;
                --dark-container: #262626;
                --dark-text: #f0f0f0;
                --dark-border: #3a3a3a;
                --dark-hover: #2d2d2d;
                --dark-icon: #b0b0b0;
                --dark-highlight: #3d3d3d;
                --dark-footer-text: #aaaaaa;
                
                --accent-color: #888888;
                --button-size: 42px;
                --spacing: 15px;
                --transition-time: 0.25s;
                --border-radius: 8px;
            }

            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            body {
                font-family: 'Segoe UI', 'Microsoft YaHei', 'Roboto', sans-serif;
                background-color: var(--light-bg);
                color: var(--light-text);
                padding: 25px;
                transition: background-color var(--transition-time), color var(--transition-time);
                display: flex;
                flex-direction: column;
                align-items: center;
                min-height: 100vh;
                line-height: 1.6;
            }
            .container {
                max-width: 1000px;
                width: 100%;
                background-color: var(--light-container);
                padding: 30px;
                border-radius: var(--border-radius);
                box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
                transition: background-color var(--transition-time);
                margin-top: 20px;
                border: 1px solid var(--light-border);
                position: relative;
            }
            .header {
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 25px;
                flex-wrap: wrap;
                gap: 15px;
            }
            .logo {
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .logo-icon {
                width: 36px;
                height: 36px;
                object-fit: contain;
                /* 移除了灰阶滤镜，恢复原色 */
            }
            .logo-text {
                font-size: 1.6em;
                font-weight: 600;
                color: var(--light-text);
                letter-spacing: -0.5px;
            }
            .controls {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 25px;
                flex-wrap: wrap;
                gap: var(--spacing);
                padding-bottom: 15px;
                border-bottom: 1px solid var(--light-border);
            }
            .button-group {
                display: flex;
                gap: 10px;
            }
            .controls button {
                background: transparent;
                color: var(--light-text);
                border: 1px solid var(--light-border);
                width: var(--button-size);
                height: var(--button-size);
                border-radius: 50%;
                cursor: pointer;
                font-size: 1.1em;
                transition: all var(--transition-time);
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .controls button:hover {
                background-color: var(--light-hover);
                border-color: var(--accent-color);
            }
            .search-container {
                flex: 1;
                display: flex;
                max-width: 600px;
                min-width: 200px;
                position: relative;
            }
            .search-container input {
                width: 100%;
                padding: 12px 45px 12px 15px;
                border: 1px solid var(--light-border);
                border-radius: 24px;
                font-size: 15px;
                transition: all var(--transition-time);
                background: var(--light-container);
            }
            .search-container input:focus {
                border-color: var(--accent-color);
                outline: none;
                box-shadow: 0 0 0 2px rgba(136, 136, 136, 0.1);
            }
            .tree {
                margin: 0;
                padding: 0;
                list-style: none;
            }
            .tree li {
                margin: 0;
                padding: 10px 0;
                position: relative;
                background-color: var(--light-container);
                border-radius: 6px;
                transition: background-color var(--transition-time);
                cursor: pointer;
                padding: 10px 15px;
                margin-bottom: 6px;
                border: 1px solid transparent;
            }
            .tree li:hover {
                background-color: var(--light-hover);
                border-color: var(--light-border);
            }
            .tree .directory-wrapper {
                display: flex;
                align-items: center;
                padding-left: 8px;
            }
            .tree .toggle {
                margin-right: 10px;
                cursor: pointer;
                user-select: none;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 24px;
                height: 24px;
                color: var(--light-text);
                font-size: 13px;
                flex-shrink: 0;
            }
            .material-icons {
                font-size: 20px;
                transition: transform 0.2s;
                color: var(--light-icon);
            }
            .tree .directory {
                font-weight: 600;
                color: var(--light-text);
                font-size: 16px;
            }
            .tree .file {
                display: flex;
                align-items: center;
                padding-left: 30px;
                font-size: 15px;
            }
            .tree .file-icon {
                margin-right: 10px;
                font-size: 16px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 20px;
                height: 20px;
                color: var(--light-icon);
            }
            .tree .file a {
                text-decoration: none;
                color: var(--light-text);
                transition: color var(--transition-time);
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .tree .file a:hover {
                color: var(--accent-color);
            }
            .tree ul {
                display: none;
                padding-left: 20px;
                margin-top: 8px;
                list-style: none;
            }
            .tree li.open > ul {
                display: block;
            }

            /* 底部生成时间 */
            .generation-info {
                text-align: center;
                margin-top: 25px;
                padding-top: 15px;
                border-top: 1px solid var(--light-border);
                font-size: 13px;
                color: var(--light-footer-text);
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 8px;
                flex-wrap: wrap;
            }
            .generation-info .material-icons {
                font-size: 15px;
            }

            /* 深色模式 */
            body.dark {
                background-color: var(--dark-bg);
                color: var(--dark-text);
            }
            body.dark .container {
                background-color: var(--dark-container);
                border-color: var(--dark-border);
                box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
            }
            body.dark .logo-text {
                color: var(--dark-text);
            }
            body.dark .controls button {
                color: var(--dark-text);
                border-color: var(--dark-border);
            }
            body.dark .controls button:hover {
                background-color: var(--dark-hover);
                border-color: var(--accent-color);
            }
            body.dark .search-container input {
                background: var(--dark-container);
                color: var(--dark-text);
                border-color: var(--dark-border);
            }
            body.dark .search-container input:focus {
                border-color: var(--accent-color);
                box-shadow: 0 0 0 2px rgba(136, 136, 136, 0.2);
            }
            body.dark .tree li {
                background-color: var(--dark-container);
                border-color: transparent;
            }
            body.dark .tree li:hover {
                background-color: var(--dark-hover);
                border-color: var(--dark-border);
            }
            body.dark .tree .directory {
                color: var(--dark-text);
            }
            body.dark .tree .file a {
                color: var(--dark-text);
            }
            body.dark .tree .file a:hover {
                color: var(--accent-color);
            }
            body.dark .material-icons {
                color: var(--dark-icon);
            }
            body.dark .controls {
                border-bottom-color: var(--dark-border);
            }
            body.dark .generation-info {
                border-top-color: var(--dark-border);
                color: var(--dark-footer-text);
            }

            /* 平板上的布局调整 */
            @media (max-width: 992px) {
                .container {
                    padding: 20px;
                }
                .controls {
                    flex-direction: column;
                    align-items: stretch;
                }
                .search-container {
                    width: 100%;
                    max-width: 100%;
                }
                .button-group {
                    width: 100%;
                    justify-content: center;
                }
            }

            /* 手机上的布局优化 */
            @media (max-width: 576px) {
                body {
                    padding: 15px;
                }
                .container {
                    padding: 18px 12px;
                    margin-top: 15px;
                }
                .logo-text {
                    font-size: 1.4em;
                }
                .tree li {
                    padding: 8px 10px;
                }
                .tree .file {
                    padding-left: 22px;
                }
                .controls button {
                    width: 38px;
                    height: 38px;
                }
                .material-icons {
                    font-size: 18px;
                }
                .generation-info {
                    font-size: 12px;
                    margin-top: 20px;
                    padding-top: 12px;
                }
            }

            /* 重置按钮样式 */
            #reset-search {
                display: flex;
                align-items: center;
                justify-content: center;
                width: var(--button-size);
                height: var(--button-size);
                border-radius: 50%;
                cursor: pointer;
                font-size: 1.1em;
                transition: background-color var(--transition-time);
            }

            /* 滚动条样式 */
            .tree {
                max-height: 60vh;
                overflow-y: auto;
                padding-right: 5px;
            }
            
            /* 自定义滚动条 */
            .tree::-webkit-scrollbar {
                width: 6px;
            }
            
            .tree::-webkit-scrollbar-track {
                background: rgba(0, 0, 0, 0.03);
                border-radius: 3px;
            }
            
            .tree::-webkit-scrollbar-thumb {
                background: rgba(0, 0, 0, 0.1);
                border-radius: 3px;
            }
            
            .tree::-webkit-scrollbar-thumb:hover {
                background: rgba(0, 0, 0, 0.15);
            }
            
            body.dark .tree::-webkit-scrollbar-track {
                background: rgba(255, 255, 255, 0.05);
            }
            
            body.dark .tree::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.1);
            }
            
            body.dark .tree::-webkit-scrollbar-thumb:hover {
                background: rgba(255, 255, 255, 0.15);
            }
            
            /* 高亮匹配项 */
            .match-highlight {
                background-color: var(--light-highlight) !important;
                border: 1px solid var(--light-border) !important;
            }
            body.dark .match-highlight {
                background-color: var(--dark-highlight) !important;
                border: 1px solid var(--dark-border) !important;
            }
            
            /* 搜索图标 */
            .search-icon {
                position: absolute;
                right: 15px;
                top: 50%;
                transform: translateY(-50%);
                color: var(--light-icon);
                pointer-events: none;
            }
            body.dark .search-icon {
                color: var(--dark-icon);
            }
            
            /* 操作按钮样式 */
            .action-button {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 8px 16px;
                background: transparent;
                color: var(--light-text);
                border: 1px solid var(--light-border);
                border-radius: 24px;
                cursor: pointer;
                font-size: 14px;
                transition: all var(--transition-time);
            }
            .action-button:hover {
                background-color: var(--light-hover);
                border-color: var(--accent-color);
            }
            body.dark .action-button {
                color: var(--dark-text);
                border-color: var(--dark-border);
            }
            body.dark .action-button:hover {
                background-color: var(--dark-hover);
            }
        ''')
        self.html_content.append('</style>')
        self.html_content.append('</head>')
        self.html_content.append('<body>')
        self.html_content.append('<div class="container">')
        
        # 添加logo区域
        self.html_content.append('<div class="header">')
        if self.has_icon:
            self.html_content.append(f'<div class="logo">')
            self.html_content.append(f'<img src="./.APP/favicon.ico" alt="Folder Icon" class="logo-icon">')
            self.html_content.append(f'<div class="logo-text">{folder_name}</div>')
            self.html_content.append('</div>')
        else:
            self.html_content.append(f'<h1 class="logo-text">{folder_name}</h1>')
        self.html_content.append('</div>')
        
        self.html_content.append('<div class="controls">')
        self.html_content.append('<div class="button-group">')
        self.html_content.append('<button id="toggle-theme" aria-label="切换主题" class="action-button">')
        self.html_content.append('<span class="material-icons">dark_mode</span>')
        self.html_content.append('')
        self.html_content.append('</button>')
        self.html_content.append('<button id="toggle-all" aria-label="" class="action-button">')
        self.html_content.append('<span class="material-icons">unfold_more</span>')
        self.html_content.append('')
        self.html_content.append('</button>')
        self.html_content.append('</div>')
        
        self.html_content.append('<div class="search-container">')
        self.html_content.append('<input type="text" id="search-input" placeholder="搜索文件或文件夹...">')
        self.html_content.append('<span class="material-icons search-icon">search</span>')
        self.html_content.append('</div>')
        
        self.html_content.append('<div class="button-group">')
        self.html_content.append('<button id="reset-search" aria-label="重置搜索" class="action-button">')
        self.html_content.append('<span class="material-icons">refresh</span>')
        self.html_content.append('')
        self.html_content.append('</button>')
        self.html_content.append('</div>')
        self.html_content.append('</div>')
        
        self.html_content.append('<ul class="tree">')
        self.process_directory(self.folder_path)
        self.html_content.append('</ul>')
        
        # 添加底部生成时间信息
        self.html_content.append(f'<div class="generation-info">')
        self.html_content.append('<span class="material-icons">schedule</span>')
        self.html_content.append(f'<span>生成时间：{self.generation_time}</span>')
        self.html_content.append('</div>')
        
        self.html_content.append('</div>')
        self.html_content.append('<script>')
        self.html_content.append('''
            document.addEventListener('DOMContentLoaded', function() {
                // 为所有目录项添加点击事件
                document.querySelectorAll('.tree .directory-wrapper').forEach(wrapper => {
                    wrapper.addEventListener('click', function() {
                        const parentLi = this.parentElement;
                        parentLi.classList.toggle('open');
                        const toggleIcon = this.querySelector('.toggle .material-icons');
                        if (parentLi.classList.contains('open')) {
                            toggleIcon.textContent = 'expand_more';
                        } else {
                            toggleIcon.textContent = 'chevron_right';
                        }
                    });
                });

                // 默认展开所有节点
                expandAll(document.querySelector('.tree'));

                // 切换主题按钮
                const toggleThemeButton = document.getElementById('toggle-theme');
                toggleThemeButton.addEventListener('click', function() {
                    const body = document.body;
                    if (body.classList.contains('dark')) {
                        body.classList.remove('dark');
                        localStorage.setItem('theme', 'light');
                        this.querySelector('.material-icons').textContent = 'dark_mode';
                    } else {
                        body.classList.add('dark');
                        localStorage.setItem('theme', 'dark');
                        this.querySelector('.material-icons').textContent = 'light_mode';
                    }
                });

                // 检查本地存储中的主题设置
                const savedTheme = localStorage.getItem('theme');
                if (savedTheme === 'dark') {
                    document.body.classList.add('dark');
                    toggleThemeButton.querySelector('.material-icons').textContent = 'light_mode';
                }

                // 展开&折叠按钮
                const toggleAllButton = document.getElementById('toggle-all');
                toggleAllButton.addEventListener('click', function() {
                    const icon = this.querySelector('.material-icons');
                    if (icon.textContent === 'unfold_more') {
                        collapseAll(document.querySelector('.tree'));
                        icon.textContent = 'unfold_less';
                    } else {
                        expandAll(document.querySelector('.tree'));
                        icon.textContent = 'unfold_more';
                    }
                });

                // 搜索功能
                const searchInput = document.getElementById('search-input');
                const resetSearchButton = document.getElementById('reset-search');
                const tree = document.querySelector('.tree');

                searchInput.addEventListener('input', function() {
                    const searchTerm = this.value.trim().toLowerCase();
                    filterTree(tree, searchTerm);
                    
                    // 显示/隐藏重置按钮
                    if (searchTerm.length > 0) {
                        resetSearchButton.style.display = 'flex';
                    } else {
                        resetSearchButton.style.display = 'none';
                    }
                });

                // 初始隐藏重置按钮
                resetSearchButton.style.display = 'none';

                // 重置搜索框按钮
                resetSearchButton.addEventListener('click', function() {
                    searchInput.value = '';
                    filterTree(tree, '');
                    this.style.display = 'none';
                    // 重置后恢复展开状态
                    expandAll(document.querySelector('.tree'));
                    // 更新切换按钮状态
                    const toggleAllButton = document.getElementById('toggle-all');
                    toggleAllButton.querySelector('.material-icons').textContent = 'unfold_more';
                });
            });

            function expandAll(node) {
                node.querySelectorAll('.directory-wrapper').forEach(wrapper => {
                    const parentLi = wrapper.parentElement;
                    parentLi.classList.add('open');
                    const toggleIcon = wrapper.querySelector('.toggle .material-icons');
                    toggleIcon.textContent = 'expand_more';
                });
            }

            function collapseAll(node) {
                node.querySelectorAll('.directory-wrapper').forEach(wrapper => {
                    const parentLi = wrapper.parentElement;
                    parentLi.classList.remove('open');
                    const toggleIcon = wrapper.querySelector('.toggle .material-icons');
                    toggleIcon.textContent = 'chevron_right';
                });
            }

            function filterTree(node, searchTerm) {
                const listItems = node.querySelectorAll('li');
                let hasMatches = false;
                
                // 重置所有显示状态
                listItems.forEach(item => {
                    item.style.display = '';
                    item.classList.remove('match-highlight');
                });
                
                // 移除之前的"无结果"提示
                const existingNoResults = node.querySelector('.no-results');
                if (existingNoResults) {
                    existingNoResults.remove();
                }
                
                if (searchTerm === '') {
                    return;
                }
                
                listItems.forEach(item => {
                    const text = item.textContent.toLowerCase();
                    
                    if (text.includes(searchTerm)) {
                        hasMatches = true;
                        // 高亮匹配项
                        item.classList.add('match-highlight');
                        
                        // 确保所有祖先项都可见并展开
                        let parent = item.parentElement;
                        while (parent && parent.classList.contains('tree') === false) {
                            if (parent.tagName === 'UL') {
                                parent.style.display = 'block';
                                const parentLi = parent.parentElement;
                                if (parentLi && parentLi.classList.contains('li')) {
                                    parentLi.classList.add('open');
                                    const toggleIcon = parentLi.querySelector('.toggle .material-icons');
                                    if (toggleIcon) {
                                        toggleIcon.textContent = 'expand_more';
                                    }
                                }
                            }
                            parent = parent.parentElement;
                        }
                    } else {
                        // 只隐藏没有子匹配项的项
                        const hasVisibleChildren = item.querySelector('li[style*="display:"]') !== null;
                        if (!hasVisibleChildren) {
                            item.style.display = 'none';
                        }
                    }
                });
                
                // 如果没有匹配项，显示提示
                if (!hasMatches) {
                    const noResults = document.createElement('li');
                    noResults.textContent = '没有找到匹配项';
                    noResults.className = 'no-results';
                    noResults.style.textAlign = 'center';
                    noResults.style.padding = '20px';
                    noResults.style.color = '#888';
                    node.appendChild(noResults);
                }
            }
        ''')
        self.html_content.append('</script>')
        self.html_content.append('</body>')
        self.html_content.append('</html>')

    def process_directory(self, directory_path):
        dir_name = os.path.basename(directory_path)
        self.html_content.append('<li>')
        self.html_content.append('<div class="directory-wrapper">')
        self.html_content.append('<span class="toggle"><span class="material-icons">chevron_right</span></span>')
        self.html_content.append(f'<span class="directory">{dir_name}</span>')
        self.html_content.append('</div>')
        self.html_content.append('<ul>')

        try:
            contents = os.listdir(directory_path)
        except Exception as e:
            print(f"无法访问目录 {directory_path}: {e}")
            contents = []

        folders = []
        files = []
        for item in contents:
            if item.startswith('.') or item == self.generated_html_name:
                continue
            item_path = os.path.join(directory_path, item)
            if os.path.isdir(item_path):
                folders.append(item)
            else:
                files.append(item)

        files.sort(key=lambda x: x.lower())
        folders.sort(key=lambda x: x.lower())

        for file in files:
            file_path = os.path.join(directory_path, file)
            self.html_content.append('<li>')
            self.html_content.append('<div class="file">')
            self.html_content.append('<span class="file-icon"><span class="material-icons">insert_drive_file</span></span>')
            self.html_content.append(f'<a href="./{os.path.relpath(file_path, self.folder_path).replace("\\", "/")}" target="_blank">{file}</a>')
            self.html_content.append('</div>')
            self.html_content.append('</li>')

        for folder in folders:
            folder_path = os.path.join(directory_path, folder)
            self.process_directory(folder_path)

        self.html_content.append('</ul>')
        self.html_content.append('</li>')

def main():
    folder_path = input("请输入文件夹路径: ").strip()
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        print("指定的路径不存在或不是一个文件夹，请检查后重新输入。")
        return

    generator = DirectoryTreeGenerator(folder_path)
    generator.generate_html()

    html_output = os.path.join(folder_path, generator.generated_html_name)
    with open(html_output, 'w', encoding='utf-8') as f:
        f.write('\n'.join(generator.html_content))

    print(f"HTML文件已生成：{html_output}")
    
    # 提示用户关于图标的使用
    if generator.has_icon:
        print("提示：已使用文件夹中的 ./.APP/favicon.ico 作为网站图标")
    else:
        print("提示：您可以在文件夹中添加名为 './.APP/favicon.ico' 的文件作为网站图标")
    print("注意：生成的HTML文件将不会显示在目录树中")

if __name__ == "__main__":
    main()