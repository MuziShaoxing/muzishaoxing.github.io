import os

def create_folders(base_path, num_levels=3, num_subfolders=5):
    """
    创建多层文件夹
    :param base_path: 根文件夹路径
    :param num_levels: 文件夹层数
    :param num_subfolders: 每层的子文件夹数量
    """
    # 检查根文件夹是否存在，不存在则创建
    if not os.path.exists(base_path):
        os.makedirs(base_path)
        print(f"创建根文件夹：{base_path}")

    # 递归创建子文件夹
    def create_sub_folders(current_path, level):
        if level > num_levels:
            return
        # 在当前路径下创建5个子文件夹
        for i in range(1, num_subfolders + 1):
            subfolder_name = str(i)
            subfolder_path = os.path.join(current_path, subfolder_name)
            os.makedirs(subfolder_path, exist_ok=True)
            print(f"创建文件夹：{subfolder_path}")
            # 在每个子文件夹中创建一个示例文件
            file_name = f"file_{subfolder_name}.txt"
            file_path = os.path.join(subfolder_path, file_name)
            with open(file_path, "w") as f:
                f.write(f"这是第{level}层的文件夹{subfolder_name}中的文件")
            print(f"创建文件：{file_path}")
        # 递归创建下一层
        for i in range(1, num_subfolders + 1):
            next_path = os.path.join(current_path, str(i))
            create_sub_folders(next_path, level + 1)

    # 从根文件夹开始递归创建
    create_sub_folders(base_path, 1)

if __name__ == "__main__":
    # 设置根文件夹路径
    root_folder_path = "主目录"
    create_folders(root_folder_path)
    print("文件夹和文件创建完成！")