@echo off
chcp 65001 >nul
title Excel通讯录转换工具 - 安装依赖

echo.
echo ========================================
echo    Excel通讯录转换工具 - 依赖安装
echo ========================================
echo.

echo [1/3] 检查 Python 环境...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未检测到 Python，请先安装 Python 3.7 或更高版本
    echo 下载地址：https://www.python.org/downloads/
    pause
    exit /b 1
)
python --version
echo.

echo [2/3] 升级 pip 到最新版本...
python -m pip install --upgrade pip
echo.

echo [3/3] 安装所需依赖包...
echo.
echo 正在安装 pandas（Excel文件处理）...
pip install pandas

echo.
echo 正在安装 openpyxl（Excel文件读写）...
pip install openpyxl

echo.
echo 正在安装 tkinterdnd2（拖拽功能支持，可选）...
pip install tkinterdnd2

echo.
echo ========================================
echo    安装完成！
echo ========================================
echo.
echo 已安装的依赖包：
pip list | findstr "pandas openpyxl tkinterdnd2"
echo.
echo 现在可以运行 Excel通讯录转换工具.py 了
echo.
pause