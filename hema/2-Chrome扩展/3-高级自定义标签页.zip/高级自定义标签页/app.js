
    (() => {
      /* ====== 数据 ====== */
      const engines = {
        bing: { name: 'Bing', url: 'https://www.bing.com/search?q=', icon: 'https://www.bing.com/favicon.ico' },
        baidu: { name: '百度', url: 'https://www.baidu.com/s?wd=', icon: 'https://www.baidu.com/favicon.ico' },
        sogou: { name: '搜狗', url: 'https://www.sogou.com/web?query=', icon: 'https://www.sogou.com/favicon.ico' }
      };
      
      // 初始数据结构（支持多个抽屉）
      let appData = JSON.parse(localStorage.getItem('navPageData') || JSON.stringify({
        drawers: [
           { 
            id: 'default', 
            name: '我的书签', 
            bookmarks: [] // 这里改为空数组
          },

        ],
        currentDrawer: 'default',
        engine: 'bing',
        darkMode: false,
        editMode: false,
        seenDragHint: false,
        wallpaper: null
      }));
      
      // 当前选中的抽屉
      let currentDrawer = appData.currentDrawer;
      
      // 当前编辑的书签ID（用于编辑模式）
      let editingBookmarkId = null;
      // 当前编辑的抽屉ID（用于编辑模式）
      let editingDrawerId = null;
      
      // 当前是否处于编辑模式
      let editMode = appData.editMode;
      
      // DOM元素
      const dom = {
        links: document.getElementById('links'),
        search: document.getElementById('search'),
        engineIcon: document.getElementById('engine-icon'),
        engineName: document.getElementById('engine-name'),
        themeToggle: document.getElementById('theme-toggle'),
        editModeToggle: document.getElementById('edit-mode-toggle'),
        settingsBtn: document.getElementById('settings-btn'),
        addBtn: document.getElementById('add-link-btn'),
        linkModal: document.getElementById('link-modal'),
        drawerModal: document.getElementById('drawer-modal'),
        settingsModal: document.getElementById('settings-modal'),
        clearConfirmModal: document.getElementById('clear-confirm-modal'),
        wallpaperModal: document.getElementById('wallpaper-modal'),
        importFile: document.getElementById('import-file'),
        drawerNav: document.getElementById('drawer-nav'),
        currentDrawerName: document.getElementById('current-drawer-name'),
        linkDrawerSelect: document.getElementById('link-drawer'),
        notification: document.getElementById('notification'),
        engineSelector: document.getElementById('engine-selector'),
        dragHint: document.getElementById('drag-hint'),
        clearCancelBtn: document.getElementById('clear-cancel-btn'),
        clearConfirmBtn: document.getElementById('clear-confirm-btn'),
        saveLinkBtn: document.getElementById('save-link-btn'),
        saveDrawerBtn: document.getElementById('save-drawer-btn'),
        linkModalTitle: document.getElementById('link-modal-title'),
        drawerModalTitle: document.getElementById('drawer-modal-title')
      };

      /* ====== 工具函数 ====== */
      // 保存数据到localStorage
      const saveData = () => {
        appData.editMode = editMode;
        localStorage.setItem('navPageData', JSON.stringify(appData));
      };
      
      // 获取favicon
      const getFavicon = (url) => {
        try {
          return `https://favicon.im/${new URL(url).hostname}?larger=true`;
        } catch {
          return 'https://favicon.im/default?larger=true';
        }
      };
      
      // 生成唯一ID
      const uuid = () => '_' + Math.random().toString(36).substr(2, 9);
      
      // 显示通知
      const showNotification = (message, isSuccess = true) => {
        const noti = dom.notification;
        noti.querySelector('.notification-content').textContent = message;
        noti.className = `notification ${isSuccess ? 'success' : 'error'} show`;
        noti.querySelector('i').className = isSuccess ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
        
        setTimeout(() => {
          noti.classList.remove('show');
        }, 3000);
      };
      
      // 关闭所有模态框
      const closeAllModals = () => {
        document.querySelectorAll('.modal').forEach(modal => {
          modal.classList.remove('active');
        });
      };
      
      // 显示拖动提示
      const showDragHint = () => {
        if (appData.seenDragHint) return;
        
        dom.dragHint.classList.add('show');
        setTimeout(() => {
          dom.dragHint.classList.remove('show');
          appData.seenDragHint = true;
          saveData();
        }, 5000);
      };
      
      // 应用壁纸
      const applyWallpaper = () => {
        if (appData.wallpaper) {
          document.documentElement.style.setProperty('--wallpaper', `url(${appData.wallpaper})`);
        } else {
          document.documentElement.style.setProperty('--wallpaper', 'none');
        }
      };

      // 更新编辑模式按钮状态
      const updateEditModeButton = () => {
        if (editMode) {
          dom.editModeToggle.innerHTML = '<i class="fas fa-lock-open"></i>';
          document.body.classList.add('edit-mode');
        } else {
          dom.editModeToggle.innerHTML = '<i class="fas fa-lock"></i>';
          document.body.classList.remove('edit-mode');
        }
      };

      /* ====== 渲染函数 ====== */
      // 渲染抽屉导航
      function renderDrawerNav() {
        dom.drawerNav.innerHTML = '';
        
        appData.drawers.forEach(drawer => {
          const btn = document.createElement('button');
          btn.className = `drawer-btn ${drawer.id === currentDrawer ? 'active' : ''}`;
          btn.innerHTML = `
            <i class="fas fa-folder${drawer.id === currentDrawer ? '-open' : ''}"></i>
            <span>${drawer.name}</span>
            <div class="drawer-actions">
              <button class="drawer-action-btn edit-drawer-btn" title="编辑分类">✎</button>
              <button class="drawer-action-btn delete-drawer-btn" title="删除分类">×</button>
            </div>
          `;
          btn.dataset.id = drawer.id;
          
          btn.onclick = (e) => {
            // 防止点击操作按钮时切换抽屉
            if (!e.target.closest('.drawer-action-btn')) {
              currentDrawer = drawer.id;
              appData.currentDrawer = drawer.id;
              saveData();
              renderDrawerNav();
              renderBookmarks();
              dom.currentDrawerName.textContent = drawer.name;
            }
          };
          
          // 添加抽屉排序拖拽事件
          if (editMode) {
            btn.setAttribute('draggable', 'true');
            btn.addEventListener('dragstart', handleDrawerDragStart);
            btn.addEventListener('dragover', handleDrawerSortDragover);
            btn.addEventListener('drop', handleDrawerSortDrop);
            btn.addEventListener('dragend', handleDrawerDragEnd);
          } else {
            btn.removeAttribute('draggable');
            btn.removeEventListener('dragstart', handleDrawerDragStart);
            btn.removeEventListener('dragover', handleDrawerSortDragover);
            btn.removeEventListener('drop', handleDrawerSortDrop);
            btn.removeEventListener('dragend', handleDrawerDragEnd);
          }
          
          // 添加分类拖放事件
          if (editMode) {
            btn.addEventListener('dragover', handleDrawerDragover);
            btn.addEventListener('dragleave', handleDrawerDragleave);
            btn.addEventListener('drop', handleDrawerDrop);
          } else {
            btn.removeEventListener('dragover', handleDrawerDragover);
            btn.removeEventListener('dragleave', handleDrawerDragleave);
            btn.removeEventListener('drop', handleDrawerDrop);
          }
          
          // 编辑分类按钮
          const editBtn = btn.querySelector('.edit-drawer-btn');
          editBtn.onclick = (e) => {
            e.stopPropagation();
            editingDrawerId = drawer.id;
            document.getElementById('drawer-name').value = drawer.name;
            dom.drawerModalTitle.textContent = '编辑分类';
            dom.drawerModal.classList.add('active');
          };
          
          // 删除分类按钮
          const deleteBtn = btn.querySelector('.delete-drawer-btn');
          deleteBtn.onclick = (e) => {
            e.stopPropagation();
            if (drawer.bookmarks.length > 0) {
              if (!confirm(`确定要删除分类 "${drawer.name}" 吗？此操作将删除其中的 ${drawer.bookmarks.length} 个书签！`)) {
                return;
              }
            }
            
            // 删除分类
            appData.drawers = appData.drawers.filter(d => d.id !== drawer.id);
            
            // 如果删除的是当前分类，切换到第一个分类
            if (currentDrawer === drawer.id && appData.drawers.length > 0) {
              currentDrawer = appData.drawers[0].id;
              appData.currentDrawer = currentDrawer;
            }
            
            saveData();
            renderDrawerNav();
            renderBookmarks();
            
            if (appData.drawers.length > 0) {
              dom.currentDrawerName.textContent = appData.drawers.find(d => d.id === currentDrawer).name;
            } else {
              // 如果没有分类了，添加一个默认分类
              const newDrawer = {
                id: 'default',
                name: '我的书签',
                bookmarks: []
              };
              appData.drawers.push(newDrawer);
              currentDrawer = 'default';
              appData.currentDrawer = currentDrawer;
              saveData();
              renderDrawerNav();
              renderBookmarks();
              dom.currentDrawerName.textContent = newDrawer.name;
            }
            
            showNotification(`分类 "${drawer.name}" 已删除`);
          };
          
          dom.drawerNav.appendChild(btn);
        });
        
        // 添加"新建分类"按钮
        const addBtn = document.createElement('button');
        addBtn.className = 'drawer-btn add-drawer-btn';
        addBtn.innerHTML = '<i class="fas fa-plus"></i> 新建分类';
        addBtn.onclick = () => {
          editingDrawerId = null;
          document.getElementById('drawer-name').value = '';
          dom.drawerModalTitle.textContent = '添加分类';
          dom.drawerModal.classList.add('active');
        };
        dom.drawerNav.appendChild(addBtn);
      }
      
      // 渲染书签选择抽屉下拉框
      function renderDrawerSelect() {
        dom.linkDrawerSelect.innerHTML = '';
        
        appData.drawers.forEach(drawer => {
          const option = document.createElement('option');
          option.value = drawer.id;
          option.textContent = drawer.name;
          option.selected = drawer.id === currentDrawer;
          dom.linkDrawerSelect.appendChild(option);
        });
      }
      
      // 渲染书签
      function renderBookmarks() {
        dom.links.innerHTML = '';
        
        const drawer = appData.drawers.find(d => d.id === currentDrawer);
        if (!drawer) return;
        
        if (drawer.bookmarks.length === 0) {
          dom.links.innerHTML = `
            <div class="empty-state">
              <i class="fas fa-book-open"></i>
              <p>此分类还没有书签，点击右上角"添加书签"按钮开始添加</p>
            </div>
          `;
          return;
        }
        
        drawer.bookmarks.forEach((bookmark, index) => {
          const div = document.createElement('div');
          div.className = 'link-item';
          div.dataset.id = bookmark.id;
          div.dataset.index = index;
          div.innerHTML = `
            <div class="link-icon-container">
              <img class="link-icon" src="${bookmark.favicon}" alt="${bookmark.name}">
            </div>
            <div class="link-name" data-name="${bookmark.name}">${bookmark.name}</div>
            <div class="link-actions">
              <button class="action-btn edit-btn" title="编辑">✎</button>
              <button class="action-btn delete-btn" title="删除">×</button>
            </div>
          `;
          
          div.querySelector('.delete-btn').onclick = e => {
            e.stopPropagation();
            const drawerIndex = appData.drawers.findIndex(d => d.id === currentDrawer);
            if (drawerIndex !== -1) {
              appData.drawers[drawerIndex].bookmarks = appData.drawers[drawerIndex].bookmarks.filter(b => b.id !== bookmark.id);
              saveData();
              renderBookmarks();
              showNotification('书签已删除');
            }
          };
          
          div.querySelector('.edit-btn').onclick = e => {
            e.stopPropagation();
            editingBookmarkId = bookmark.id;
            document.getElementById('link-name').value = bookmark.name;
            document.getElementById('link-url').value = bookmark.url;
            renderDrawerSelect();
            document.getElementById('link-drawer').value = currentDrawer;
            dom.linkModalTitle.textContent = '编辑书签';
            dom.linkModal.classList.add('active');
          };
          
          div.onclick = () => {
            if (!editMode) {
              window.open(bookmark.url, '_blank');
            }
          };
          
          // 添加拖拽事件
          if (editMode) {
            div.setAttribute('draggable', 'true');
            div.addEventListener('dragstart', handleDragStart);
            div.addEventListener('dragover', handleDragOver);
            div.addEventListener('drop', handleDrop);
            div.addEventListener('dragend', handleDragEnd);
            div.addEventListener('dragleave', handleDragLeave);
            
            // 添加长按事件（移动端）
            let longPressTimer;
            div.addEventListener('touchstart', (e) => {
              longPressTimer = setTimeout(() => {
                handleDragStart(e);
                e.preventDefault();
              }, 500);
            });
            
            div.addEventListener('touchend', () => {
              clearTimeout(longPressTimer);
            });
            
            div.addEventListener('touchmove', () => {
              clearTimeout(longPressTimer);
            });
          } else {
            div.removeAttribute('draggable');
            div.removeEventListener('dragstart', handleDragStart);
            div.removeEventListener('dragover', handleDragOver);
            div.removeEventListener('drop', handleDrop);
            div.removeEventListener('dragend', handleDragEnd);
            div.removeEventListener('dragleave', handleDragLeave);
            
            // 移除长按事件
            div.removeEventListener('touchstart', handleDragStart);
            div.removeEventListener('touchend', () => {});
            div.removeEventListener('touchmove', () => {});
          }
          
          dom.links.appendChild(div);
        });
        
        // 显示拖动提示（如果用户还没看过）
        if (!appData.seenDragHint && editMode) {
          setTimeout(showDragHint, 1000);
        }
      }
      
      // 初始化渲染
      function initRender() {
        renderDrawerNav();
        renderDrawerSelect();
        renderBookmarks();
        
        // 设置当前抽屉名称
        const current = appData.drawers.find(d => d.id === currentDrawer);
        if (current) {
          dom.currentDrawerName.textContent = current.name;
        }
        
        // 应用壁纸
        applyWallpaper();
        
        // 更新编辑模式按钮状态
        updateEditModeButton();
      }

      /* ====== 搜索功能 ====== */
      function setEngine(key) {
        appData.engine = key;
        dom.engineIcon.src = engines[key].icon;
        dom.engineName.textContent = engines[key].name;
        saveData();
        
        // 显示切换通知
        showNotification(`搜索引擎已切换为 ${engines[key].name}`);
      }
      
      function initSearch() {
        // 设置初始搜索引擎
        setEngine(appData.engine);
        
        // 点击切换搜索引擎
        dom.engineSelector.onclick = () => {
          // 获取当前引擎索引
          const engineKeys = Object.keys(engines);
          const currentIndex = engineKeys.indexOf(appData.engine);
          
          // 计算下一个引擎索引
          const nextIndex = (currentIndex + 1) % engineKeys.length;
          const nextEngine = engineKeys[nextIndex];
          
          // 设置新引擎
          setEngine(nextEngine);
          
          // 显示切换动画
          dom.engineSelector.style.transform = 'scale(0.95)';
          setTimeout(() => {
            dom.engineSelector.style.transform = 'scale(1)';
          }, 150);
        };
        
        // 搜索框回车事件
        dom.search.onkeydown = e => {
          if (e.key === 'Enter') {
            window.open(engines[appData.engine].url + encodeURIComponent(dom.search.value), '_blank');
          }
        };
        
        // 搜索按钮点击事件
        document.querySelector('.search-btn').onclick = () => {
          if (dom.search.value.trim()) {
            window.open(engines[appData.engine].url + encodeURIComponent(dom.search.value), '_blank');
          }
        };
      }

      /* ====== 主题功能 ====== */
      function initTheme() {
        // 应用保存的主题设置
        if (appData.darkMode) {
          document.body.classList.add('dark');
          dom.themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
          document.body.classList.remove('dark');
          dom.themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        }
        
        // 主题切换按钮
        dom.themeToggle.onclick = () => {
          appData.darkMode = !appData.darkMode;
          saveData();
          
          if (appData.darkMode) {
            document.body.classList.add('dark');
            dom.themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
          } else {
            document.body.classList.remove('dark');
            dom.themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
          }
        };
      }

      /* ====== 编辑模式功能 ====== */
      function initEditMode() {
        dom.editModeToggle.onclick = () => {
          editMode = !editMode;
          saveData();
          updateEditModeButton();
          renderDrawerNav();
          renderBookmarks();
          showNotification(editMode ? '编辑模式已开启' : '编辑模式已关闭');
        };
      }

      /* ====== 书签拖拽功能 ====== */
      let draggedItem = null;
      let draggedIndex = -1;
      let draggedDrawer = null;
      
      function handleDragStart(e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        
        // 桌面端使用原生拖拽事件
        if (e.type === 'dragstart') {
          draggedItem = e.target.closest('.link-item');
          draggedIndex = parseInt(draggedItem.dataset.index);
          draggedDrawer = currentDrawer;
          
          // 添加拖动样式
          draggedItem.classList.add('dragging');
          
          // 设置数据
          e.dataTransfer.setData('text/plain', JSON.stringify({
            bookmarkId: draggedItem.dataset.id,
            drawerId: currentDrawer,
            index: draggedIndex
          }));
        } 
        // 移动端模拟拖拽
        else if (e.type === 'touchstart') {
          draggedItem = e.target.closest('.link-item');
          draggedIndex = parseInt(draggedItem.dataset.index);
          draggedDrawer = currentDrawer;
          
          // 添加拖动样式
          draggedItem.classList.add('dragging');
        }
      }
      
      function handleDragOver(e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        
        e.preventDefault();
        
        const target = e.target.closest('.link-item');
        if (target && target !== draggedItem) {
          // 添加悬停样式
          target.classList.add('over');
        }
      }
      
      function handleDrop(e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        
        e.preventDefault();
        
        // 获取目标书签元素
        const target = e.target.closest('.link-item');
        if (!target || !draggedItem) return;
        
        // 移除悬停样式
        document.querySelectorAll('.link-item').forEach(item => {
          item.classList.remove('over');
        });
        
        const targetIndex = parseInt(target.dataset.index);
        const drawerIndex = appData.drawers.findIndex(d => d.id === currentDrawer);
        
        if (drawerIndex !== -1) {
          // 同一分类内移动
          const bookmarks = appData.drawers[drawerIndex].bookmarks;
          
          // 保存被拖动的书签
          const draggedBookmark = bookmarks[draggedIndex];
          
          // 从原位置移除
          bookmarks.splice(draggedIndex, 1);
          
          // 插入到新位置
          if (draggedIndex < targetIndex) {
            bookmarks.splice(targetIndex - 1, 0, draggedBookmark);
          } else {
            bookmarks.splice(targetIndex, 0, draggedBookmark);
          }
          
          // 保存并重新渲染
          saveData();
          renderBookmarks();
        }
      }
      
      function handleDragEnd() {
        // 移除拖动样式
        document.querySelectorAll('.link-item').forEach(item => {
          item.classList.remove('dragging');
          item.classList.remove('over');
        });
        
        draggedItem = null;
        draggedIndex = -1;
      }
      
      function handleDragLeave(e) {
        const target = e.target.closest('.link-item');
        if (target) {
          target.classList.remove('over');
        }
      }
      
      // 处理抽屉按钮上的拖拽事件
      function handleDrawerDragover(e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        
        e.preventDefault();
        const drawerBtn = e.target.closest('.drawer-btn');
        if (drawerBtn) {
          drawerBtn.classList.add('drop-target');
        }
      }
      
      function handleDrawerDragleave(e) {
        const drawerBtn = e.target.closest('.drawer-btn');
        if (drawerBtn) {
          drawerBtn.classList.remove('drop-target');
        }
      }
      
      function handleDrawerDrop(e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        
        e.preventDefault();
        const targetDrawerBtn = e.target.closest('.drawer-btn');
        if (targetDrawerBtn) {
          targetDrawerBtn.classList.remove('drop-target');
        }
        
        // 获取目标抽屉ID
        const targetDrawerId = targetDrawerBtn?.dataset.id;
        if (!targetDrawerId || !draggedItem) return;
        
        // 如果目标抽屉和源抽屉相同，则不做操作
        if (targetDrawerId === draggedDrawer) {
          return;
        }
        
        // 查找源抽屉和目标抽屉
        const sourceDrawerIndex = appData.drawers.findIndex(d => d.id === draggedDrawer);
        const targetDrawerIndex = appData.drawers.findIndex(d => d.id === targetDrawerId);
        
        if (sourceDrawerIndex !== -1 && targetDrawerIndex !== -1) {
          // 获取被拖动的书签
          const sourceBookmarks = appData.drawers[sourceDrawerIndex].bookmarks;
          const draggedBookmark = sourceBookmarks[draggedIndex];
          
          // 从源抽屉中移除
          sourceBookmarks.splice(draggedIndex, 1);
          
          // 添加到目标抽屉
          appData.drawers[targetDrawerIndex].bookmarks.push(draggedBookmark);
          
          // 保存数据
          saveData();
          
          // 如果当前抽屉是源抽屉或目标抽屉，重新渲染书签
          if (currentDrawer === draggedDrawer || currentDrawer === targetDrawerId) {
            renderBookmarks();
          }
          
          // 显示成功通知
          showNotification(`书签已移动到"${appData.drawers[targetDrawerIndex].name}"分类`);
        }
      }
      
      /* ====== 书签分类拖拽排序 ====== */
      let draggedDrawerItem = null;
      let draggedDrawerIndex = -1;
      
      function handleDrawerDragStart(e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        
        draggedDrawerItem = e.target.closest('.drawer-btn');
        draggedDrawerIndex = Array.from(dom.drawerNav.children).indexOf(draggedDrawerItem);
        
        // 添加拖动样式
        draggedDrawerItem.classList.add('dragging');
        
        // 设置数据
        e.dataTransfer.setData('text/plain', JSON.stringify({
          drawerId: draggedDrawerItem.dataset.id,
          index: draggedDrawerIndex
        }));
      }
      
      function handleDrawerSortDragover(e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        
        e.preventDefault();
        const target = e.target.closest('.drawer-btn');
        if (target && target !== draggedDrawerItem) {
          // 添加悬停样式
          target.classList.add('over');
        }
      }
      
      function handleDrawerSortDrop(e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        
        e.preventDefault();
        const target = e.target.closest('.drawer-btn');
        if (!target || !draggedDrawerItem) return;
        
        // 移除悬停样式
        document.querySelectorAll('.drawer-btn').forEach(btn => {
          btn.classList.remove('over');
        });
        
        const targetIndex = Array.from(dom.drawerNav.children).indexOf(target);
        
        // 保存被拖动的抽屉
        const draggedDrawer = appData.drawers[draggedDrawerIndex];
        
        // 从原位置移除
        appData.drawers.splice(draggedDrawerIndex, 1);
        
        // 插入到新位置
        if (draggedDrawerIndex < targetIndex) {
          appData.drawers.splice(targetIndex - 1, 0, draggedDrawer);
        } else {
          appData.drawers.splice(targetIndex, 0, draggedDrawer);
        }
        
        // 保存并重新渲染
        saveData();
        renderDrawerNav();
        
        // 显示成功通知
        showNotification('分类顺序已更新');
      }
      
      function handleDrawerDragEnd() {
        // 移除拖动样式
        document.querySelectorAll('.drawer-btn').forEach(btn => {
          btn.classList.remove('dragging');
          btn.classList.remove('over');
        });
        
        draggedDrawerItem = null;
        draggedDrawerIndex = -1;
      }

      /* ====== 书签管理 ====== */
      function initBookmarkManagement() {
        // 添加书签按钮
        dom.addBtn.onclick = () => {
          editingBookmarkId = null;
          document.getElementById('link-name').value = '';
          document.getElementById('link-url').value = '';
          renderDrawerSelect();
          dom.linkModalTitle.textContent = '添加书签';
          dom.linkModal.classList.add('active');
        };
        
        // 保存书签按钮
        dom.saveLinkBtn.onclick = () => {
          const name = document.getElementById('link-name').value.trim();
          const url = document.getElementById('link-url').value.trim();
          const drawerId = document.getElementById('link-drawer').value;
          
          if (!name || !url) {
            showNotification('名称和网址不能为空', false);
            return;
          }
          
          try {
            new URL(url);
          } catch {
            showNotification('请输入有效的网址', false);
            return;
          }
          
          const drawerIndex = appData.drawers.findIndex(d => d.id === drawerId);
          if (drawerIndex !== -1) {
            if (editingBookmarkId) {
              // 查找原始书签位置
              let originalDrawerIndex = -1;
              let bookmarkIndex = -1;
              
              for (let i = 0; i < appData.drawers.length; i++) {
                bookmarkIndex = appData.drawers[i].bookmarks.findIndex(b => b.id === editingBookmarkId);
                if (bookmarkIndex !== -1) {
                  originalDrawerIndex = i;
                  break;
                }
              }
              
              // 如果分类改变了
              if (originalDrawerIndex !== -1 && originalDrawerIndex !== drawerIndex) {
                // 从原分类移除书签
                const [bookmark] = appData.drawers[originalDrawerIndex].bookmarks.splice(bookmarkIndex, 1);
                
                // 更新书签信息
                bookmark.name = name;
                bookmark.url = url;
                
                // 添加到新分类
                appData.drawers[drawerIndex].bookmarks.push(bookmark);
              } else {
                // 同分类内更新书签
                const bookmark = appData.drawers[drawerIndex].bookmarks[bookmarkIndex];
                bookmark.name = name;
                bookmark.url = url;
                bookmark.favicon = getFavicon(url);
              }
            } else {
              // 添加新书签
              appData.drawers[drawerIndex].bookmarks.push({
                id: uuid(),
                name,
                url,
                favicon: getFavicon(url)
              });
            }
            
            saveData();
            renderBookmarks();
            closeAllModals();
            showNotification(editingBookmarkId ? '书签修改成功' : '书签添加成功');
          }
        };
        
        // 添加/编辑抽屉模态框保存按钮
        dom.saveDrawerBtn.onclick = () => {
          const name = document.getElementById('drawer-name').value.trim();
          
          if (!name) {
            showNotification('分类名称不能为空', false);
            return;
          }
          
          if (editingDrawerId) {
            // 编辑现有分类
            const drawerIndex = appData.drawers.findIndex(d => d.id === editingDrawerId);
            if (drawerIndex !== -1) {
              appData.drawers[drawerIndex].name = name;
            }
          } else {
            // 添加新分类
            // 检查是否已存在同名分类
            if (appData.drawers.some(d => d.name === name)) {
              showNotification('分类名称已存在', false);
              return;
            }
            
            const newDrawer = {
              id: uuid(),
              name,
              bookmarks: []
            };
            
            appData.drawers.push(newDrawer);
          }
          
          saveData();
          renderDrawerNav();
          closeAllModals();
          showNotification(editingDrawerId ? `分类"${name}"修改成功` : `分类"${name}"创建成功`);
        };
      }

      /* ====== 设置功能 ====== */
      function initSettings() {
        // 打开设置面板
        dom.settingsBtn.onclick = () => dom.settingsModal.classList.add('active');
        
        // 导出书签
        document.getElementById('export-btn').onclick = () => {
          const html = buildChromeHtml();
          download('bookmarks.html', html);
          closeAllModals();
          showNotification('书签导出成功');
        };
        
        // 导入书签
        document.getElementById('import-btn').onclick = () => {
          dom.importFile.accept = ".html";
          dom.importFile.onchange = handleImportHtml;
          dom.importFile.click();
        };
        
        // 恢复数据按钮
        document.getElementById('restore-btn').onclick = () => {
          dom.importFile.accept = ".json";
          dom.importFile.onchange = handleRestoreJson;
          dom.importFile.click();
        };
        
        // 清空书签 - 增强功能：移除所有数据
        document.getElementById('clear-btn').onclick = () => {
          dom.clearConfirmModal.classList.add('active');
        };
        
        // 清空确认按钮
        dom.clearConfirmBtn.onclick = () => {
          if (appData.drawers.length > 0) {
            // 重置为初始状态
            appData.drawers = [{
              id: 'default',
              name: '我的书签',
              bookmarks: []
            }];
            currentDrawer = 'default';
            appData.currentDrawer = currentDrawer;
            appData.engine = 'bing';
            appData.darkMode = false;
            appData.editMode = false;
            appData.seenDragHint = false;
            appData.wallpaper = null;
            
            // 保存并重新渲染
            saveData();
            initRender();
            setEngine(appData.engine);
            initTheme();
            applyWallpaper();
            
            closeAllModals();
            showNotification('所有数据已清空');
          }
        };
        
        // 清空取消按钮
        dom.clearCancelBtn.onclick = () => {
          dom.clearConfirmModal.classList.remove('active');
        };
        
// 备份数据
document.getElementById('backup-btn').onclick = () => {
  const dataStr = JSON.stringify(appData);
  const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
  
  // 生成时间戳 (格式: YYMMDD)
  const now = new Date();
  const year = String(now.getFullYear()).slice(-2); // 取年份后两位
  const month = String(now.getMonth() + 1).padStart(2, '0'); // 月份补零
  const day = String(now.getDate()).padStart(2, '0'); // 日期补零
  const timeStamp = `${year}${month}${day}`;
  
  // 在文件名中添加时间戳
  const exportName = `少星导航页-数据备份-${timeStamp}.json`;
  
  const link = document.createElement('a');
  link.setAttribute('href', dataUri);
  link.setAttribute('download', exportName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  closeAllModals();
  showNotification('数据备份成功');
};
        
        // 壁纸设置按钮
        document.getElementById('wallpaper-btn').onclick = () => {
          // 打开壁纸设置模态框
          dom.wallpaperModal.classList.add('active');
          
          // 重置输入框
          document.getElementById('wallpaper-api').value = '';
          document.getElementById('wallpaper-url').value = '';
          document.getElementById('wallpaper-upload').value = '';
          
          // 设置当前壁纸预览
          const preview = document.getElementById('wallpaper-preview');
          preview.className = 'wallpaper-preview empty';
          preview.innerHTML = '<i class="fas fa-image"></i>';
          
          // 如果已有壁纸，显示预览
          if (appData.wallpaper) {
            preview.style.backgroundImage = `url(${appData.wallpaper})`;
            preview.className = 'wallpaper-preview';
            preview.innerHTML = '';
          }
        };
        
        // 壁纸选项切换
        const wallpaperOptions = document.querySelectorAll('.wallpaper-option-btn');
        wallpaperOptions.forEach(option => {
          option.addEventListener('click', () => {
            wallpaperOptions.forEach(btn => btn.classList.remove('active'));
            option.classList.add('active');
          });
        });
        
        // 壁纸输入变化时更新预览
        document.getElementById('wallpaper-api').addEventListener('input', updateWallpaperPreview);
        document.getElementById('wallpaper-url').addEventListener('input', updateWallpaperPreview);
        document.getElementById('wallpaper-upload').addEventListener('change', handleWallpaperUpload);
        
        // 保存壁纸设置
        document.getElementById('save-wallpaper').onclick = () => {
          const selectedOption = document.querySelector('.wallpaper-option-btn.active').dataset.type;
          let wallpaperUrl = '';
          
          switch(selectedOption) {
            case 'api':
              wallpaperUrl = document.getElementById('wallpaper-api').value.trim();
              break;
            case 'url':
              wallpaperUrl = document.getElementById('wallpaper-url').value.trim();
              break;
            case 'upload':
              const fileInput = document.getElementById('wallpaper-upload');
              if (fileInput.files.length > 0) {
                const file = fileInput.files[0];
                const reader = new FileReader();
                reader.onload = () => {
                  wallpaperUrl = reader.result;
                  saveWallpaper(wallpaperUrl);
                };
                reader.readAsDataURL(file);
                return; // 等待读取完成
              } else {
                showNotification('请选择上传的图片', false);
                return;
              }
          }
          
          if (!wallpaperUrl) {
            showNotification('请输入有效的壁纸设置', false);
            return;
          }
          
          saveWallpaper(wallpaperUrl);
        };
        
        function updateWallpaperPreview() {
          const preview = document.getElementById('wallpaper-preview');
          const selectedOption = document.querySelector('.wallpaper-option-btn.active').dataset.type;
          let url = '';
          
          if (selectedOption === 'api') {
            url = document.getElementById('wallpaper-api').value.trim();
          } else if (selectedOption === 'url') {
            url = document.getElementById('wallpaper-url').value.trim();
          }
          
          if (url) {
            preview.style.backgroundImage = `url(${url})`;
            preview.className = 'wallpaper-preview';
            preview.innerHTML = '';
          } else {
            preview.style.backgroundImage = '';
            preview.className = 'wallpaper-preview empty';
            preview.innerHTML = '<i class="fas fa-image"></i>';
          }
        }
        
        function handleWallpaperUpload(e) {
          const file = e.target.files[0];
          if (!file) return;
          
          if (!file.type.match('image.*')) {
            showNotification('请选择图片文件', false);
            return;
          }
          
          const reader = new FileReader();
          reader.onload = () => {
            const preview = document.getElementById('wallpaper-preview');
            preview.style.backgroundImage = `url(${reader.result})`;
            preview.className = 'wallpaper-preview';
            preview.innerHTML = '';
          };
          reader.readAsDataURL(file);
        }
        
        function saveWallpaper(url) {
          appData.wallpaper = url;
          saveData();
          applyWallpaper();
          closeAllModals();
          showNotification('壁纸设置成功');
        }
      }

      /* ====== Chrome书签HTML处理 ====== */
      function buildChromeHtml() {
        let html = `<!DOCTYPE NETSCAPE-Bookmark-file-1>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
`;
        
        appData.drawers.forEach(drawer => {
          html += `<DT><H3>${drawer.name}</H3>\n<DL><p>\n`;
          
          drawer.bookmarks.forEach(bookmark => {
            html += `<DT><A HREF="${bookmark.url}">${bookmark.name}</A>\n`;
          });
          
          html += `</DL><p>\n`;
        });
        
        html += '</DL><p>';
        return html;
      }
      
      function parseChromeHtml(html) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const result = { drawers: [] };
        
        // 解析文件夹
        const folders = doc.querySelectorAll('h3');
        folders.forEach(folder => {
          const folderName = folder.textContent;
          const nextSibling = folder.nextElementSibling;
          
          if (nextSibling && nextSibling.tagName === 'DL') {
            const links = nextSibling.querySelectorAll('a');
            const bookmarks = [];
            
            links.forEach(link => {
              bookmarks.push({
                id: uuid(),
                name: link.textContent,
                url: link.href,
                favicon: getFavicon(link.href)
              });
            });
            
            if (bookmarks.length > 0) {
              result.drawers.push({
                id: uuid(),
                name: folderName,
                bookmarks
              });
            }
          }
        });
        
        return result;
      }
      
      // 导入书签处理函数 (HTML格式)
      function handleImportHtml(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = () => {
          try {
            const importedData = parseChromeHtml(reader.result);
            
            if (importedData.drawers.length > 0) {
              appData.drawers = importedData.drawers;
              currentDrawer = appData.drawers[0].id;
              appData.currentDrawer = currentDrawer;
              saveData();
              initRender();
              closeAllModals();
              showNotification(`成功导入${importedData.drawers.length}个分类`);
            } else {
              showNotification('未找到可导入的书签', false);
            }
          } catch (error) {
            console.error(error);
            showNotification('导入失败，文件格式不正确', false);
          }
          
          // 重置input
          e.target.value = '';
        };
        reader.readAsText(file);
      }
      
      // 恢复数据处理函数 (JSON格式)
      function handleRestoreJson(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = () => {
          try {
            const backupData = JSON.parse(reader.result);
            
            // 验证备份数据结构
            if (backupData.drawers && Array.isArray(backupData.drawers)) {
              appData = backupData;
              currentDrawer = appData.currentDrawer;
              editMode = appData.editMode || false;
              saveData();
              initRender();
              setEngine(appData.engine);
              initTheme();
              applyWallpaper();
              closeAllModals();
              showNotification('数据恢复成功');
            } else {
              showNotification('无效的备份文件', false);
            }
          } catch (error) {
            console.error(error);
            showNotification('恢复失败，文件格式不正确', false);
          }
          
          // 重置input
          e.target.value = '';
        };
        reader.readAsText(file);
      }
      
      function download(filename, content) {
        const blob = new Blob([content], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
      }

      /* ====== 事件绑定 ====== */
      function initEventListeners() {
        // 关闭模态框
        document.querySelectorAll('.close-modal, .cancel-btn').forEach(btn => {
          btn.onclick = function() {
            this.closest('.modal').classList.remove('active');
          };
        });
        
        // 点击模态框外部关闭
        document.querySelectorAll('.modal').forEach(modal => {
          modal.onclick = e => {
            if (e.target === modal) {
              modal.classList.remove('active');
            }
          };
        });
      }

      /* ====== 初始化 ====== */
      function init() {
        initTheme();
        initSearch();
        initEditMode();
        initBookmarkManagement();
        initSettings();
        initEventListeners();
        initRender();
      }

      // 启动应用
      init();
    })();