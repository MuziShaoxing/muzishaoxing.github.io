浏览器扩展图标包 / Browser Extension Icons
==========================================

目录结构:
  icons/icon16.png
  icons/icon48.png
  icons/icon128.png

manifest.json (Manifest V3) 引用方式:
{
  "icons": {
    "16": "icons/icon16.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
  },
  "action": {
    "default_icon": {
      "16": "icons/icon16.png",
      "48": "icons/icon48.png",
      "128": "icons/icon128.png"
    }
  }
}

生成参数: 主色 #165DFF / 风格 grad
文字: 台面=开, 气泡=开, 卡片=关
