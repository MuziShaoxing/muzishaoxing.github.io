/**
 * 当DOM加载完成后执行初始化函数
 */
document.addEventListener('DOMContentLoaded', () => {
    initSettingsPage();
    initQRCodePage();
    adjustContainerSize();
    setupSizeSelector();
});

/**
 * 设置尺寸选择器
 */
function setupSizeSelector() {
    const sizeButtons = document.querySelectorAll('.size-btn');
    
    if (sizeButtons.length > 0) {
        // 从存储加载保存的尺寸
        chrome.storage.local.get(['qrSize'], (result) => {
            const size = result.qrSize || 'medium';
            setActiveSize(size);
        });
        
        // 添加按钮点击事件
        sizeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const size = btn.dataset.size;
                setActiveSize(size);
                
                // 保存选择的尺寸
                chrome.storage.local.set({ qrSize: size });
                
                // 调整容器尺寸
                adjustContainerSize();
            });
        });
        
        function setActiveSize(size) {
            // 更新按钮激活状态
            sizeButtons.forEach(btn => {
                btn.classList.toggle('active', btn.dataset.size === size);
            });
        }
    }
}

/**
 * 调整容器大小
 */
function adjustContainerSize() {
    chrome.storage.local.get(['qrSize'], (result) => {
        const size = result.qrSize || 'medium';
        const container = document.querySelector('.container');
        if (container) {
            // 移除所有尺寸类
            container.classList.remove('small-size', 'medium-size', 'large-size');
            // 添加当前尺寸类
            container.classList.add(`${size}-size`);
            
            // 设置按钮激活状态
            const buttons = document.querySelectorAll('.size-btn');
            if (buttons.length > 0) {
                buttons.forEach(btn => {
                    btn.classList.toggle('active', btn.dataset.size === size);
                });
            }
        }
    });
}

/**
 * 初始化设置页面
 */
function initSettingsPage() {
    if (window.location.pathname.includes('options.html')) {
        loadSettings();
        setupSaveButton();
        
        const title = document.querySelector('h1');
        if (title) {
            const handleClick = () => goToAdmirePage();
            
            title.addEventListener('mouseover', function() {
                this.textContent = '👉🏻 赞赏 👈🏻';
                this.style.color = 'red';
                this.addEventListener('click', handleClick);
            });
            
            title.addEventListener('mouseout', function() {
                this.textContent = '👉🏻 设置 👈🏻';
                this.style.color = '#555';
                this.removeEventListener('click', handleClick);
            });
        }
    }
}

/**
 * 初始化二维码页面
 */
function initQRCodePage() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('text')) {
        setupQRCode();
    }
}

/**
 * 设置保存按钮功能
 */
function setupSaveButton() {
    const saveButton = document.getElementById('saveSettings');
    if (saveButton) {
        saveButton.addEventListener('click', () => {
            const settings = {
                enablePhoneNumberDetection: document.getElementById('enablePhoneNumberDetection').checked,
                enableVCardGeneration: document.getElementById('enableVCardGeneration').checked,
                enableNewContactFormat: document.getElementById('enableNewContactFormat').checked
            };
            
            chrome.storage.local.set(settings, () => {
                showSaveAlert();
            });
        });
    }
}

/**
 * 显示保存成功提示
 */
function showSaveAlert() {
    const alertDiv = document.createElement('div');
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '50%';
    alertDiv.style.left = '50%';
    alertDiv.style.transform = 'translate(-50%, -50%)';
    alertDiv.style.padding = '15px 25px';
    alertDiv.style.backgroundColor = '#0078d4';
    alertDiv.style.color = 'white';
    alertDiv.style.borderRadius = '8px';
    alertDiv.style.zIndex = '1000';
    alertDiv.style.textAlign = 'center';
    alertDiv.style.boxShadow = '0 6px 18px rgba(0, 0, 0, 0.2)';
    alertDiv.style.fontSize = '16px';
    alertDiv.textContent = '设置已保存！';
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        document.body.removeChild(alertDiv);
        window.close();
    }, 2000);
}

/**
 * 加载设置
 */
function loadSettings() {
    const settingsKeys = [
        'enablePhoneNumberDetection',
        'enableVCardGeneration',
        'enableNewContactFormat'
    ];
    
    chrome.storage.local.get(settingsKeys, (result) => {
        settingsKeys.forEach(key => {
            const element = document.getElementById(key);
            if (element) {
                element.checked = result[key] !== false;
            }
        });
    });
}

// 定义显示赞赏页面的函数
function goToAdmirePage() {
    // 如果已存在赞赏弹窗，则直接返回不再创建
    if (document.getElementById('admire-overlay')) return;
    
    // 创建遮罩层元素
    const overlay = document.createElement('div');
    // 设置遮罩层ID
    overlay.id = 'admire-overlay';
    // 固定定位
    overlay.style.position = 'fixed';
    // 顶部定位
    overlay.style.top = '0';
    // 左侧定位
    overlay.style.left = '0';
    // 宽度100%
    overlay.style.width = '100%';
    // 高度100%
    overlay.style.height = '100%';
    // 半透明黑色背景
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    // 设置最高层级
    overlay.style.zIndex = '9999';
    // 使用flex布局
    overlay.style.display = 'flex';
    // 水平居中
    overlay.style.justifyContent = 'center';
    // 垂直居中
    overlay.style.alignItems = 'center';
    // 背景模糊效果
    overlay.style.backdropFilter = 'blur(5px)';
    
    // 创建内容容器
    const container = document.createElement('div');
    // 白色背景
    container.style.backgroundColor = 'white';
    // 内边距
    container.style.padding = 'auto';
    // 圆角边框
    container.style.borderRadius = '16px';
    // 阴影效果
    container.style.boxShadow = '0 12px 30px rgba(0, 0, 0, 0.25)';
    // 文字居中
    container.style.textAlign = 'center';
    // 最大宽度
    container.style.maxWidth = '320px';
    // 宽度90%
    container.style.width = '90%';
    
    // 创建二维码图片元素
    const img = document.createElement('img');
    // 设置图片路径
    img.src = './icons/admire.jpeg';
    // 图片替代文字
    img.alt = '赞赏二维码';
    // 图片宽度80%
    img.style.width = '100%';
    // 图片高度80%
    img.style.height = '100%';
    // 块级显示
    img.style.display = 'block';
    // 外边距设置
    img.style.margin = 'auto auto auto';
    // 图片圆角
    img.style.borderRadius = '8px';
    // 禁止拖动图片
    img.draggable = false;
    

    
    // 将图片添加到容器
    container.appendChild(img);
    // 将容器添加到遮罩层
    overlay.appendChild(container);
    // 将遮罩层添加到页面body
    document.body.appendChild(overlay);
    
    // 给遮罩层添加点击事件
    overlay.addEventListener('click', (e) => {
        // 如果点击的是遮罩层本身(不是内容区域)
        if (e.target === overlay) {
            // 从页面移除遮罩层
            document.body.removeChild(overlay);
        }
    });
}
/**
 * 设置二维码页面
 */
function setupQRCode() {
    const urlParams = new URLSearchParams(window.location.search);
    let text = urlParams.get('text') || 'options.html';
    chrome.storage.local.get([
        'enablePhoneNumberDetection',
        'enableVCardGeneration',
        'enableNewContactFormat'
    ], (result) => {
        const settings = {
            enablePhoneNumberDetection: result.enablePhoneNumberDetection !== false,
            enableVCardGeneration: result.enableVCardGeneration !== false,
            enableNewContactFormat: result.enableNewContactFormat !== false
        };
        
        const qrText = processInputText(text, settings);
        document.getElementById('url').value = qrText;
        
        const qrcodeElement = document.getElementById('qrcode');
        new QRCode(qrcodeElement, {
            text: qrText,
            width: 200,
            height: 200,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
        });
        
        qrcodeElement.addEventListener('dblclick', goToAdmirePage);
    });
}

/**
 * 处理输入文本
 */
function processInputText(inputText, settings) {
    const minutePattern = /^(194\d{17})(?:分钟：\d+单)?$/;
    if (minutePattern.test(inputText) && 
       (inputText.endsWith('40') || inputText.includes('分钟：'))) {
        return inputText.slice(0, 18);
    }
    
    if (settings.enablePhoneNumberDetection && /^1\d{10}$/.test(inputText)) {
        return `tel:${inputText}`;
    }
    
    if (settings.enableVCardGeneration) {
        const namePhonePattern = /([\u4e00-\u9fa5]+)[(（](1\d{10})[)）]/;
        const matchResult = inputText.match(namePhonePattern);
        if (matchResult && matchResult.length === 3) {
            const [_, name, phone] = matchResult;
            return `BEGIN:VCARD
VERSION:3.0
N:${name}
FN:${name}
TEL;TYPE=CELL:${phone}
END:VCARD`;
        }
    }
    
    if (settings.enableNewContactFormat) {
        const newContactPattern = /([\u4e00-\u9fa5]+)\s+(1\d{10})/;
        const matchResult = inputText.match(newContactPattern);
        if (matchResult && matchResult.length === 3) {
            const [_, name, phone] = matchResult;
            return `BEGIN:VCARD
VERSION:3.0
N:${name}
FN:${name}
TEL;TYPE=CELL:${phone}
END:VCARD`;
        }
    }
    
    return inputText;
}